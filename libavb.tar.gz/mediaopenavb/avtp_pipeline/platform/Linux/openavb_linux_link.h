/**
 * Copyright @ 2013 - 2018 Suntec Software(Shanghai) Co., Ltd.
 * All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are NOT permitted except as agreed by
 * Suntec Software(Shanghai) Co., Ltd.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

/**
 * @file openavb_linux_link.h
 */
#ifndef OPENAVB_LINUX_LINK_H
#define OPENAVB_LINUX_LINK_H

#ifndef QNX_OS
//#define QNX_OS
#endif

#ifdef QNX_OS
#include <net/if_ether.h>
#include <netinet/if_ether.h>
#include <net/if.h>

typedef	uint16_t	u_int16_t;
typedef unsigned int __u32;
typedef unsigned short __u16;
typedef unsigned char __u8;
typedef uint64_t	U64;

#define NANOSECONDS_PER_SECOND		(1000000000ULL)

#ifndef IFNAMSIZ
#define IFNAMSIZ 16
#endif
#ifndef ETH_ALEN
#define ETH_ALEN 6
#endif

#define ETH_HLEN	14
#define SOL_PACKET	263
#define	PACKET_RX_RING			5
#define	PACKET_VERSION			10
#define	PACKET_HDRLEN			11
#define	PACKET_TX_RING			13

#define TP_STATUS_KERNEL		      0
#define TP_STATUS_USER			(1 << 0)
#define TP_STATUS_COPY			(1 << 1)
#define TP_STATUS_LOSING		(1 << 2)
#define TP_STATUS_AVAILABLE	      0
#define TP_STATUS_SEND_REQUEST	(1 << 0)
#define TP_STATUS_SENDING	(1 << 1)
#define TP_STATUS_WRONG_FORMAT	(1 << 2)

#define PF_PACKET	17	/* Packet family.  */
#define SO_MARK			36
#define SO_PRIORITY	12
#define PACKET_MR_MULTICAST	0
#define PACKET_ADD_MEMBERSHIP		1
#define PACKET_DROP_MEMBERSHIP		2
#define SO_ATTACH_FILTER	26
#define SO_DETACH_FILTER	27

#define TPACKET_ALIGNMENT	16
#define TPACKET_ALIGN(x)	(((x)+TPACKET_ALIGNMENT-1)&~(TPACKET_ALIGNMENT-1))

#define SLEEP_UNTIL_NSEC(nSec)  				   xSleepUntilNSec(nSec)
//inline static void xSleepUntilNSec(U64 nSec)
//{
//	struct timespec tmpTime;
//	tmpTime.tv_sec = nSec / NANOSECONDS_PER_SECOND;
//	tmpTime.tv_nsec = nSec % NANOSECONDS_PER_SECOND;
//	clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &tmpTime, NULL);
//}

enum tpacket_versions {
	TPACKET_V1,
	TPACKET_V2,
	TPACKET_V3
};

struct sockaddr_ll {
    unsigned short int sll_family;
    unsigned short int sll_protocol;
    int sll_ifindex;
    unsigned short int sll_hatype;
    unsigned char sll_pkttype;
    unsigned char sll_halen;
    unsigned char sll_addr[8];
};

struct tpacket_req {
	unsigned int	tp_block_size;	/* Minimal size of contiguous block */
	unsigned int	tp_block_nr;	/* Number of blocks */
	unsigned int	tp_frame_size;	/* Size of frame */
	unsigned int	tp_frame_nr;	/* Total number of frames */
};

struct tpacket2_hdr {
	__u32		tp_status;
	__u32		tp_len;
	__u32		tp_snaplen;
	__u16		tp_mac;
	__u16		tp_net;
	__u32		tp_sec;
	__u32		tp_nsec;
	__u16		tp_vlan_tci;
	__u16		tp_vlan_tpid;
	__u8		tp_padding[4];
};

struct packet_mreq {
	int		mr_ifindex;
	unsigned short	mr_type;
	unsigned short	mr_alen;
	unsigned char	mr_address[8];
};

struct sock_filter {	/* Filter block */
	__u16	code;   /* Actual filter code */
	__u8	jt;	/* Jump true */
	__u8	jf;	/* Jump false */
	__u32	k;      /* Generic multiuse field */
};

struct sock_fprog {	/* Required for SO_ATTACH_FILTER. */
	unsigned short		len;	/* Number of filter blocks */
	struct sock_filter *filter;
};

#else
#include <linux/if_ether.h>
//#include <bits/types.h>
#include <netinet/ether.h>
#include <netinet/in.h>
#include <sys/timerfd.h>
#include <linux/ptp_clock.h>
#include <net/ethernet.h>
#include <linux/if_packet.h>
#include <linux/filter.h>
#include <net/if.h>
#endif

#endif
