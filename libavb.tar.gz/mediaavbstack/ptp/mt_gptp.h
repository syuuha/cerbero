#ifndef _MT_GPTP_H
#define _MT_GPTP_H

#include <inttypes.h>

#define MT_GPTP_NANOSECONDS_PER_USEC		(1000L)
#define MT_NANOSECONDS_PER_SECOND		(1000000000ULL)
#define MT_OPENAVB_AVTP_TIME_MAX_TS_DIFF (0x7FFFFFFF)

typedef struct _mt_gptp mt_gptp;
#ifndef false
typedef enum
{
    false = 0,
    true = 1
} bool;
#endif
// Not mt-safe
mt_gptp *mt_gptp_init();
void mt_gptp_deinit(mt_gptp* ptp);
bool mt_gptp_system2master(mt_gptp* ptp, const uint64_t system, uint64_t* master);
bool mt_gptp_master2system(mt_gptp* ptp, const uint64_t master, uint64_t* system);
bool mt_gptp_mastertime(mt_gptp* ptp, uint64_t* master);
void mt_time_set_to_ts(mt_gptp* ptp, uint64_t *dest_nsec, uint64_t timestamp);
bool mt_time_get_sys_ns(mt_gptp* ptp, int clockid, uint64_t *time_ns);

#endif
