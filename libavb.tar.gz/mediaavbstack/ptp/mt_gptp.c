#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <pthread.h>
#include <mt_gptp.h>

#define SHM_SIZE (4*8 + sizeof(pthread_mutex_t)) /* 3 - 64 bit and 2 - 32 bits */
#define SHM_NAME  "/ptp"
#define PTP_CLOCK_IDENTITY_LENGTH 8

#if defined(__clang__) &&  defined(__x86_64__)
// Clang/llvm has incompatible long double (fp128) for x86_64.
typedef double freq_ratio_t;        /*!< Frequency Ratio */
#else
typedef long double freq_ratio_t;    /*!< Frequency Ratio */
#endif

/**
 * @brief port_state_t enumeration
 */
typedef enum {
    PTP_MASTER = 7,   //!< Port is PTP Master
    PTP_PRE_MASTER,   //!< Port is not PTP Master yet.
    PTP_SLAVE,          //!< Port is PTP Slave
    PTP_UNCALIBRATED, //!< Port is uncalibrated.
    PTP_DISABLED,     //!< Port is not PTP enabled. All messages are ignored when in this state.
    PTP_FAULTY,          //!< Port is in a faulty state. Recovery is implementation specific.
    PTP_INITIALIZING, //!< Port's initial state.
    PTP_LISTENING     //!< Port is in a PTP listening state. Currently not in use.
} port_state_t;


typedef struct {
    int64_t ml_phoffset;            //!< Master to local phase offset
    int64_t ls_phoffset;            //!< Local to system phase offset
    freq_ratio_t ml_freqoffset;    //!< Master to local frequency offset
    freq_ratio_t ls_freqoffset;    //!< Local to system frequency offset
    uint64_t local_time;            //!< Local time of last update


    /* Referenced by the IEEE Std 1722.1-2013 AVDECC Discovery Protocol Data Unit (ADPDU) */
    uint8_t gptp_grandmaster_id[PTP_CLOCK_IDENTITY_LENGTH];    //!< Current grandmaster id (all 0's if no grandmaster selected)
    uint8_t gptp_domain_number;        //!< gPTP domain number

    /* Grandmaster support for the network interface */
    /* Referenced by the IEEE Std 1722.1-2013 AVDECC AVB_INTERFACE descriptor */
    uint8_t  clock_identity[PTP_CLOCK_IDENTITY_LENGTH];    //!< The clock identity of the interface
    uint8_t  priority1;                //!< The priority1 field of the grandmaster functionality of the interface, or 0xFF if not supported
    uint8_t  clock_class;            //!< The clockClass field of the grandmaster functionality of the interface, or 0xFF if not supported
    int16_t  offset_scaled_log_variance;    //!< The offsetScaledLogVariance field of the grandmaster functionality of the interface, or 0x0000 if not supported
    uint8_t  clock_accuracy;        //!< The clockAccuracy field of the grandmaster functionality of the interface, or 0xFF if not supported
    uint8_t  priority2;                //!< The priority2 field of the grandmaster functionality of the interface, or 0xFF if not supported
    uint8_t  domain_number;            //!< The domainNumber field of the grandmaster functionality of the interface, or 0 if not supported
    int8_t   log_sync_interval;        //!< The currentLogSyncInterval field of the grandmaster functionality of the interface, or 0 if not supported
    int8_t   log_announce_interval;    //!< The currentLogAnnounceInterval field of the grandmaster functionality of the interface, or 0 if not supported
    int8_t   log_pdelay_interval;    //!< The currentLogPDelayReqInterval field of the grandmaster functionality of the interface, or 0 if not supported
    uint16_t port_number;            //!< The portNumber field of the interface, or 0x0000 if not supported

    /* Linux-specific */
    uint32_t sync_count;            //!< Sync messages count
    uint32_t pdelay_count;            //!< pdelay messages count
    bool asCapable;                 //!< asCapable flag: true = device is AS Capable; false otherwise
    port_state_t port_state;            //!< gPTP port state. It can assume values defined at ::port_state_t
    pid_t process_id;            //!< Process id number
} gptp_time_d;

struct _mt_gptp {
    gptp_time_d data;
};

static volatile int ref_cnt = 0;
int shm_fd_ins = -1;
char *mmap_ins = NULL;

/**
 * @brief Open the memory mapping used for IPC
 * @param shm_fd [inout] File descriptor for mapping
 * @param shm_map [inout] Pointer to mapping
 * @return 0 for success, negative for failure
 */
 int
gptp_init(int *shm_fd, char **shm_map)
{
    if (NULL == shm_fd || NULL == shm_map) {
        return -1;
    }

#ifdef __ANDROID__

#else
    *shm_fd = shm_open(SHM_NAME, O_RDWR, 0);
#endif

    if (*shm_fd == -1) {
        perror("shm_open()");
        return -1;
    }
    *shm_map = (char *)mmap(NULL, SHM_SIZE, PROT_READ | PROT_WRITE,
                MAP_SHARED, *shm_fd, 0);
    if ((char*)-1 == *shm_map) {
        perror("mmap()");
        *shm_map = NULL;

#ifdef __ANDROID__

#else
        shm_unlink(SHM_NAME);
#endif

        return -1;
    }
    return 0;
}

/**
 * @brief Free the memory mapping used for IPC
 * @param shm_fd [in] File descriptor for mapping
 * @param shm_map [in] Pointer to mapping
 * @return 0 for success, negative for failure
 *    -1 = close failed
 *    -2 = munmap failed
 *    -3 = close and munmap failed
 */

 int
gptp_deinit(int *shm_fd, char **shm_map)
{
    int ret = 0;
    if (NULL == shm_fd || -1 == *shm_fd) {
        ret -= 1;
    } else {
        if(close(*shm_fd) == -1) {
            ret -= 1;
        }
        *shm_fd = -1;
    }
    if (NULL == shm_map || NULL == *shm_map) {
        ret -= 2;
    } else {
        if (munmap(*shm_map, SHM_SIZE) == -1) {
            ret -= 2;
        }
        *shm_map = NULL;
    }
    return ret;
}

mt_gptp*
mt_gptp_init()
{
    mt_gptp *p = NULL;
    p = (mt_gptp *)malloc(sizeof(mt_gptp));
    if (!mmap_ins) {
        if (gptp_init(&shm_fd_ins, &mmap_ins) < 0) {
            goto fail;
        }
    }
    ++ref_cnt;
    return p;

fail:
    if (p)
        free(p);

    return NULL;
}

void
mt_gptp_deinit(mt_gptp* ptp)
{
    if (!ptp)
        return;

    if (--ref_cnt == 0) {
        if (mmap_ins) {
            gptp_deinit(&shm_fd_ins, &mmap_ins);
            shm_fd_ins = -1;
            mmap_ins = NULL;
        }
    }

    free(ptp);
}

/**
 * @brief Read the ptp data from IPC memory
 * @param shm_map [in] Pointer to mapping
 * @param td [inout] Struct to read the data into
 * @return 0 for success, negative for failure
 */
static int
gptp_fetch(char *shm_map, gptp_time_d *td)
{
    if (NULL == shm_map || NULL == td) {
        return -1;
    }
    pthread_mutex_lock((pthread_mutex_t *) shm_map);
    memcpy(td, shm_map + sizeof(pthread_mutex_t), sizeof(*td));
    pthread_mutex_unlock((pthread_mutex_t *) shm_map);

    return 0;
}

bool
gptp_localtime(const gptp_time_d * td, uint64_t* now_local)
{
    struct timespec sys_time;
    uint64_t now_system;
    uint64_t system_time;
    int64_t delta_local;
    int64_t delta_system;

    if (!td || !now_local)
        return false;

    if (clock_gettime(CLOCK_REALTIME, &sys_time) != 0)
        return false;

    now_system = (uint64_t)sys_time.tv_sec * 1000000000ULL + (uint64_t)sys_time.tv_nsec;//now  system time

    system_time = td->local_time + td->ls_phoffset; // wether or not Local to system phase offset
    delta_system = now_system - system_time;
    delta_local = td->ls_freqoffset * delta_system;
    *now_local = td->local_time + delta_local;

    return true;
}

bool
mt_gptp_mastertime(mt_gptp* ptp, uint64_t* master)
{
    if (!ptp || !mmap_ins) {
        return false;
    }

    if (gptp_fetch(mmap_ins, &(ptp->data)) < 0) {
        // printf("GPTP data fetch failed\n");
        return false;
    }

    if(0 == ptp->data.port_state) {
        //if port_state = 0  , invalid port_state
        return false;
    }
    uint64_t now_local;
    uint64_t update_8021as;
    int64_t delta_8021as;
    int64_t delta_local;

    if (gptp_localtime(&(ptp->data), &now_local)) {
        update_8021as = ptp->data.local_time - ptp->data.ml_phoffset;
        delta_local = now_local - ptp->data.local_time;
        delta_8021as = ptp->data.ml_freqoffset * delta_local;
        *master = update_8021as + delta_8021as;

        return true;
    }

    return false;
}

static bool
gptp_master2local(const gptp_time_d *td, const uint64_t master, uint64_t *local)
{
    int64_t delta_8021as;
    int64_t delta_local;

    if (!td || !local)
        return false;

    delta_8021as = master - td->local_time + td->ml_phoffset;
    delta_local = delta_8021as / td->ml_freqoffset;
    *local = td->local_time + delta_local;

    return true;
}

bool
mt_gptp_system2master(mt_gptp* ptp, const uint64_t system, uint64_t* master)
{
    if (!ptp || !master) {
        return false;
    }

    uint64_t ptp_system;
    uint64_t ptp_8021as;
    uint64_t local;
    int64_t delta_system;
    int64_t delta_local;
    int64_t delta_8021as;

    if (gptp_fetch(mmap_ins, &(ptp->data)) < 0) {
        // printf("GPTP data fetch failed\n");
        return false;
    }

    ptp_system = ptp->data.local_time + ptp->data.ls_phoffset;
    delta_system = system - ptp_system;
    delta_local = ptp->data.ls_freqoffset * delta_system;

    ptp_8021as = ptp->data.local_time - ptp->data.ml_phoffset;
    delta_8021as = ptp->data.ml_freqoffset * delta_local;
    *master = ptp_8021as + delta_8021as;

    return true;
}

bool
mt_gptp_master2system(mt_gptp* ptp, const uint64_t master, uint64_t* system)
{
    if (!ptp || !system) {
        return false;
    }

    uint64_t ptp_system;
    uint64_t ptp_8021as;
    uint64_t local;
    int64_t delta_system;
    int64_t delta_local;
    int64_t delta_8021as;

    if (gptp_fetch(mmap_ins, &(ptp->data)) < 0) {
        // printf("GPTP data fetch failed\n");
        return false;
    }

    ptp_8021as = ptp->data.local_time - ptp->data.ml_phoffset;
    delta_8021as = master - ptp_8021as;
    delta_local = delta_8021as / (ptp->data.ml_freqoffset);

    ptp_system = ptp->data.local_time + ptp->data.ls_phoffset;
    delta_system = delta_local / ptp->data.ls_freqoffset;
    *system = ptp_system + delta_system;
    return true;
}



void mt_time_set_to_ts(mt_gptp* ptp, uint64_t *dest_nsec, uint64_t timestamp)
{
	if (dest_nsec) {
        struct timespec tmNow;
        uint64_t ptp_time;
		if (mt_gptp_mastertime(ptp, &ptp_time)) {
			uint64_t nsNow = ptp_time;
			uint32_t tsNow = ptp_time & 0x00000000FFFFFFFFL;

			uint32_t delta;
			if (tsNow < timestamp) {
				delta = timestamp - tsNow;
			}
			else if (tsNow > timestamp) {
				delta = timestamp + (0x100000000ULL - tsNow);
			}
			else {
				delta = 0;
			}

			if (delta < MT_OPENAVB_AVTP_TIME_MAX_TS_DIFF) {
			  	// Normal case, timestamp is upcoming
				*dest_nsec = nsNow + delta;
			}
			else {
			  	// Timestamp is past
				*dest_nsec = nsNow - (0x100000000ULL - delta);
			}

			// pAvtpTime->bTimestampValid = TRUE;
			// pAvtpTime->bTimestampUncertain = FALSE;
		}
		else {
			// pAvtpTime->bTimestampValid = FALSE;
			// pAvtpTime->bTimestampUncertain = TRUE;
		}
	}
}

bool mt_time_get_sys_ns(mt_gptp* ptp, int clockid, uint64_t *time_ns) {

    if (clockid < CLOCK_REALTIME || clockid > CLOCK_MONOTONIC) {
        return false;
    }
    struct timespec getTime;
    if (!clock_gettime(clockid, &getTime)) {
        *time_ns = ((uint64_t)getTime.tv_sec * (uint64_t)MT_NANOSECONDS_PER_SECOND) + (uint64_t)getTime.tv_nsec;
        return true;
    }
    return false;
}
