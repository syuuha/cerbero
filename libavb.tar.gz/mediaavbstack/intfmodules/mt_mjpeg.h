#ifndef MT_MJPEG_H
#define MT_MJPEG_H
#include "glib.h"
#include <stdio.h>
#include <mt_inc.h>
#include <openavb_mediaq_pub.h>

#define DEFAULT_JPEG_QUALITY 255
#define DEFAULT_JPEG_QUANT 255
#define DEFAULT_JPEG_TYPE 1

typedef enum {
    JPEG_MARKER_NOTHING = 0x00,
    JPEG_MARKER = 0xFF,
    JPEG_MARKER_SOI = 0xD8,
    JPEG_MARKER_JFIF = 0xE0,
    JPEG_MARKER_CMT = 0xFE,
    JPEG_MARKER_DQT = 0xDB, //量化表，，，64字节 比如亮度色度的量化表
    JPEG_MARKER_SOF = 0xC0,
    JPEG_MARKER_DHT = 0xC4,
    JPEG_MARKER_JPG = 0xC8,
    JPEG_MARKER_SOS = 0xDA,
    JPEG_MARKER_EOI = 0xD9,
    JPEG_MARKER_DRI = 0xDD,
    JPEG_MARKER_APP0 = 0xE0,
    JPEG_MARKER_H264 = 0xE4, /* APP4 */
    JPEG_MARKER_APP15 = 0xEF,
    JPEG_MARKER_JPG0 = 0xF0,
    JPEG_MARKER_JPG13 = 0xFD
} mt_jpg_marker_t;

//read from sof(FF C0) mt_jpg_comp_info *[3]
typedef struct {
    guint8 id;
    guint8 samp;
    guint8 qt;
} mt_jpg_comp_info;

typedef struct {
#ifdef BIG_ENDIA
    guint32 version : 2; /* protocol version */
    guint32 p : 1;       /* padding flag */
    guint32 x : 1;       /* header extension flag */
    guint32 cc : 4;      /* CSRC count */
    guint32 m : 1;       /* marker bit */
    guint32 pt : 7;      /* payload type */
    guint32 seq : 16;    /* sequence number */

#else //小端

    guint8 cc : 4;
    guint8 x : 1;
    guint8 p : 1;
    guint8 v : 2;

    guint8 pt : 7;
    guint8 m : 1;

    guint16 seq:16;

#endif
    guint32 timestamp;
    guint32 ssrc;
    //guint32 csrc[1]; /* optional CSRC list */
} mt_jpg_rtp_hdr_t;

//read from dqt (FF DB )  mt_jpg_quant_table *[2]
typedef struct {
    guint8 size;
    const guint8 *data;
} mt_jpg_quant_table;

typedef struct {
    guint8 mbz;
    guint8 precision; //distinguish the  mt_jpg_quant_table data size is 64 or 128
    guint16 length;
} mt_jpg_quant_header;

typedef struct {
    //GstRTPBasePayload payload;
    //reset by sof (FF C0)
    gint height;
    gint width;
    guint8 type; //components type  0x21 type=0 ;if 0x22 type=1

    //set default
    guint8 quality; //default set DEFAULT_JPEG_QUALITY
    guint8 quant;   //default set DEFAULT_JPEG_QUANT=255
} mt_jpg_frame_info;

typedef struct {
    guint type_spec : 8;
    guint offset : 24; //pack offset
    guint8 type; //read from sof (FF C0) and reset bt dri head
    guint8 q;
    guint8 width;
    guint8 height;
} mt_jpg_head;

typedef struct {
    guint16 restart_interval;
    guint16 restart_count;
} mt_jpg_restart_marker_header;

typedef struct {
    mt_jpg_frame_info pay;
    mt_jpg_head jpeg_header;
    mt_jpg_quant_header quant_header;
    mt_jpg_restart_marker_header restart_marker_header;
    guint quant_data_size;
    guint jpeg_marker_info_size;
    //gboolean sos_found, sof_found, dqt_found, dri_found;
    gboolean sos_found;
    gboolean sof_found;
    gboolean dqt_found;
    gboolean dri_found;
    mt_jpg_rtp_hdr_t rtp_head;
} mt_jpg_pack;

mt_jpg_pack* mt_jpg_pack_init();
void mt_jpg_pack_deinit(mt_jpg_pack * pkg);
gboolean mt_jpg_pay(mt_jpg_pack* pkg, mt_buffer *pBuffer, media_q_item_t *pMediaQItem);
gboolean mt_jpg_depay(mt_jpg_pack* pkg, mt_buffer *pBuffer, media_q_item_t *pMediaQItem);

#endif
