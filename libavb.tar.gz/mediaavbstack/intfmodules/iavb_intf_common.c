/*************************************************************************************************************
Copyright (c) 2012-2015, Symphony Teleca Corporation, a Harman International Industries, Incorporated company
Copyright (c) 2016-2017, Harman International Industries, Incorporated
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS LISTED "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS LISTED BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Attributions: The inih library portion of the source code is licensed from
Brush Technology and Ben Hoyt - Copyright (c) 2009, Brush Technology and Copyright (c) 2009, Ben Hoyt.
Complete license and copyright information can be found at
https://github.com/benhoyt/inih/commit/74d2ca064fb293bc60a77b0bd068075b293cf175.
*************************************************************************************************************/

/*
* MODULE SUMMARY : common interface module.
*
* This common interface module sends or receives data from MediaQ, interact with mediatransport
* exercise the various functions and callback and can be used as an example
* or a template for new interfaces.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "glib.h"
#include "mt_map_h264_pub.h"
#include "mt_map_mjpeg_pub.h"
#include "mt_map_mpeg2ts_pub.h"
#include "mt_map_aaf_audio_pub.h"
#include "mt_map_uncmp_audio_pub.h"
#include "openavb_types_pub.h"
#include "openavb_mediaq_pub.h"
#include "openavb_intf_pub.h"
//#include "mt_avtp_common.h"
#include "mt_inc.h"
#include <mt_mjpeg.h>

#ifdef MT_CATEGERY
#undef MT_CATEGERY
#endif
#define MT_CATEGERY "avtp_intf_common"

#define H264NAL_SUPPORT (1)
#define H264NAL_HEAD3   ("\x00\x00\x01")
#define H264NAL_HEAD4   ("\x00\x00\x00\x01")
#define H264NAL_HEAD_LEN3   (3)
#define H264NAL_HEAD_LEN4   (4)

#define RTPH264_NAL_TYPE_NON_IDR    (1)
#define RTPH264_NAL_TYPE_SLICE_A    (2)
#define RTPH264_NAL_TYPE_SLICE_B    (3)
#define RTPH264_NAL_TYPE_SLICE_C    (4)
#define RTPH264_NAL_TYPE_IDR    (5)
#define RTPH264_NAL_TYPE_SEI    (6)
#define RTPH264_NAL_TYPE_SPS    (7)
#define RTPH264_NAL_TYPE_PPS    (8)
#define RTPH264_NAL_TYPE_STAP_A     (24)
#define RTPH264_NAL_TYPE_STAP_B     (25)
#define RTPH264_NAL_TYPE_MTAP16     (26)
#define RTPH264_NAL_TYPE_MTAP24     (27)
#define RTPH264_NAL_TYPE_FU_A     (28)
#define RTPH264_NAL_TYPE_FU_B     (29)

#define RTPH264_FUA_HEAD_LEN   (2)
#define H264NAL_NALTYPE_LEN   (1)

#define IAVB_MT_MIN(A, B) ((A < B) ? (A) : (B))

typedef enum {
    AVB_STREAM_FORMAT_AAF,
    AVB_STREAM_FORMAT_PCM,
    AVB_STREAM_FORMAT_TS,
    AVB_STREAM_FORMAT_H264,
    AVB_STREAM_FORMAT_MJPEG
} stream_format_t;

typedef struct {
	/////////////
	// Config data
	/////////////
	// Ignore timestamp at listener.
    int streamFormat;
    bool validPipeline;
    union {
        struct {
            int audioRate;
            int audioBitDepth;
            int audioChannels;
            int audioEndian;
        } aaf;
        struct {
            int audioRate;
            int audioBitDepth;
            int audioChannels;
            int audioEndian;
        } iec61883_6;
        struct {
            U8 NalHead; // current NALU head
            bool split; // current NALU need split to FU-A or FU-A recover to NALU Type
        } h264;
        struct  {
        mt_jpg_pack* pkg;
        } mjpeg;
        struct  {
            int dummy; // TBD
        } iec61883_4;
    } streamPvtData;
	bool ignoreTs;
    uint64_t intervalCounter;
	/////////////
	// Variable data
	/////////////
    void *pDq;
    mt_buffer *pBuffer;
    mt_gptp *ptp;
    timestamp_type ts_type;
} pvt_data_t;

// #define DUMP_DATA_DEBUG (1)
#ifdef DUMP_DATA_DEBUG
static FILE* dump_tx = NULL;
static FILE* dump_rx = NULL;
static FILE* dump_rx_mtbuffer = NULL;
#endif

//used by tx and rx refer to diff ts_type between master time and usertime  change
bool mt_intf_time_change_rx(int ts_type, mt_gptp * ptp, const avtp_time_t *pAvtpTime, uint64_t * dest_ts) {
    if (ts_type < TS_DEFAULT || ts_type > TS_MASTER) {
        MT_PRINT_ERR("ts_type is valid");
        return FALSE;
    }
    if (!pAvtpTime) {
        MT_PRINT_ERR("pAvtpTime is NULL");
        return FALSE;
    }
    if (!dest_ts) {
        MT_PRINT_ERR("dest_ts is NULL");
        return FALSE;
    }
    if (!ptp) {
        MT_PRINT_INFO("ptp is NULL");
        return FALSE;
    }

    switch (ts_type) {
    case TS_MASTER:
    case TS_DEFAULT:
        //master、default，直接将avtp_time填写到mt_buffer
        *dest_ts = pAvtpTime->timeNsec;
        break;
    case TS_SYSTEM:
        //system，将avtp_time转换为system time，填写到mt_buffer
        if (!mt_gptp_master2system(ptp, pAvtpTime->timeNsec, dest_ts)) {
            MT_PRINT_ERR("mt_gptp_master2system failed");
            return  FALSE;
        }
        break;
    default:
    MT_PRINT_ERR("use valid ts_type");
        break;
    }

    return TRUE;
}

bool mt_intf_time_change_tx(int ts_type, mt_gptp * ptp, uint64_t src_ts, avtp_time_t *pAvtpTime) {
    if (ts_type<TS_DEFAULT || ts_type>TS_MASTER) {
        MT_PRINT_ERR("ts_type is valid");
        return  FALSE;
    }
    if (!pAvtpTime) {
        MT_PRINT_ERR("pAvtpTime is NULL");
        return  FALSE;
    }
    if (!ptp) {
        if (ts_type != TS_MASTER) {
            goto invalid_time;
        }
        MT_PRINT_INFO("ptp is NULL");
    }
    uint64_t tmNow;
    switch (ts_type) {
    case TS_DEFAULT:
        //default，维持现状，intfacemodule中取得ptptime，填写到avtp_timestamp位
        if (!mt_gptp_mastertime(ptp, &tmNow)) {
            goto invalid_time;
        }
        pAvtpTime->timeNsec = tmNow;
        pAvtpTime->bTimestampValid = TRUE;
        pAvtpTime->bTimestampUncertain = FALSE;
        break;
    case TS_SYSTEM:
        //system，将mt_buffer中的timestamp转换为master后，填写到avtp_timestamp位
        if (!mt_gptp_system2master(ptp, src_ts, &(pAvtpTime->timeNsec))) {
            goto invalid_time;
        }
        pAvtpTime->bTimestampValid = TRUE;
        pAvtpTime->bTimestampUncertain = FALSE;
        break;
    case TS_MASTER:
        //直接将mt_buffer中的timestamp，填写到avtp_timestamp位
        pAvtpTime->timeNsec = src_ts;
        pAvtpTime->bTimestampValid = TRUE;
        pAvtpTime->bTimestampUncertain = FALSE;
        break;
    default:
        MT_PRINT_ERR("use valid ts_type");
        break;
    }
    return TRUE;

    invalid_time: {
        pAvtpTime->timeNsec = 0;
        pAvtpTime->bTimestampValid = FALSE;
        pAvtpTime->bTimestampUncertain = TRUE;
        return FALSE;
    }
}
// Each configuration name value pair for this mapping will result in this callback being called.
static void iavbPcmCfgCB(media_q_t *pMediaQ, const char *name, const char *value)
{
    char *pEnd;
    long tmp;
    long val;
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    media_q_pub_map_uncmp_audio_info_t *pPubMapUncmpAudioInfo = (media_q_pub_map_uncmp_audio_info_t *)pMediaQ->pPubMapInfo;
    // ===================== audio parameters ========================
    if (strcmp(name, "intf_nv_audio_rate") == 0) {
        val = strtol(value, &pEnd, 10);
        if (val >= AVB_AUDIO_RATE_8KHZ && val <= AVB_AUDIO_RATE_192KHZ) {
            pPvtData->streamPvtData.iec61883_6.audioRate = val;
        }
        else {
            MT_PRINT_ERR("Invalid audio rate configured for intf_nv_audio_rate.");
            pPvtData->streamPvtData.iec61883_6.audioRate = AVB_AUDIO_RATE_44_1KHZ;
        }
        pPubMapUncmpAudioInfo->audioRate = pPvtData->streamPvtData.iec61883_6.audioRate;
    }
    else if (strcmp(name, "intf_nv_audio_bit_depth") == 0) {
        val = strtol(value, &pEnd, 10);
        if (val >= AVB_AUDIO_BIT_DEPTH_1BIT && val <= AVB_AUDIO_BIT_DEPTH_64BIT) {
            pPvtData->streamPvtData.iec61883_6.audioBitDepth = val;
        }
        else {
            MT_PRINT_ERR("Invalid audio type configured for intf_nv_audio_bits.");
            pPvtData->streamPvtData.iec61883_6.audioBitDepth = AVB_AUDIO_BIT_DEPTH_24BIT;
        }
        pPubMapUncmpAudioInfo->audioBitDepth = pPvtData->streamPvtData.iec61883_6.audioBitDepth;
    }
    else if (strcmp(name, "intf_nv_audio_channels") == 0) {
        val = strtol(value, &pEnd, 10);
        if (val >= AVB_AUDIO_CHANNELS_1 && val <= AVB_AUDIO_CHANNELS_8) {
            pPvtData->streamPvtData.iec61883_6.audioChannels = val;
        }
        else {
            MT_PRINT_ERR("Invalid audio channels configured for intf_nv_audio_channels.");
            pPvtData->streamPvtData.iec61883_6.audioChannels = AVB_AUDIO_CHANNELS_2;
        }
        pPubMapUncmpAudioInfo->audioChannels = pPvtData->streamPvtData.iec61883_6.audioChannels;
    }
    else if (strcmp(name, "intf_nv_audio_endian") == 0) {
        if (strncasecmp(value, "big", 3) == 0) {
            pPvtData->streamPvtData.iec61883_6.audioEndian = AVB_AUDIO_ENDIAN_BIG;
            MT_PRINT_INFO("Forced audio samples endian conversion: little <-> big");
            pPubMapUncmpAudioInfo->audioEndian = pPvtData->streamPvtData.iec61883_6.audioEndian;
        }
    }
    else if (strcmp(name, "intf_nv_ts_type") == 0) {
        val = strtol(value, &pEnd, 10);
        if (val == TS_MASTER || val == TS_SYSTEM) {
            pPvtData->ts_type = val;
        }
        else {
            pPvtData->ts_type = TS_DEFAULT;
        }
        MT_PRINT_INFO("set ts_type=%d frpme config file", val);
    }
    else {
        MT_PRINT_INFO("Config not support, NV[%s]-[%s]", name, value);
    }
}

static void iavbAafCfgCB(media_q_t *pMediaQ, const char *name, const char *value)
{
    char *pEnd;
    long tmp;
    long val;
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    media_q_pub_map_uncmp_audio_info_t *pPubMapUncmpAudioInfo = (media_q_pub_map_uncmp_audio_info_t *)pMediaQ->pPubMapInfo;
    // ===================== audio parameters ========================
    if (strcmp(name, "intf_nv_audio_rate") == 0) {
        val = strtol(value, &pEnd, 10);
        if (val >= AVB_AUDIO_RATE_8KHZ && val <= AVB_AUDIO_RATE_192KHZ) {
            pPvtData->streamPvtData.aaf.audioRate = val;
        }
        else {
            MT_PRINT_ERR("Invalid audio rate configured for intf_nv_audio_rate.");
            pPvtData->streamPvtData.aaf.audioRate = AVB_AUDIO_RATE_44_1KHZ;
        }
        pPubMapUncmpAudioInfo->audioRate = pPvtData->streamPvtData.aaf.audioRate;
    }
    else if (strcmp(name, "intf_nv_audio_bit_depth") == 0) {
        val = strtol(value, &pEnd, 10);
        if (val >= AVB_AUDIO_BIT_DEPTH_1BIT && val <= AVB_AUDIO_BIT_DEPTH_64BIT) {
            pPvtData->streamPvtData.aaf.audioBitDepth = val;
        }
        else {
            MT_PRINT_ERR("Invalid audio type configured for intf_nv_audio_bits.");
            pPvtData->streamPvtData.aaf.audioBitDepth = AVB_AUDIO_BIT_DEPTH_24BIT;
        }
        pPubMapUncmpAudioInfo->audioBitDepth = pPvtData->streamPvtData.aaf.audioBitDepth;
    }
    else if (strcmp(name, "intf_nv_audio_channels") == 0) {
        val = strtol(value, &pEnd, 10);
        if (val >= AVB_AUDIO_CHANNELS_1 && val <= AVB_AUDIO_CHANNELS_8) {
            pPvtData->streamPvtData.aaf.audioChannels = val;
        }
        else {
            MT_PRINT_ERR("Invalid audio channels configured for intf_nv_audio_channels.");
            pPvtData->streamPvtData.aaf.audioChannels = AVB_AUDIO_CHANNELS_2;
        }
        pPubMapUncmpAudioInfo->audioChannels = pPvtData->streamPvtData.aaf.audioChannels;
    }
    else if (strcmp(name, "intf_nv_audio_endian") == 0) {
        if (strncasecmp(value, "big", 3) == 0) {
            pPvtData->streamPvtData.aaf.audioEndian = AVB_AUDIO_ENDIAN_BIG;
            MT_PRINT_INFO("Forced audio samples endian conversion: little <-> big");
            pPubMapUncmpAudioInfo->audioEndian = pPvtData->streamPvtData.aaf.audioEndian;
        }
    }
    else {
        MT_PRINT_INFO("Config not support, NV[%s]-[%s]", name, value);
    }
}

static void iavbTsCfgCB(media_q_t *pMediaQ, const char *name, const char *value)
{

}

static void iavbH264CfgCB(media_q_t *pMediaQ, const char *name, const char *value)
{

}

static void iavbMjpegCfgCB(media_q_t *pMediaQ, const char *name, const char *value)
{

}

void iavbIntfCommonCfgCB(media_q_t *pMediaQ, const char *name, const char *value)
{
    if (!pMediaQ || !name || !value) {
        return;
    }
    MT_PRINT_DEBUG("iavbIntfCommonCfgCB: key[%s], value[%s]", name, value);

    char *pEnd;
    long tmp;
    long val;

    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;

    if (!pPvtData) {
        MT_PRINT_ERR("Private interface module data not allocated.");
        return;
    }

    if (strcmp(name, "intf_nv_ignore_timestamp") == 0) {
        tmp = strtol(value, &pEnd, 10);
        if (*pEnd == '\0' && tmp == 1) {
            pPvtData->ignoreTs = (tmp == 1);
        }
    }
    else if (strcmp(name, "intf_nv_stream_format") == 0) {
        if (strcmp(value, "aaf") == 0) {
            pPvtData->streamFormat = AVB_STREAM_FORMAT_AAF;
            pPvtData->validPipeline = (strcmp(pMediaQ->pMediaQDataFormat, MapAVTPAudioMediaQDataFormat) == 0);
        }
        else if (strcmp(value, "pcm") == 0 || strcmp(value, "iec61883_6") == 0) {
            pPvtData->streamFormat = AVB_STREAM_FORMAT_PCM;
            pPvtData->validPipeline = (strcmp(pMediaQ->pMediaQDataFormat, MapUncmpAudioMediaQDataFormat) == 0);
        }
        else if (strcmp(value, "ts") == 0 || strcmp(value, "iec61883_4") == 0) {
            pPvtData->streamFormat = AVB_STREAM_FORMAT_TS;
            pPvtData->validPipeline = (strcmp(pMediaQ->pMediaQDataFormat, MapMpeg2tsMediaQDataFormat) == 0);
        }
        else if (strcmp(value, "h264") == 0) {
            pPvtData->streamFormat = AVB_STREAM_FORMAT_H264;
            pPvtData->validPipeline = (strcmp(pMediaQ->pMediaQDataFormat, MapH264MediaQDataFormat) == 0);
        }
        else if (strcmp(value, "mjpeg") == 0) {
            pPvtData->streamFormat = AVB_STREAM_FORMAT_MJPEG;
            pPvtData->validPipeline = (strcmp(pMediaQ->pMediaQDataFormat, MapMjpegMediaQDataFormat) == 0);
        }
        else {
            MT_PRINT_ERR("Invalid configuration[%s] for intf_nv_stream_format.", value);
        }
    }
    else {
        switch (pPvtData->streamFormat)
        {
        case AVB_STREAM_FORMAT_AAF:
            iavbAafCfgCB(pMediaQ, name, value);
            break;
        case AVB_STREAM_FORMAT_PCM:
            iavbPcmCfgCB(pMediaQ, name, value);
            break;
        case AVB_STREAM_FORMAT_H264:
            iavbH264CfgCB(pMediaQ, name, value);
            break;
        case AVB_STREAM_FORMAT_MJPEG:
            iavbMjpegCfgCB(pMediaQ, name, value);
            break;
        case AVB_STREAM_FORMAT_TS:
            iavbTsCfgCB(pMediaQ, name, value);
            break;
        default:
            break;
        }
    }
}

void iavbIntfCommonGenInitCB(media_q_t *pMediaQ)
{
    MT_PRINT_DEBUG("iavbIntfCommonGenInitCB");
    if (!pMediaQ) {
        return;
    }
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    if (!pPvtData) {
        MT_PRINT_ERR("Private interface module data not allocated.");
        return;
    }

    pPvtData->ptp = mt_gptp_init(); //al format use the ptp timestamp

    pPvtData->ts_type = TS_DEFAULT; //this param would be reset by config file if not set use this default val

    if (strcmp(pMediaQ->pMediaQDataFormat, MapAVTPAudioMediaQDataFormat) == 0) {
        pPvtData->streamFormat = AVB_STREAM_FORMAT_AAF;
    }
    else if (strcmp(pMediaQ->pMediaQDataFormat, MapUncmpAudioMediaQDataFormat) == 0) {
        pPvtData->streamFormat = AVB_STREAM_FORMAT_PCM;
    }
    else if (strcmp(pMediaQ->pMediaQDataFormat, MapMpeg2tsMediaQDataFormat) == 0) {
        pPvtData->streamFormat = AVB_STREAM_FORMAT_TS;
    }
    else if (strcmp(pMediaQ->pMediaQDataFormat, MapH264MediaQDataFormat) == 0) {
        pPvtData->streamFormat = AVB_STREAM_FORMAT_H264;
    }
    else if (strcmp(pMediaQ->pMediaQDataFormat, MapMjpegMediaQDataFormat) == 0) {
        pPvtData->streamFormat = AVB_STREAM_FORMAT_MJPEG;
        pPvtData->streamPvtData.mjpeg.pkg = mt_jpg_pack_init();
    }
    else {
        MT_PRINT_ERR("Stream format[%s] not specify or not supported");
    }
    return;
}

// A call to this callback indicates that this interface module will be
// a talker. Any talker initialization can be done in this function.
void iavbIntfCommonTxInitCB(media_q_t *pMediaQ)
{
    MT_PRINT_DEBUG("iavbIntfCommonTxInitCB");
#ifdef DUMP_DATA_DEBUG
    if (!dump_tx) {
        dump_tx = fopen("./dump_intf_tx.bin", "wb");
    }
#endif
}

static bool iavbPcmTxCb(media_q_t *pMediaQ)
{
    // MT_PRINT_TRACE("iavbPcmTxCb enter");
    if (!pMediaQ) {
        return FALSE;
    }
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    media_q_pub_map_uncmp_audio_info_t *pPubMapUncmpAudioInfo = pMediaQ->pPubMapInfo;
    if (!pPvtData || !pPvtData->pDq || !pPubMapUncmpAudioInfo) {
        return FALSE; // Data provider not exist
    }

    bool noPacking = pPubMapUncmpAudioInfo->packingFactor == 1 ? true : false;
    int itemCounts = noPacking ? 4 : 1;
    if (noPacking) {
        if (pPvtData->intervalCounter++ % itemCounts != 0)
            return TRUE;
    }
    else {
        if (pPvtData->intervalCounter++ % pPubMapUncmpAudioInfo->packingFactor != 0)
            return TRUE;
    }

    int itemProcessed = 0;
    avtp_time_t avtpBaseTime;
    while (itemProcessed < itemCounts) {
        media_q_item_t *pMediaQItem = openavbMediaQHeadLock(pMediaQ);
        int avail = 0;
        size_t copyLen = 0;
        if (pMediaQItem) {
            //openavbAvtpTimeSetToWallTime(pMediaQItem->pAvtpTime);
            if (pPvtData->pBuffer) {
            mt_intf_time_change_tx(pPvtData->ts_type, pPvtData->ptp, pPvtData->pBuffer->timestamp, pMediaQItem->pAvtpTime);
            }
            avail = pMediaQItem->itemSize - pMediaQItem->dataLen;
            while (avail > 0) {
                if (pPvtData->pBuffer) {
                    MT_PRINT_TRACE("Copy data to mediaQ, avail = %d, length = %d, offset = %d", avail, pPvtData->pBuffer->length, pPvtData->pBuffer->offset);
                    copyLen = IAVB_MT_MIN(avail, (pPvtData->pBuffer->length - pPvtData->pBuffer->offset));
                    memcpy((char*)pMediaQItem->pPubData + pMediaQItem->dataLen, (char*)pPvtData->pBuffer->data + pPvtData->pBuffer->offset, copyLen);
#ifdef DUMP_DATA_DEBUG
                    if (dump_tx) {
                        fwrite((char*)pPvtData->pBuffer->data + pPvtData->pBuffer->offset, 1, copyLen, dump_tx);
                    }
#endif
                    pMediaQItem->dataLen += copyLen;
                    pPvtData->pBuffer->offset += copyLen;
                    avail -= copyLen;
                    if (pPvtData->pBuffer->length <= pPvtData->pBuffer->offset) {
                        g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                        pPvtData->pBuffer = NULL;
                    }
                    continue;
                }
                if (0 != g_utils_funcs.acquire(pPvtData->pDq, &(pPvtData->pBuffer), 0)) {
                    MT_PRINT_TRACE("Not enougth data for AVTP");
                    openavbMediaQHeadUnlock(pMediaQ);
                    return FALSE;
                }
                else {
                    mt_intf_time_change_tx(pPvtData->ts_type, pPvtData->ptp, pPvtData->pBuffer->timestamp, pMediaQItem->pAvtpTime);
                }
                // continue to copy data;
            }
            if (itemProcessed == 0) {
                //openavbAvtpTimeSetToWallTime(pMediaQItem->pAvtpTime);
                if (pPvtData->pBuffer) {
                    mt_intf_time_change_tx(pPvtData->ts_type, pPvtData->ptp, pPvtData->pBuffer->timestamp, pMediaQItem->pAvtpTime);
                }
                avtpBaseTime.timeNsec = pMediaQItem->pAvtpTime->timeNsec;
                avtpBaseTime.bTimestampValid = pMediaQItem->pAvtpTime->bTimestampValid;
                avtpBaseTime.bTimestampUncertain = pMediaQItem->pAvtpTime->bTimestampUncertain;
            }
            else {
                pMediaQItem->pAvtpTime->timeNsec = avtpBaseTime.timeNsec + 166000*itemProcessed;
                pMediaQItem->pAvtpTime->bTimestampValid = avtpBaseTime.bTimestampValid;
                pMediaQItem->pAvtpTime->bTimestampUncertain = avtpBaseTime.bTimestampUncertain;
            }
            openavbMediaQHeadPush(pMediaQ);
            ++itemProcessed;
            continue;
        }
        else {
            // MT_PRINT_TRACE("Media queue full");
            return FALSE;    // Media queue full
        }
    }
    return TRUE;
}

static bool iavbAafTxCb(media_q_t *pMediaQ)
{
    if (!pMediaQ) {
        return FALSE;
    }
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;

    if (!pPvtData || !pPvtData->pDq) {
        return FALSE; // Data provider not exist
    }

    media_q_item_t *pMediaQItem = openavbMediaQHeadLock(pMediaQ);
    int avail = 0;
    size_t copyLen = 0;
    if (pMediaQItem) {
        //openavbAvtpTimeSetToWallTime(pMediaQItem->pAvtpTime);
        if (pPvtData->pBuffer) {
        mt_intf_time_change_tx(pPvtData->ts_type, pPvtData->ptp, pPvtData->pBuffer->timestamp, pMediaQItem->pAvtpTime);
        }
        avail = pMediaQItem->itemSize - pMediaQItem->dataLen;
        while (avail > 0) {
            if (pPvtData->pBuffer) {
                MT_PRINT_TRACE("Copy data to mediaQ, avail = %d, length = %d, offset = %d", avail, pPvtData->pBuffer->length, pPvtData->pBuffer->offset);
                copyLen = IAVB_MT_MIN(avail, (pPvtData->pBuffer->length - pPvtData->pBuffer->offset));
                memcpy((char*)pMediaQItem->pPubData + pMediaQItem->dataLen, (char*)pPvtData->pBuffer->data + pPvtData->pBuffer->offset, copyLen);
#ifdef DUMP_DATA_DEBUG
                if (dump_tx) {
                    fwrite((char*)pPvtData->pBuffer->data + pPvtData->pBuffer->offset, 1, copyLen, dump_tx);
                }
#endif
                pMediaQItem->dataLen += copyLen;
                pPvtData->pBuffer->offset += copyLen;
                avail -= copyLen;
                if (pPvtData->pBuffer->length <= pPvtData->pBuffer->offset) {
                    g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                    pPvtData->pBuffer = NULL;
                }
                continue;
            }
            if (0 != g_utils_funcs.acquire(pPvtData->pDq, &(pPvtData->pBuffer), 0)) {
                MT_PRINT_TRACE("Not enougth data for AVTP");
                openavbMediaQHeadUnlock(pMediaQ);
                return FALSE;
            }
            else {
                mt_intf_time_change_tx(pPvtData->ts_type, pPvtData->ptp, pPvtData->pBuffer->timestamp, pMediaQItem->pAvtpTime);
            }
            // continue to copy data;
        }
        openavbMediaQHeadPush(pMediaQ);
        return TRUE;
    }
    else {
        return FALSE;    // Media queue full
    }
}

static bool iavbH264TxCb(media_q_t *pMediaQ)
{
    if (!pMediaQ) {
        return FALSE;
    }
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;

    if (!pPvtData || !pPvtData->pDq) {
        return FALSE; // Data provider not exist
    }
    U8 *pH264Nal;
    U8 nalType;
    U8 *pFuIndicator;
    U8 *pFuHead;
    U32 nalOffset;
    bool startFlag;
    bool marker;
    media_q_item_t *pMediaQItem = openavbMediaQHeadLock(pMediaQ);
    size_t copyLen = 0;
    if (pMediaQItem) {
        if (NULL == pPvtData->pBuffer) {
            if (0 != g_utils_funcs.acquire(pPvtData->pDq, &(pPvtData->pBuffer), 0)) {
                MT_PRINT_TRACE("Not enougth data for AVTP");
                openavbMediaQHeadUnlock(pMediaQ);
                return FALSE;
            }
        }
#ifdef H264NAL_SUPPORT
        startFlag = FALSE;
        marker = FALSE;
        nalType = 0;
        if (0 == pPvtData->pBuffer->offset) {
            // The begin of an NALU
            // h264 NAL start code: '00 00 01' OR '00 00 00 01'
            pH264Nal = (U8*)pPvtData->pBuffer->data;
            if ((pPvtData->pBuffer->length > H264NAL_HEAD_LEN3) && (memcmp(pH264Nal, H264NAL_HEAD3, H264NAL_HEAD_LEN3) == 0)) {
                nalOffset = H264NAL_HEAD_LEN3;
            }
            else if ((pPvtData->pBuffer->length > H264NAL_HEAD_LEN4) && memcmp(pH264Nal, H264NAL_HEAD4, H264NAL_HEAD_LEN4) == 0) {
                nalOffset = H264NAL_HEAD_LEN4;
            }
            else {
                MT_PRINT_ERR("Wrong nal start code");
                openavbMediaQHeadUnlock(pMediaQ);
                g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                pPvtData->pBuffer = NULL;
                return FALSE;
            }
            // NALU First Byte
            // MSB-----------LSB
            // +---------------+
            // |0|1|2|3|4|5|6|7|
            // +-+-+-+-+-+-+-+-+
            // |F|NRI|  Type   |
            // +---------------+
            pH264Nal += nalOffset;
            nalType = *pH264Nal & 0x1f;
            pPvtData->streamPvtData.h264.NalHead = *pH264Nal;
            // Summary of allowed NAL unit types for each packetization
            // mode (yes = allowed, no = disallowed, ig = ignore)

            // Payload Packet    Single NAL    Non-Interleaved    Interleaved
            // Type    Type      Unit Mode           Mode             Mode
            // -------------------------------------------------------------
            // 0      reserved      ig               ig               ig
            // 1-23   NAL unit     yes              yes               no
            // 24     STAP-A        no              yes               no
            // 25     STAP-B        no               no              yes
            // 26     MTAP16        no               no              yes
            // 27     MTAP24        no               no              yes
            // 28     FU-A          no              yes              yes
            // 29     FU-B          no               no              yes
            // 30-31  reserved      ig               ig               ig
            switch (nalType)
            {
            case RTPH264_NAL_TYPE_NON_IDR:
            case RTPH264_NAL_TYPE_SLICE_A:
            case RTPH264_NAL_TYPE_SLICE_B:
            case RTPH264_NAL_TYPE_SLICE_C:
            case RTPH264_NAL_TYPE_IDR:
            case RTPH264_NAL_TYPE_SEI:
                marker = TRUE;
                break;
            case RTPH264_NAL_TYPE_SPS:
            case RTPH264_NAL_TYPE_PPS:
                break;
            // case RTPH264_NAL_TYPE_STAP_A:
            // case RTPH264_NAL_TYPE_STAP_B:
            // case RTPH264_NAL_TYPE_MTAP16:
            // case RTPH264_NAL_TYPE_MTAP24:
                // Single NALU
            case RTPH264_NAL_TYPE_FU_A: // FU-A
            // NAL unit type FU-B MUST be used in the interleaved packetization mode
            // for the first fragmentation unit of a fragmented NAL unit.  NAL unit
            // type FU-B MUST NOT be used in any other case.  In other words, in the
            // interleaved packetization mode, each NALU that is fragmented has an
            // FU-B as the first fragment, followed by one or more FU-A fragments.
            case RTPH264_NAL_TYPE_FU_B: // FU-B
                // FU(Fragmentation Unit) cannot fragment again
                if ((pPvtData->pBuffer->length - nalOffset) > pMediaQItem->itemSize) {
                    MT_PRINT_ERR("FU size overflow [%d]:[%d-%d]>[%d]"
                                    , nalType
                                    , pPvtData->pBuffer->length
                                    , nalOffset
                                    , pMediaQItem->itemSize);
                    openavbMediaQHeadUnlock(pMediaQ);
                    g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                    pPvtData->pBuffer = NULL;
                    return FALSE;
                }
                break;

            default:
                if (nalType > 0 && nalType < 24) {
                    // single NALU, refers to RFC6184 Table above
                    MT_PRINT_INFO("single NALU[%d], refers to RFC6184 Table", nalType);
                }
                else {
                    MT_PRINT_ERR("NAL Type (%d) unsupported", nalType);
                    openavbMediaQHeadUnlock(pMediaQ);
                    g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                    pPvtData->pBuffer = NULL;
                    return FALSE;
                }
                break;
            }
            // Skip NAL start code and NAL header
            pPvtData->pBuffer->offset += (nalOffset + 1);
            pPvtData->streamPvtData.h264.split = ((pPvtData->pBuffer->length - pPvtData->pBuffer->offset) > ((int)(pMediaQItem->itemSize) - 1)) ? TRUE : FALSE;
            startFlag = TRUE;
        }
        if (0 != pMediaQItem->dataLen) {
            MT_PRINT_INFO("MediaQItem is not clean, you may investiage the data processing code, Now we will overwrite them");
        }

        if (pPvtData->streamPvtData.h264.split) {
            // 0                   1                   2                   3
            // 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
            // +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            // | FU indicator  |   FU header   |      DON(FU-B Only)           |
            // +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+                               |
            // |                                                               |
            // |                         FU payload                            |
            // |                                                               |
            // |                               +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            // |                               :...OPTIONAL RTP padding        |
            // +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

            // FU Indicator
            // MSB-----------LSB
            // +---------------+
            // |0|1|2|3|4|5|6|7|
            // +-+-+-+-+-+-+-+-+
            // |F|NRI|  Type   |
            // +---------------+

            // FU Header
            // MSB ----------LSB
            // +-+-+-+-+-+-+-+-+
            // |S|E|R|  Type   |
            // +-+-+-+-+-+-+-+-+
            pFuIndicator = (U8*)pMediaQItem->pPubData;
            pFuHead = (U8*)pMediaQItem->pPubData + 1;

            *pFuIndicator = pPvtData->streamPvtData.h264.NalHead & 0xe0; // copy F,NRI
            *pFuIndicator |= 0x1c; // set Type to FU-A
            *pFuHead = pPvtData->streamPvtData.h264.NalHead & 0x1f; // copy NAL type to FU header type field
            copyLen = IAVB_MT_MIN(((int)(pMediaQItem->itemSize) - 2), (pPvtData->pBuffer->length - pPvtData->pBuffer->offset));
            memcpy(pFuIndicator + 2, (U8*)pPvtData->pBuffer->data + pPvtData->pBuffer->offset, copyLen);

            ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->timestamp = pPvtData->pBuffer->timestamp;
            //openavbAvtpTimeSetToWallTime(pMediaQItem->pAvtpTime);
            mt_intf_time_change_tx(pPvtData->ts_type, pPvtData->ptp, pPvtData->pBuffer->timestamp, pMediaQItem->pAvtpTime);

            pMediaQItem->dataLen += (copyLen + 2);
            pPvtData->pBuffer->offset += copyLen;

            if (pPvtData->pBuffer->length <= pPvtData->pBuffer->offset) {
                // last packet of this H264 frame
                *pFuHead |= 0x40; // set 'E' bit
                ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->lastPacket = TRUE;
                g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                pPvtData->pBuffer = NULL;
            }
            else {
                if (startFlag) {
                    *pFuHead |= 0x80; // set 'S' bit
                }
                ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->lastPacket = FALSE;
            }
        }
        else {
            // Directly copy NALU, include NAL type
            pMediaQItem->dataLen = (pPvtData->pBuffer->length - pPvtData->pBuffer->offset + 1);
            memcpy((U8*)pMediaQItem->pPubData, pH264Nal, pMediaQItem->dataLen);
            ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->lastPacket = marker;
            mt_intf_time_change_tx(pPvtData->ts_type, pPvtData->ptp, pPvtData->pBuffer->timestamp, pMediaQItem->pAvtpTime);
            g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
            pPvtData->pBuffer = NULL;
        }
#else // User defined format
        // MT_PRINT_TRACE("Copy data to mediaQ, avail = %d, length = %d, offset = %d", pMediaQItem->itemSize, pPvtData->pBuffer->length, pPvtData->pBuffer->offset);
        copyLen = IAVB_MT_MIN(pMediaQItem->itemSize, (pPvtData->pBuffer->length - pPvtData->pBuffer->offset));
        memcpy((char*)pMediaQItem->pPubData + pMediaQItem->dataLen, (char*)pPvtData->pBuffer->data + pPvtData->pBuffer->offset, copyLen);
#ifdef DUMP_DATA_DEBUG
        if (dump_tx) {
            fwrite((char*)pPvtData->pBuffer->data + pPvtData->pBuffer->offset, 1, copyLen, dump_tx);
        }
#endif
        ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->timestamp = pPvtData->pBuffer->timestamp;
        //openavbAvtpTimeSetToWallTime(pMediaQItem->pAvtpTime);

        if(pPvtData->pBuffer) {
        mt_intf_time_change_tx(pPvtData->ts_type, pPvtData->ptp, pPvtData->pBuffer->timestamp, pMediaQItem->pAvtpTime);
        }
        pMediaQItem->dataLen += copyLen;
        pPvtData->pBuffer->offset += copyLen;
        if (pPvtData->pBuffer->length <= pPvtData->pBuffer->offset) {
            // last packet of this H264 frame
            ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->lastPacket = TRUE;
            g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
            pPvtData->pBuffer = NULL;
        }
        else {
            ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->lastPacket = FALSE;
        }
#endif
        MT_PRINT_TRACE("iavbH264TxCb, push item, ts=%d[us], avtp_ts=%lld[ns], dataLen=%d[Bytes], mark=%d, NalType=%d"
                        , ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->timestamp
                        , pMediaQItem->pAvtpTime->timeNsec
                        , pMediaQItem->dataLen
                        , ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->lastPacket
                        , nalType);
        openavbMediaQHeadPush(pMediaQ);
        return TRUE;
    }
    else {
        return FALSE;    // Media queue full
    }
}

static bool iavbMjpegTxCb(media_q_t *pMediaQ) {
    if (!pMediaQ) {
        return FALSE;
    }
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;

    if (!pPvtData || !pPvtData->pDq) {
        return FALSE; // Data provider not exist
    }

    media_q_item_t *pMediaQItem = openavbMediaQHeadLock(pMediaQ);

    if (pMediaQItem) {
        if (NULL == pPvtData->pBuffer) {
            if (0 != g_utils_funcs.acquire(pPvtData->pDq, &(pPvtData->pBuffer), 0)) {
                MT_PRINT_TRACE("Not enougth data for AVTP");
                openavbMediaQHeadUnlock(pMediaQ);
                return FALSE;
            }
        }
        MT_PRINT_TRACE("Copy data to mediaQ, avail = %d, length = %d, offset = %d", pMediaQItem->itemSize, pPvtData->pBuffer->length, pPvtData->pBuffer->offset);
        // it means this is a new bunch of fragments
        // only first timestamp need to be taken
        //openavbAvtpTimeSetToWallTime(pMediaQItem->pAvtpTime);
        mt_intf_time_change_tx(pPvtData->ts_type, pPvtData->ptp, pPvtData->pBuffer->timestamp, pMediaQItem->pAvtpTime);

        if (FALSE == mt_jpg_pay(pPvtData->streamPvtData.mjpeg.pkg, pPvtData->pBuffer, pMediaQItem)) {
            MT_PRINT_ERR("jpg format error");
            openavbMediaQHeadUnlock(pMediaQ);
            g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
            pPvtData->pBuffer = NULL;
            return FALSE;
        }
#ifdef DUMP_DATA_DEBUG
        int write_cnt;
        if (dump_tx) {
            write_cnt = fwrite((unsigned char *)pMediaQItem->pPubData, 1, pMediaQItem->dataLen, dump_tx);
        }
#endif
        MT_PRINT_TRACE("pPvtData->pBuffer->length =%d, pPvtData->pBuffer->offset  = %d", pPvtData->pBuffer->length, pPvtData->pBuffer->offset);

        if (pPvtData->pBuffer->length <= pPvtData->pBuffer->offset) {
            MT_PRINT_TRACE("=====last fragment of this Mjpeg frame");
            ((media_q_item_map_mjpeg_pub_data_t *)pMediaQItem->pPubMapData)->lastFragment = TRUE;
            g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
            pPvtData->pBuffer = NULL;
        }
        else {
            ((media_q_item_map_mjpeg_pub_data_t *)pMediaQItem->pPubMapData)->lastFragment = FALSE;
        }
        openavbMediaQHeadPush(pMediaQ);
        return TRUE;
    }
    else {
        return FALSE;	// Media queue full
    }
}

static bool iavbTsTxCb(media_q_t *pMediaQ) {
    size_t avail = 0;
    size_t copyLen = 0;

    if (!pMediaQ) {
        return FALSE;
    }

    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    if (!pPvtData || !pPvtData->pDq) {
        return FALSE; // Data provider not exist
    }

    media_q_item_t *pMediaQItem = openavbMediaQHeadLock(pMediaQ);

    if (pMediaQItem) {
        if (NULL == pPvtData->pBuffer) {
            if (0 != g_utils_funcs.acquire(pPvtData->pDq, &(pPvtData->pBuffer), 0)) {
                MT_PRINT_TRACE("Not enougth data for AVTP");
                openavbMediaQHeadUnlock(pMediaQ);
                return FALSE;
            }
        }
        MT_PRINT_TRACE("Copy data to mediaQ, avail = %d, length = %d, offset = %d", pMediaQItem->itemSize, pPvtData->pBuffer->length, pPvtData->pBuffer->offset);
        mt_intf_time_change_tx(pPvtData->ts_type, pPvtData->ptp, pPvtData->pBuffer->timestamp, pMediaQItem->pAvtpTime);
        avail = pPvtData->pBuffer->length - pPvtData->pBuffer->offset;
        copyLen = IAVB_MT_MIN(avail, (pMediaQItem->itemSize - pMediaQItem->dataLen));
        memcpy((char*)pMediaQItem->pPubData + pMediaQItem->dataLen, (char*)pPvtData->pBuffer->data + pPvtData->pBuffer->offset, copyLen);
#ifdef DUMP_DATA_DEBUG
        if (dump_tx) {
            fwrite((char *)pPvtData->pBuffer->data + pPvtData->pBuffer->offset, 1, copyLen, dump_tx);
        }
#endif
        pMediaQItem->dataLen += copyLen;
        pPvtData->pBuffer->offset += copyLen;
        MT_PRINT_TRACE("pPvtData->pBuffer->length =%d, pPvtData->pBuffer->offset  = %d", pPvtData->pBuffer->length, pPvtData->pBuffer->offset);
        if (pPvtData->pBuffer->length <= pPvtData->pBuffer->offset) {
            g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
            pPvtData->pBuffer = NULL;
        }
        openavbMediaQHeadPush(pMediaQ);
        return TRUE;
    }
    else {
        return FALSE;	// Media queue full
    }
}

// This callback will be called for each AVB transmit interval. Commonly this will be
// 4000 or 8000 times  per second.
bool iavbIntfCommonTxCB(media_q_t *pMediaQ)
{
    // MT_PRINT_TRACE("iavbIntfCommonTxCB Enter");
    g_assert(pMediaQ);
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    bool rlt = false;
    if (!pPvtData || !pPvtData->validPipeline) {
        MT_PRINT_ERR("Invalid pipeline setting or userdata NULL");
        return rlt;
    }
    switch (pPvtData->streamFormat)
    {
    case AVB_STREAM_FORMAT_AAF:
        rlt = iavbAafTxCb(pMediaQ);
        break;
    case AVB_STREAM_FORMAT_H264:
        rlt = iavbH264TxCb(pMediaQ);
        break;
    case AVB_STREAM_FORMAT_MJPEG:
        rlt = iavbMjpegTxCb(pMediaQ);
        break;
    case AVB_STREAM_FORMAT_PCM:
        rlt = iavbPcmTxCb(pMediaQ);
        break;
    case AVB_STREAM_FORMAT_TS:
        rlt = iavbTsTxCb(pMediaQ);
        break;
    default:
        break;
    }
    return rlt;
}

// A call to this callback indicates that this interface module will be
// a listener. Any listener initialization can be done in this function.
void iavbIntfCommonRxInitCB(media_q_t *pMediaQ)
{
    MT_PRINT_DEBUG("iavbIntfCommonRxInitCB");
#ifdef DUMP_DATA_DEBUG
    if (!dump_rx) {
        dump_rx = fopen("./dump_intf_rx.bin", "wb");
}
    if (!dump_rx_mtbuffer) {
        dump_rx_mtbuffer = fopen("./dump_intf_rx_mtbuffer.bin", "wb");
    }
#endif
}

bool iavbPcmRxCb(media_q_t *pMediaQ)
{
    if (!pMediaQ) {
        return FALSE;
    }
    bool moreItems = TRUE;
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    if (!pPvtData) {
        MT_PRINT_ERR("Private interface module data not allocated.");
        return FALSE;
    }
    size_t avail = 0;
    size_t copyLen = 0;
    while (moreItems) {
        media_q_item_t *pMediaQItem = openavbMediaQTailLock(pMediaQ, pPvtData->ignoreTs);
        if (pMediaQItem) {
            if (pPvtData->pBuffer == NULL) {
                if (0 != g_utils_funcs.acquire(pPvtData->pDq, &(pPvtData->pBuffer), 0)) {
                    MT_PRINT_INFO("Not enougth space for AVTP data");
                    openavbMediaQTailUnlock(pMediaQ);
                    break;
                }
            }

            if (!pPvtData->pBuffer) {
                MT_PRINT_INFO("Acquire PCM Buffer Failed, SHAME");
                openavbMediaQTailUnlock(pMediaQ);
                return FALSE;
            }

            avail = pPvtData->pBuffer->size - pPvtData->pBuffer->length;
            MT_PRINT_INFO("Copy data from mediaQ, avail = %d, dataLen = %d, readIdx = %d", avail, pMediaQItem->dataLen, pMediaQItem->readIdx);
            copyLen = IAVB_MT_MIN(avail, (pMediaQItem->dataLen - pMediaQItem->readIdx));
            memcpy((U8*)pPvtData->pBuffer->data + pPvtData->pBuffer->length, (U8*)pMediaQItem->pPubData + pMediaQItem->readIdx, copyLen);
#ifdef DUMP_DATA_DEBUG
            if (dump_rx) {
                fwrite((U8*)pMediaQItem->pPubData + pMediaQItem->readIdx, 1, copyLen, dump_rx);
            }
#endif
            pMediaQItem->readIdx += copyLen;
            pPvtData->pBuffer->length += copyLen;

            if (pPvtData->pBuffer->length >= pPvtData->pBuffer->size) {
                // Buffer full, release it.
                pPvtData->pBuffer->offset = 0;
                mt_intf_time_change_rx(pPvtData->ts_type, pPvtData->ptp, pMediaQItem->pAvtpTime, (U64 *)&(pPvtData->pBuffer->timestamp));
                g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                pPvtData->pBuffer = NULL;
            }
            if (pMediaQItem->readIdx >= pMediaQItem->dataLen) {
                // Read the entire item
                openavbMediaQTailPull(pMediaQ);
            }
            else {
                openavbMediaQTailUnlock(pMediaQ);
            }
        }
        else {
            moreItems = FALSE;
        }
    }
    // if (pPvtData->pBuffer && pPvtData->pBuffer->length > 0) {
    //     pPvtData->pBuffer->offset = 0;
    //     g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
    //     pPvtData->pBuffer = NULL;
    // }
    return TRUE;
}

bool iavbAafRxCb(media_q_t *pMediaQ)
{
    if (!pMediaQ) {
        return FALSE;
    }
    bool moreItems = TRUE;
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    if (!pPvtData) {
        MT_PRINT_ERR("Private interface module data not allocated.");
        return FALSE;
    }
    size_t avail = 0;
    size_t copyLen = 0;
    while (moreItems) {
        media_q_item_t *pMediaQItem = openavbMediaQTailLock(pMediaQ, pPvtData->ignoreTs);
        if (pMediaQItem) {
            if (pPvtData->pBuffer == NULL) {
                if (0 != g_utils_funcs.acquire(pPvtData->pDq, &(pPvtData->pBuffer), 0)) {
                    MT_PRINT_INFO("Not enougth space for AVTP data");
                    openavbMediaQTailUnlock(pMediaQ);
                    break;
                }
            }

            if (!pPvtData->pBuffer) {
                MT_PRINT_INFO("Acquire AAF Buffer Failed, SHAME");
                openavbMediaQTailUnlock(pMediaQ);
                return FALSE;
            }

            avail = pPvtData->pBuffer->size - pPvtData->pBuffer->length;
            MT_PRINT_INFO("Copy data from mediaQ, avail = %d, dataLen = %d, readIdx = %d", avail, pMediaQItem->dataLen, pMediaQItem->readIdx);
            copyLen = IAVB_MT_MIN(avail, (pMediaQItem->dataLen - pMediaQItem->readIdx));
            memcpy((U8*)pPvtData->pBuffer->data + pPvtData->pBuffer->length, (U8*)pMediaQItem->pPubData + pMediaQItem->readIdx, copyLen);
#ifdef DUMP_DATA_DEBUG
            if (dump_rx) {
                fwrite((U8*)pMediaQItem->pPubData + pMediaQItem->readIdx, 1, copyLen, dump_rx);
            }
#endif
            pMediaQItem->readIdx += copyLen;
            pPvtData->pBuffer->length += copyLen;

            if (pPvtData->pBuffer->length >= pPvtData->pBuffer->size) {
                // Buffer full, release it.
                pPvtData->pBuffer->offset = 0;
                mt_intf_time_change_rx(pPvtData->ts_type, pPvtData->ptp, pMediaQItem->pAvtpTime, (U64 *)&(pPvtData->pBuffer->timestamp));
                g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                pPvtData->pBuffer = NULL;
            }
            if (pMediaQItem->readIdx >= pMediaQItem->dataLen) {
                // Read the entire item
                openavbMediaQTailPull(pMediaQ);
            }
            else {
                openavbMediaQTailUnlock(pMediaQ);
            }
        }
        else {
            moreItems = FALSE;
        }
    }
    // if (pPvtData->pBuffer && pPvtData->pBuffer->length > 0) {
    //     pPvtData->pBuffer->offset = 0;
    //     g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
    //     pPvtData->pBuffer = NULL;
    // }
    return TRUE;
}
static bool first_pps = true;
static bool first_sps = true;

bool iavbH264RxCb(media_q_t *pMediaQ)
{
    if (!pMediaQ) {
        return FALSE;
    }
    bool moreItems = TRUE;
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    if (!pPvtData) {
        MT_PRINT_ERR("Private interface module data not allocated.");
        return FALSE;
    }
    size_t avail = 0;
    size_t copyLen = 0;
    U8 *pPayload;
    U8 *pH264Nal;
    U8 nalType;
    U8 *pFuIndicator;
    U8 *pFuHead;
    while (moreItems) {
        media_q_item_t *pMediaQItem = openavbMediaQTailLock(pMediaQ, pPvtData->ignoreTs);
        if (pMediaQItem) {
            if (pPvtData->pBuffer == NULL) {
                if (0 != g_utils_funcs.acquire(pPvtData->pDq, &(pPvtData->pBuffer), 0)) {
                    MT_PRINT_INFO("Not enougth space for AVTP data");
                    openavbMediaQTailUnlock(pMediaQ);
                    break;
                }
            }

            if (!pPvtData->pBuffer) {
                MT_PRINT_INFO("Acquire H264 Buffer Failed, SHAME");
                openavbMediaQTailUnlock(pMediaQ);
                return FALSE;
            }

#ifdef H264NAL_SUPPORT
            avail = pPvtData->pBuffer->size - pPvtData->pBuffer->length;
            pH264Nal = (U8*)pMediaQItem->pPubData;
            nalType = *pH264Nal & 0x1f;
            pPvtData->streamPvtData.h264.split = FALSE;
            switch (nalType)
            {
            case RTPH264_NAL_TYPE_SPS:
                // if (!first_sps) {
                    MT_PRINT_ERR("Not first sps frame, drop it");
                    openavbMediaQTailPull(pMediaQ);
                    return FALSE;
                // }
                // else {
                //     MT_PRINT_ERR("First sps frame, send it");
                //     first_sps = false;
                //     break;
                // }
            case RTPH264_NAL_TYPE_PPS:
                // if (!first_pps) {
                    MT_PRINT_ERR("Not first pps frame, drop it");
                    openavbMediaQTailPull(pMediaQ);
                    return FALSE;
                // }
                // else {
                //     MT_PRINT_ERR("First pps frame, send it");
                //     first_pps = false;
                //     break;
                // }
            case RTPH264_NAL_TYPE_NON_IDR:
                MT_PRINT_ERR("Receive NON_IDR Type");
                break;
            case RTPH264_NAL_TYPE_SLICE_A:
                MT_PRINT_ERR("Receive SLICE_A Type");
                break;
            case RTPH264_NAL_TYPE_SLICE_B:
                MT_PRINT_ERR("Receive SLICE_B Type");
                break;
            case RTPH264_NAL_TYPE_SLICE_C:
                MT_PRINT_ERR("Receive SLICE_C Type");
                break;
            case RTPH264_NAL_TYPE_IDR:
                MT_PRINT_ERR("Receive IDR Type");
                break;
            case RTPH264_NAL_TYPE_SEI:
                MT_PRINT_ERR("Receive SEI Type");
            // case RTPH264_NAL_TYPE_STAP_A:
            // case RTPH264_NAL_TYPE_STAP_B:
            // case RTPH264_NAL_TYPE_MTAP16:
            // case RTPH264_NAL_TYPE_MTAP24:
                // Single NALU
                break;
            case RTPH264_NAL_TYPE_FU_A: // FU-A
            // NAL unit type FU-B MUST be used in the interleaved packetization mode
            // for the first fragmentation unit of a fragmented NAL unit.  NAL unit
            // type FU-B MUST NOT be used in any other case.  In other words, in the
            // interleaved packetization mode, each NALU that is fragmented has an
            // FU-B as the first fragment, followed by one or more FU-A fragments.
            case RTPH264_NAL_TYPE_FU_B:
                pFuIndicator = pH264Nal;
                pFuHead = pFuIndicator + 1;
                pPvtData->streamPvtData.h264.split = TRUE;
                break;
            default:
                if (nalType > 0 && nalType < 24) {
                    // single NALU, refers to RFC6184 Table above
                    MT_PRINT_INFO("Rx Single NALU[%d], refers to RFC6184 Table", nalType);
                }
                else {
                    MT_PRINT_ERR("nal_type(%d) unsupported", nalType);
                    openavbMediaQTailPull(pMediaQ);
                    return FALSE;
                }
            }
            MT_PRINT_ERR("Receive FU_A/FU_B Type");
            pPayload = (U8*)pPvtData->pBuffer->data + pPvtData->pBuffer->offset;
            if (pPvtData->streamPvtData.h264.split) {
                if (0 == pPvtData->pBuffer->offset) {
                    memcpy(pPayload, H264NAL_HEAD3, H264NAL_HEAD_LEN3);
                    pPayload += H264NAL_HEAD_LEN3;
                    *pPayload = (*pFuIndicator & 0xe0) | (*pFuHead & 0x1f);
                    pPayload += H264NAL_NALTYPE_LEN;
                    pPvtData->pBuffer->offset += (H264NAL_NALTYPE_LEN + H264NAL_HEAD_LEN3);
                    pPvtData->pBuffer->length += (H264NAL_NALTYPE_LEN + H264NAL_HEAD_LEN3);
                }
                avail = pPvtData->pBuffer->size - pPvtData->pBuffer->offset;
                // TODO,maybe we should handle the FU-B case
                if (avail < pMediaQItem->dataLen - RTPH264_FUA_HEAD_LEN) {
                    MT_PRINT_ERR("Buffer fragment is too Small to hold a whole H264 frame!!!!!");
                    copyLen = avail;
                }
                else {
                    copyLen = pMediaQItem->dataLen - RTPH264_FUA_HEAD_LEN;
                }

                memcpy(pPayload, pFuIndicator + RTPH264_FUA_HEAD_LEN, copyLen);
                pPvtData->pBuffer->length += copyLen;
                if (((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->lastPacket)
                {
                    pPvtData->pBuffer->timestamp = ((media_q_item_map_h264_pub_data_t*)pMediaQItem->pPubMapData)->timestamp;
                    // TODO here mapintf  recv timestamp use the pMediaQItem->pPubMapData)->timestamp
                    // mt_intf_time_change_rx(pPvtData->ts_type, pPvtData->ptp, pMediaQItem->pAvtpTime, (U64 *)&(pPvtData->pBuffer->timestamp));
                    pPvtData->pBuffer->offset = 0;

                    // acquire buffer fisrt, make sure we have buffer to write one frame
                    // drop the current frame if acquire buffer failed
                    mt_buffer *tmp = NULL;
                    if (0 != g_utils_funcs.acquire(pPvtData->pDq, &tmp, 0)) {
                        MT_PRINT_INFO("Not enougth space for AVTP data, drop this frame[h264]");
                        pPvtData->pBuffer->length = 0;
                        pPvtData->pBuffer->flag |= MT_STREAM_NOT_CONTINUOUS;
                    }
                    else {
#ifdef DUMP_DATA_DEBUG
                        if (dump_rx) {
                            fwrite(pPvtData->pBuffer, 1, pPvtData->pBuffer->length, dump_rx);
                        }
#endif
                        g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                        pPvtData->pBuffer = tmp;
                        pPvtData->pBuffer->flag = 0;
                        pPvtData->pBuffer->length = 0;
                        pPvtData->pBuffer->offset = 0;
                    }
                }
                else {
                    pPvtData->pBuffer->offset += copyLen;
                }
            }
            else {
                if (0 != pPvtData->pBuffer->offset) {
                    MT_PRINT_ERR("Data processing error, check it");
                }

                memcpy(pPayload, H264NAL_HEAD3, H264NAL_HEAD_LEN3);
                pPayload += H264NAL_HEAD_LEN3;
                pPvtData->pBuffer->offset += H264NAL_HEAD_LEN3;
                pPvtData->pBuffer->length += H264NAL_HEAD_LEN3;

                avail = pPvtData->pBuffer->size - pPvtData->pBuffer->offset;
                if (avail < pMediaQItem->dataLen) {
                    MT_PRINT_ERR("Buffer fragment is too Small to hold a whole H264 frame!!!!!");
                    copyLen = avail;
                }
                else {
                    copyLen = pMediaQItem->dataLen;
                }
                memcpy(pPayload, pH264Nal, copyLen);
                pPvtData->pBuffer->length += copyLen;
                pPvtData->pBuffer->offset = 0;
                pPvtData->pBuffer->timestamp = ((media_q_item_map_h264_pub_data_t*)pMediaQItem->pPubMapData)->timestamp;
                // mt_intf_time_change_rx(pPvtData->ts_type, pPvtData->ptp, pMediaQItem->pAvtpTime, (U64 *)&(pPvtData->pBuffer->timestamp));

                // acquire buffer fisrt, make sure we have buffer to write one frame
                // drop the current frame if acquire buffer failed
                mt_buffer *tmp = NULL;
                if (0 != g_utils_funcs.acquire(pPvtData->pDq, &tmp, 0)) {
                    MT_PRINT_INFO("Not enougth space for AVTP data, drop this frame[h264]");
                    pPvtData->pBuffer->length = 0;
                    pPvtData->pBuffer->flag |= MT_STREAM_NOT_CONTINUOUS;
                }
                else {
#ifdef DUMP_DATA_DEBUG
                    if (dump_rx) {
                        fwrite(pPvtData->pBuffer, 1, pPvtData->pBuffer->length, dump_rx);
                    }
#endif
                    g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                    pPvtData->pBuffer = tmp;
                    pPvtData->pBuffer->flag = 0;
                    pPvtData->pBuffer->length = 0;
                    pPvtData->pBuffer->offset = 0;
                }
            }
            openavbMediaQTailPull(pMediaQ);
#else
            avail = pPvtData->pBuffer->size - pPvtData->pBuffer->length;
            MT_PRINT_INFO("Copy data from mediaQ, avail = %d, dataLen = %d, readIdx = %d", avail, pMediaQItem->dataLen, pMediaQItem->readIdx);
            copyLen = IAVB_MT_MIN(avail, (pMediaQItem->dataLen - pMediaQItem->readIdx));
            memcpy(pPvtData->pBuffer->data + pPvtData->pBuffer->length, pMediaQItem->pPubData + pMediaQItem->readIdx, copyLen);
#ifdef DUMP_DATA_DEBUG
            if (dump_rx) {
                fwrite(pMediaQItem->pPubData + pMediaQItem->readIdx, 1, copyLen, dump_rx);
            }
#endif
            pMediaQItem->readIdx += copyLen;
            pPvtData->pBuffer->length += copyLen;

            if (((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->lastPacket) {
                // last packet of a frame, we'v got a frame, release the buffer
                //pPvtData->pBuffer->timestamp = ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->timestamp;
                mt_intf_time_change_rx(pPvtData->ts_type, pPvtData->ptp, pMediaQItem->pAvtpTime, &(pPvtData->pBuffer->timestamp));

                pPvtData->pBuffer->offset = 0;
                g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                pPvtData->pBuffer = NULL;
            }
            else if (pPvtData->pBuffer->length >= pPvtData->pBuffer->size) {
                MT_PRINT_ERR("DQ buffer is full, but we still can't reach the last packet, you may reconsider the mt_buffer size");
                //pPvtData->pBuffer->timestamp = ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->timestamp;
                mt_intf_time_change_rx(pPvtData->ts_type, pPvtData->ptp, pMediaQItem->pAvtpTime, &(pPvtData->pBuffer->timestamp));

                pPvtData->pBuffer->offset = 0;
                g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                pPvtData->pBuffer = NULL;
            }
            else {
                // continue retrieve data from mediaQ
                //pPvtData->pBuffer->timestamp = ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->timestamp;
                mt_intf_time_change_rx(pPvtData->ts_type, pPvtData->ptp, pMediaQItem->pAvtpTime, &(pPvtData->pBuffer->timestamp));
            }

            if (pMediaQItem->readIdx >= pMediaQItem->dataLen) {
                // Read the entire item
                openavbMediaQTailPull(pMediaQ);
            }
            else {
                // Abnormal
                openavbMediaQTailUnlock(pMediaQ);
            }
#endif
        }
        else {
            moreItems = FALSE;
        }
    }
    return TRUE;
}

bool iavbMjpegRxCb(media_q_t *pMediaQ)
{
    if (!pMediaQ) {
        return FALSE;
    }
    bool moreItems = TRUE;
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    if (!pPvtData) {
        MT_PRINT_ERR("Private interface module data not allocated.");
        return FALSE;
    }
    size_t avail = 0;
    size_t copyLen = 0;
    while (moreItems) {
        media_q_item_t *pMediaQItem = openavbMediaQTailLock(pMediaQ, pPvtData->ignoreTs);
        if (pMediaQItem) {
            if (pPvtData->pBuffer == NULL) {
                if (0 != g_utils_funcs.acquire(pPvtData->pDq, &(pPvtData->pBuffer), 0)) {
                    MT_PRINT_INFO("Not enougth space for AVTP data");
                    openavbMediaQTailUnlock(pMediaQ);
                    break;
                }
            }

            if (!pPvtData->pBuffer) {
                MT_PRINT_INFO("Acquire MJPEG Buffer Failed, SHAME");
                openavbMediaQTailUnlock(pMediaQ);
                return FALSE;
            }

            avail = pPvtData->pBuffer->size - pPvtData->pBuffer->length;
            MT_PRINT_TRACE("Copy data from mediaQ, avail = %d, dataLen = %d, readIdx = %d", avail, pMediaQItem->dataLen, pMediaQItem->readIdx);
            copyLen = IAVB_MT_MIN(avail, (pMediaQItem->dataLen - pMediaQItem->readIdx));
            //memcpy((U8*)pPvtData->pBuffer->data + pPvtData->pBuffer->length, (U8*)pMediaQItem->pPubData + pMediaQItem->readIdx, copyLen);
#ifdef DUMP_DATA_DEBUG
            if (dump_rx) {
                fwrite((U8 *)pMediaQItem->pPubData + pMediaQItem->readIdx, 1, pMediaQItem->dataLen - pMediaQItem->readIdx, dump_rx);
            }
#endif
            if (pPvtData->pBuffer->length == 0) {
                //pPvtData->pBuffer->timestamp = openavbAvtpTimeGetAvtpTimestamp(pMediaQItem->pAvtpTime);
                mt_intf_time_change_rx(pPvtData->ts_type, pPvtData->ptp, pMediaQItem->pAvtpTime, (U64 *)&(pPvtData->pBuffer->timestamp));

            }
            else {
                //all fragments should have the same timestamp
                uint64_t fragment_timestamp;
                mt_intf_time_change_rx(pPvtData->ts_type, pPvtData->ptp, pMediaQItem->pAvtpTime, &(fragment_timestamp));
                //long long fragment_timestamp = openavbAvtpTimeGetAvtpTimestamp(pMediaQItem->pAvtpTime);
                if ((U64)(pPvtData->pBuffer->timestamp) != fragment_timestamp) {
                    MT_PRINT_ERR("Mapping is wrong. Fragment timestamp should be %" PRIu32 " instead of %" PRIu32,
                                 pPvtData->pBuffer->timestamp, fragment_timestamp);
                }
            }
            if(FALSE == mt_jpg_depay(pPvtData->streamPvtData.mjpeg.pkg, pPvtData->pBuffer, pMediaQItem)) {
                MT_PRINT_ERR("jpg format error");
                openavbMediaQTailPull(pMediaQ);
                return FALSE;
            }

            if (((media_q_item_map_mjpeg_pub_data_t *)pMediaQItem->pPubMapData)->lastFragment) {
                // last packet of a frame, we'v got a frame, release the buffer
#ifdef DUMP_DATA_DEBUG
                if (dump_rx_mtbuffer) {
                    fwrite((U8 *)pPvtData->pBuffer->data, 1, pPvtData->pBuffer->length, dump_rx_mtbuffer);
                }
#endif
                pPvtData->pBuffer->offset = 0;
                // acquire buffer fisrt, make sure we have buffer to write one frame
                // drop the current frame if acquire buffer failed
                mt_buffer *tmp = NULL;
                if (0 != g_utils_funcs.acquire(pPvtData->pDq, &tmp, 0)) {
                    MT_PRINT_INFO("Not enougth space for AVTP data, drop this frame[mpeg]");
                    pPvtData->pBuffer->length = 0;
                    pPvtData->pBuffer->flag |= MT_STREAM_NOT_CONTINUOUS;
                }
                else {
                    g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                    pPvtData->pBuffer = tmp;
                    pPvtData->pBuffer->flag = 0;
                    pPvtData->pBuffer->length = 0;
                    pPvtData->pBuffer->offset = 0;
                }
            }
            else if (pPvtData->pBuffer->length >= pPvtData->pBuffer->size) {
                MT_PRINT_ERR("DQ buffer is full, but we still can't reach the last fragment, you may reconsider the mt_buffer size");
                pPvtData->pBuffer->offset = 0;
                // acquire buffer fisrt, make sure we have buffer to write one frame
                // drop the current frame if acquire buffer failed
                mt_buffer *tmp = NULL;
                if (0 != g_utils_funcs.acquire(pPvtData->pDq, &tmp, 0)) {
                    MT_PRINT_INFO("Not enougth space for AVTP data, drop this frame[mpeg]");
                    pPvtData->pBuffer->length = 0;
                    pPvtData->pBuffer->flag |= MT_STREAM_NOT_CONTINUOUS;
                }
                else {
                    g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                    pPvtData->pBuffer = tmp;
                    pPvtData->pBuffer->flag = 0;
                    pPvtData->pBuffer->length = 0;
                    pPvtData->pBuffer->offset = 0;
                }
            }
            else {
                // continue retrieve data from mediaQ
            }
            if (pMediaQItem->readIdx >= pMediaQItem->dataLen) {
                // Read the entire item
                openavbMediaQTailPull(pMediaQ);
            }
            else {
                // Abnormal   mtbuffer has not enough sapce to store recv payload or next pbuffer store this mediaq data
                openavbMediaQTailUnlock(pMediaQ);
                return  FALSE;
            }
        }
        else {
            moreItems = FALSE;
        }
    }
    return TRUE;
}

bool iavbTsRxCb(media_q_t *pMediaQ) {
    if (!pMediaQ) {
        return FALSE;
    }
    bool moreItems = TRUE;
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    if (!pPvtData) {
        MT_PRINT_ERR("Private interface module data not allocated.");
        return FALSE;
    }
    size_t avail = 0;
    size_t copyLen = 0;
    while (moreItems) {
        media_q_item_t *pMediaQItem = openavbMediaQTailLock(pMediaQ, pPvtData->ignoreTs);
        if (pMediaQItem) {
            if (pPvtData->pBuffer == NULL) {
                if (0 != g_utils_funcs.acquire(pPvtData->pDq, &(pPvtData->pBuffer), 0)) {
                    MT_PRINT_INFO("Not enougth space for AVTP data");
                    openavbMediaQTailUnlock(pMediaQ);
                    break;
                }
            }

            if (!pPvtData->pBuffer) {
                MT_PRINT_INFO("Acquire PCM Buffer Failed, SHAME");
                openavbMediaQTailUnlock(pMediaQ);
                return FALSE;
            }

            avail = pPvtData->pBuffer->size - pPvtData->pBuffer->length;
            MT_PRINT_TRACE("Copy data from mediaQ, avail = %d, dataLen = %d, readIdx = %d", avail, pMediaQItem->dataLen, pMediaQItem->readIdx);
            copyLen = IAVB_MT_MIN(avail, (pMediaQItem->dataLen - pMediaQItem->readIdx));
            memcpy((U8*)pPvtData->pBuffer->data + pPvtData->pBuffer->length, (U8*)pMediaQItem->pPubData + pMediaQItem->readIdx, copyLen);
#ifdef DUMP_DATA_DEBUG
            if (dump_rx) {
                fwrite((U8*)pMediaQItem->pPubData + pMediaQItem->readIdx, 1, copyLen, dump_rx);
            }
#endif
            pMediaQItem->readIdx += copyLen;
            pPvtData->pBuffer->length += copyLen;

            if (pPvtData->pBuffer->length >= pPvtData->pBuffer->size) {
                // Buffer full, release it.
                pPvtData->pBuffer->offset = 0;
                mt_intf_time_change_rx(pPvtData->ts_type, pPvtData->ptp, pMediaQItem->pAvtpTime, (U64 *)&(pPvtData->pBuffer->timestamp));
                // acquire buffer fisrt, make sure we have buffer to write one frame
                // drop the current frame if acquire buffer failed
                mt_buffer *tmp = NULL;
                if (0 != g_utils_funcs.acquire(pPvtData->pDq, &tmp, 0)) {
                    MT_PRINT_INFO("Not enougth space for AVTP data, drop this package[ts]");
                    pPvtData->pBuffer->length = 0;
                    pPvtData->pBuffer->flag |= MT_STREAM_NOT_CONTINUOUS;
                }
                else {
                    g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
                    pPvtData->pBuffer = tmp;
                    pPvtData->pBuffer->flag = 0;
                    pPvtData->pBuffer->length = 0;
                    pPvtData->pBuffer->offset = 0;
                }
            }
            if (pMediaQItem->readIdx >= pMediaQItem->dataLen) {
                // Read the entire item
                openavbMediaQTailPull(pMediaQ);
            }
            else {
                openavbMediaQTailUnlock(pMediaQ);
            }
        }
        else {
            moreItems = FALSE;
        }
    }
    return TRUE;
}

// This callback is called when acting as a listener.
bool iavbIntfCommonRxCB(media_q_t *pMediaQ)
{
    g_assert(pMediaQ);
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    bool rlt = false;
    if (!pPvtData || !pPvtData->validPipeline) {
        MT_PRINT_ERR("Invalid pipeline setting or userdata NULL");
        return rlt;
    }
    switch (pPvtData->streamFormat)
    {
    case AVB_STREAM_FORMAT_AAF:
        rlt = iavbAafRxCb(pMediaQ);
        break;
    case AVB_STREAM_FORMAT_H264:
        rlt = iavbH264RxCb(pMediaQ);
        break;
    case AVB_STREAM_FORMAT_MJPEG:
        rlt = iavbMjpegRxCb(pMediaQ);
        break;
    case AVB_STREAM_FORMAT_PCM:
        rlt = iavbPcmRxCb(pMediaQ);
        break;
    case AVB_STREAM_FORMAT_TS:
        rlt = iavbTsRxCb(pMediaQ);
        break;
    default:
        break;
    }
    return rlt;

}

// This callback will be called when the interface needs to be closed. All shutdown should
// occur in this function.
void iavbIntfCommonEndCB(media_q_t *pMediaQ)
{
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    if (!pPvtData) {
        MT_PRINT_ERR("Private interface module data not allocated.");
        return;
    }
    MT_PRINT_DEBUG("iavbIntfCommonEndCB");
    mt_gptp_deinit(pPvtData->ptp);
}

void iavbIntfCommonGenEndCB(media_q_t *pMediaQ)
{
    MT_PRINT_DEBUG("iavbIntfCommonGenEndCB");
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    if (!pPvtData) {
        MT_PRINT_ERR("Private interface module data not allocated.");
        return;
    }

    if (pPvtData->pBuffer && pPvtData->pDq) {
        pPvtData->pBuffer->offset = 0;
        g_utils_funcs.release(pPvtData->pDq, &(pPvtData->pBuffer), 0);
        pPvtData->pBuffer = NULL;
    }

    if (pPvtData->pDq) {
        pPvtData->pDq = NULL;
    }
    if(pPvtData->streamFormat == AVB_STREAM_FORMAT_MJPEG) {
        mt_jpg_pack_deinit(pPvtData->streamPvtData.mjpeg.pkg);
    }

#ifdef DUMP_DATA_DEBUG
    if (dump_rx) {
        fclose(dump_rx);
        dump_rx = NULL;
    }
    if (dump_rx_mtbuffer) {
        fclose(dump_rx_mtbuffer);
        dump_rx_mtbuffer = NULL;
    }

    if (dump_tx) {
        fclose(dump_tx);
        dump_tx = NULL;
    }
#endif
}

void iavbIntfCommonSetIOCB(media_q_t *pMediaQ, void *buffer)
{
    MT_PRINT_DEBUG("iavbIntfCommonSetIOCB, IOBuffer:%p", buffer);
    pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;
    if (!pPvtData) {
        MT_PRINT_ERR("Private interface module data not allocated.");
        return;
    }
    pPvtData->pDq = (mt_duplex_queue*)buffer;
    return;
}

// Main initialization entry point into the interface module
extern DLL_EXPORT bool iavbIntfCommonInitialize(media_q_t *pMediaQ, openavb_intf_cb_t *pIntfCB)
{
    if (pMediaQ) {
        pMediaQ->pPvtIntfInfo = calloc(1, sizeof(pvt_data_t));        // Memory freed by the media queue when the media queue is destroyed.

        if (!pMediaQ->pPvtIntfInfo) {
            MT_PRINT_ERR("Unable to allocate memory for AVTP interface module.");
            return FALSE;
        }

        pvt_data_t *pPvtData = pMediaQ->pPvtIntfInfo;

        pIntfCB->intf_cfg_cb = iavbIntfCommonCfgCB;
        pIntfCB->intf_gen_init_cb = iavbIntfCommonGenInitCB;
        pIntfCB->intf_tx_init_cb = iavbIntfCommonTxInitCB;
        pIntfCB->intf_tx_cb = iavbIntfCommonTxCB;
        pIntfCB->intf_rx_init_cb = iavbIntfCommonRxInitCB;
        pIntfCB->intf_rx_cb = iavbIntfCommonRxCB;
        pIntfCB->intf_end_cb = iavbIntfCommonEndCB;
        pIntfCB->intf_gen_end_cb = iavbIntfCommonGenEndCB;
        pIntfCB->intf_set_stream_iobuffer_cb = iavbIntfCommonSetIOCB;

        pPvtData->ignoreTs = TRUE;
        pPvtData->intervalCounter = 0;
        pPvtData->pDq = NULL;
        pPvtData->pBuffer = NULL;
    }
    return TRUE;
}
