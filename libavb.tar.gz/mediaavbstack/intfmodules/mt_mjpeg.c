#include <mt_mjpeg.h>
#include<mt_mjpeg_def.h>
#include <string.h>
#include <mt_debug.h>
#ifdef MT_CATEGERY
#undef MT_CATEGERY
#endif
#define MT_CATEGERY "mt_mjpeg_pack"

static gboolean mt_jpg_frame_info_init(mt_jpg_frame_info *pay) {
    if(!pay) {
        MT_PRINT_ERR("mt_jpg_frame_info *pay = NULL");
        return FALSE;
    }
    pay->quality = DEFAULT_JPEG_QUALITY;
    pay->quant = DEFAULT_JPEG_QUANT;
    pay->type = DEFAULT_JPEG_TYPE;
    pay->width = -1;
    pay->height = -1;
    return TRUE;
    //GST_RTP_BASE_PAYLOAD_PT(pay) = GST_RTP_PAYLOAD_JPEG;
}

void mt_jpg_init_rtp_header(mt_jpg_rtp_hdr_t* h) {
    h->v = 2;
    h->p = 0;
    h->x = 0;
    h->cc = 0;
    h->m = 0;
    h->pt = 26;
    h->seq = 10;
    h->timestamp = 0;
    h->ssrc = 0;
}

//rtp 长度为12字节
static void mt_jpg_ajust_rtp_header(mt_jpg_rtp_hdr_t *rtp_head, gboolean is_last_pkg) {
    //version  //检测丢包的seq
    if (rtp_head->seq == 65535) {
        rtp_head->seq = 0;
    }
    else {
        rtp_head->seq++;
    }
    if (is_last_pkg) {
        rtp_head->m = 1;
    }
    else {
        rtp_head->m = 0;
    }
    //时间戳增加一个增量，采样率9000  帧率
}

//parse the mjpeg width and length
static guint mt_jpg_get_marker_size(const guint8 *data, guint offset) {
    return data[offset] << 8 | data[offset + 1];
}

static mt_jpg_marker_t mt_jpg_scan_marker(const guint8 *data, guint size, guint *offset) {
    while ((data[(*offset)++] != JPEG_MARKER) && ((*offset) < size))
        ;

    if (G_UNLIKELY((*offset) >= size)) {
        return JPEG_MARKER_NOTHING;
    }
    else {
        guint8 marker;
        marker = data[*offset];
        (*offset)++;
        return marker;
    }
}


static gboolean mt_jpg_read_sof(mt_jpg_pack * pkg, const guint8 *data, guint size, guint *offset, mt_jpg_comp_info info[]) {
    guint sof_size, off;
    guint width, height, infolen;
    mt_jpg_comp_info elem;
    gint i, j;

    off = *offset;

    /* we need at least 17 bytes for the SOF */
    if (off + 17 > size)
        goto wrong_size;

    sof_size = mt_jpg_get_marker_size(data, off);
    if (sof_size < 17)
        goto wrong_length;

    *offset += sof_size;

    /* skip size */
    off += 2;

    /* precision should be 8 */
    if (data[off++] != 8)
        goto bad_precision;

    /* read dimensions */
    height = data[off] << 8 | data[off + 1];
    width = data[off + 2] << 8 | data[off + 3];
    off += 4;

    //GST_LOG_OBJECT (pay, "got dimensions %ux%u", height, width);
    if (height == 0) {
        goto invalid_dimension;
    }
    if (height > 2040) {
        //height = 0;
    }
    if (width == 0) {
        goto invalid_dimension;
    }
    if (width > 2040) {
        //width = 0;
    }

    if (height == 0 || width == 0) {
        pkg->pay.height = 0;
        pkg->pay.width = 0;
    }
    else {

        pkg->pay.height = (((height) + 7) & ~7) / 8;
        pkg->pay.width = (((width) + 7) & ~7) / 8;
    }

    /* we only support 3 components */
    if (data[off++] != 3)
        goto bad_components;

    infolen = 0;
    for (i = 0; i < 3; i++) {
        elem.id = data[off++];
        elem.samp = data[off++];
        elem.qt = data[off++];
        // GST_LOG_OBJECT (pay, "got comp %d, samp %02x, qt %d", elem.id, elem.samp,elem.qt);
        /* insertion sort from the last element to the first */
        for (j = infolen; j > 1; j--) {
            if (G_LIKELY(info[j - 1].id < elem.id))
                break;
            info[j] = info[j - 1];
        }
        info[j] = elem;
        infolen++;
    }

    /* see that the components are supported */
    if (info[0].samp == 0x21)
        pkg->pay.type = 0;
    else if (info[0].samp == 0x22)
        pkg->pay.type = 1;
    else
        goto invalid_comp;

    if (!(info[1].samp == 0x11))
        goto invalid_comp;

    if (!(info[2].samp == 0x11))
        goto invalid_comp;

    pkg->sof_found = TRUE;
    return TRUE;

    /* ERRORS */
wrong_size: {
    *offset = size;
    MT_PRINT_ERR("Wrong size %u (needed %u)", size, off + 17);
    return FALSE;
}
wrong_length: {
    *offset = size;
    MT_PRINT_ERR("Wrong SOF length %u", sof_size);
    return FALSE;
}
bad_precision: {
    *offset = size;
    MT_PRINT_ERR("Wrong precision, expecting 8");
    return FALSE;
}
invalid_dimension: {
    *offset = size;
    MT_PRINT_ERR("Wrong dimension, size %ux%u", width, height);
    return FALSE;
}
bad_components: {
    *offset = size;
    MT_PRINT_ERR("Wrong number of components");
    return FALSE;
}
invalid_comp: {
    *offset = size;
    MT_PRINT_ERR("Invalid component");
    return FALSE;
}
}

static gboolean mt_jpg_read_dqt(mt_jpg_pack * pkg, const guint8 *data, guint size, guint * offset, mt_jpg_quant_table tables[]) {
    guint quant_size, tab_size;
    guint8 prec;
    guint8 id;
    guint  off = *offset;

    if (off + 2 > size)
        goto too_small;

    quant_size = mt_jpg_get_marker_size(data, off);
    if (quant_size < 2)
        goto small_quant_size;

    /* clamp to available data */
    if (off + quant_size > size)
        quant_size = size - off;
    *offset += quant_size;
    off += 2;
    quant_size -= 2;

    while (quant_size > 0) {
        /* not enough to read the id */
        if (off + 1 > size)
            break;

        id = data[off] & 0x0f;
        if (id == 15)
            /* invalid id received - corrupt data */
            goto invalid_id;

        prec = (data[off] & 0xf0) >> 4;
        if (prec)
            tab_size = 128;
        else
            tab_size = 64;

        /* there is not enough for the table */
        if (quant_size < tab_size + 1)
            goto no_table;

        //GST_LOG("read quant table %d, tab_size %d, prec %02x", id, tab_size, prec);

        tables[id].size = tab_size;
        tables[id].data = &data[off + 1];

        tab_size += 1;
        quant_size -= tab_size;
        off += tab_size;
    }
    pkg->dqt_found = TRUE;
    return TRUE;
done: {
    pkg->dqt_found = TRUE;
    return TRUE;
}

    /* ERRORS */
too_small: {
    *offset = size;
    MT_PRINT_ERR("not enough data");
    return FALSE;
}
small_quant_size: {
    *offset = size;
    MT_PRINT_ERR("quant_size too small (%u < 2)", quant_size);
    return FALSE;
}

//the conditions below ,listener will make dqt with Q
invalid_id: {
    MT_PRINT_DEBUG("invalid id");
    goto done;
}
no_table: {
    MT_PRINT_DEBUG("not enough data for table (%u < %u)", quant_size, tab_size + 1);
    goto done;
}
}

static gboolean mt_jpg_read_dri(mt_jpg_pack * pkg, const guint8 *data, guint size, guint *offset) {
    guint dri_size, off;

    off = *offset;

    /* we need at least 4 bytes for the DRI */
    if (off + 4 > size)
        goto wrong_size;

    dri_size = mt_jpg_get_marker_size(data, off);
    if (dri_size < 4)
        goto wrong_length;

    *offset += dri_size;
    off += 2;

    pkg->restart_marker_header.restart_interval = g_htons((data[off] << 8) | (data[off + 1]));
    pkg->restart_marker_header.restart_count = g_htons(0xFFFF);
    pkg->pay.type += 64;
    pkg->dri_found = TRUE;
    return pkg->restart_marker_header.restart_interval > 0;

wrong_size: {
    MT_PRINT_ERR("not enough data for DRI");
    *offset = size;
    return FALSE;
}
wrong_length: {
    MT_PRINT_DEBUG("DRI size too small (%u)", dri_size);
    *offset += dri_size;
    return TRUE;
}
}

static void mt_jpg_make_qtables(int Q, unsigned char qtable[128]) {
    gint i;
    guint factor;

    factor = CLAMP(Q, 1, 99);

    if (Q < 50)
        Q = 5000 / factor;
    else
        Q = 200 - factor * 2;

    for (i = 0; i < 64; i++) {
        int lq = (jpeg_luma_quantizer[zigzag[i]] * Q + 50) / 100;
        int cq = (jpeg_chroma_quantizer[zigzag[i]] * Q + 50) / 100;

        /* Limit the quantizers to 1 <= q <= 255 */
        qtable[i] = CLAMP(lq, 1, 255);
        qtable[i + 64] = CLAMP(cq, 1, 255);
    }
}

static guint8 * mt_jpg_make_quant_head(guint8 *p, guint8 *qt, gint size, gint table_no) {
    *p++ = 0xff;
    *p++ = 0xdb;     /* DQT */
    *p++ = 0;        /* length msb */
    *p++ = size + 3; /* length lsb */
    *p++ = table_no;
    memcpy(p, qt, size);

    return (p + size);
}

static guint8 * mt_jpg_make_huffman_head(guint8 *p, const guint8 *codelens, int ncodes,
                  const guint8 *symbols, int nsymbols, int tableNo, int tableClass) {
    *p++ = 0xff;
    *p++ = 0xc4;                  /* DHT */
    *p++ = 0;                     /* length msb */
    *p++ = 3 + ncodes + nsymbols; /* length lsb */
    *p++ = (tableClass << 4) | tableNo;
    memcpy(p, codelens, ncodes);
    p += ncodes;
    memcpy(p, symbols, nsymbols);
    p += nsymbols;

    return (p);
}

static guint8 * mt_jpg_make_dri_head(guint8 *p, guint16 dri) {
    *p++ = 0xff;
    *p++ = 0xdd;       /* DRI */
    *p++ = 0x0;        /* length msb */
    *p++ = 4;          /* length lsb */
    *p++ = dri >> 8;   /* dri msb */
    *p++ = dri & 0xff; /* dri lsb */

    return (p);
}

static guint8* mt_jpg_make_sof_head(guint8 *p, int type, int width, int height) {
    *p++ = 0xff;
    *p++ = 0xc0;        /* SOF */
    *p++ = 0;           /* length msb */
    *p++ = 17;          /* length lsb */
    *p++ = 8;           /* 8-bit precision */
    *p++ = height >> 8; /* height msb */
    *p++ = height;      /* height lsb */
    *p++ = width >> 8;  /* width msb */
    *p++ = width;       /* width lsb */
    *p++ = 3;           /* number of components */
    *p++ = 0;           /* comp 0 */
    if ((type & 0x3f) == 0)
        *p++ = 0x21; /* hsamp = 2, vsamp = 1 */
    else
        *p++ = 0x22; /* hsamp = 2, vsamp = 2 */
    *p++ = 0;        /* quant table 0 */
    *p++ = 1;        /* comp 1 */
    *p++ = 0x11;     /* hsamp = 1, vsamp = 1 */
    *p++ = 1;        /* quant table 1 */
    *p++ = 2;        /* comp 2 */
    *p++ = 0x11;     /* hsamp = 1, vsamp = 1 */
    *p++ = 1;        /* quant table 1 */

    return p;
}

static guint8* mt_jpg_make_sos_head(guint8 *p) {
    *p++ = 0xff;
    *p++ = 0xda; /* SOS */
    *p++ = 0;    /* length msb */
    *p++ = 12;   /* length lsb */
    *p++ = 3;    /* 3 components */
    *p++ = 0;    /* comp 0 */
    *p++ = 0;    /* huffman table 0 */
    *p++ = 1;    /* comp 1 */
    *p++ = 0x11; /* huffman table 1 */
    *p++ = 2;    /* comp 2 */
    *p++ = 0x11; /* huffman table 1 */
    *p++ = 0;    /* first DCT coeff */
    *p++ = 63;   /* last DCT coeff */
    *p++ = 0;    /* sucessive approx. */
    return p;
}
static guint mt_jpg_make_all_head(guint8 *p, int type, int width, int height, guint8 *qt, guint precision, guint16 dri) {
    guint8 *start = p;
    gint size;

    *p++ = 0xff;
    *p++ = 0xd8; /* SOI */

    size = ((precision & 1) ? 128 : 64);
    p = mt_jpg_make_quant_head(p, qt, size, 0);
    qt += size;

    size = ((precision & 2) ? 128 : 64);
    p = mt_jpg_make_quant_head(p, qt, size, 1);
    qt += size;

    if (dri != 0)
    p = mt_jpg_make_dri_head(p, dri);

    p = mt_jpg_make_sof_head(p, type, width, height);

    p = mt_jpg_make_huffman_head(p, lum_dc_codelens,
                          sizeof(lum_dc_codelens), lum_dc_symbols, sizeof(lum_dc_symbols), 0, 0);
    p = mt_jpg_make_huffman_head(p, lum_ac_codelens,
                          sizeof(lum_ac_codelens), lum_ac_symbols, sizeof(lum_ac_symbols), 0, 1);
    p = mt_jpg_make_huffman_head(p, chm_dc_codelens,
                          sizeof(chm_dc_codelens), chm_dc_symbols, sizeof(chm_dc_symbols), 1, 0);
    p = mt_jpg_make_huffman_head(p, chm_ac_codelens,
                          sizeof(chm_ac_codelens), chm_ac_symbols, sizeof(chm_ac_symbols), 1, 1);

    p = mt_jpg_make_sos_head(p);

    return (p - start);
};

static gboolean mt_jpg_pack_update(mt_jpg_pack* pkg) {
    if(!pkg) {
        MT_PRINT_ERR("mt_jpg_pack_update failed");
        return FALSE;
    }

    memset(&(pkg->jpeg_header), 0, sizeof(pkg->jpeg_header));
    memset(&(pkg->quant_header), 0, sizeof(pkg->quant_header));
    memset(&(pkg->restart_marker_header), 0, sizeof(pkg->restart_marker_header));
    mt_jpg_frame_info_init(&(pkg->pay));

    pkg->dqt_found = FALSE;
    pkg->dri_found = FALSE;
    pkg->sof_found = FALSE;
    pkg->sos_found = FALSE;
    pkg->jpeg_marker_info_size = 0;
    pkg->quant_data_size = 0; //dqtheader + dqt data size

    return TRUE;
}

mt_jpg_pack* mt_jpg_pack_init() {
    mt_jpg_pack* pkg = (mt_jpg_pack*)malloc(sizeof(mt_jpg_pack));
    if(!pkg) {
    MT_PRINT_ERR("mt_mjpeg_pack_init failed");
    return NULL;
    }

    pkg->dqt_found = FALSE;
    pkg->dri_found = FALSE;
    pkg->sof_found = FALSE;
    pkg->sos_found = FALSE;
    pkg->jpeg_marker_info_size = 0;
    pkg->quant_data_size = 0; //dqtheader + dqt data size
    memset(&(pkg->jpeg_header), 0, sizeof(pkg->jpeg_header));
    memset(&(pkg->quant_header), 0, sizeof(pkg->quant_header));
    memset(&(pkg->restart_marker_header), 0, sizeof(pkg->restart_marker_header));

    mt_jpg_frame_info_init(&(pkg->pay));

    //send all frames use this rtp head
    mt_jpg_init_rtp_header(&(pkg->rtp_head));
    return pkg;
}

void mt_jpg_pack_deinit(mt_jpg_pack * pkg) {
    if(!pkg) {
        return;
    }
    free(pkg);
    pkg = NULL;
}

gboolean mt_jpg_pay(mt_jpg_pack* pkg, mt_buffer *pBuffer, media_q_item_t *pMediaQItem) {
    int i = 0;
    gint marker; //distinguish the mapinfo
    guint total_size = 0;               //pbuffer relative dest data total size
    guchar *mt_buffer_cpypos = NULL;          //mark the //mt_buffer start to copy pos
    guchar *cpy_pos = NULL;
    guint mt_buffer_cpypos_offset = 0; //mt_buffer_cpypos start read offset
    guint jpeg_marker_info_size = 0;
    int mjpeg_offset = 0;  //per packet use this mjpeg_offset to fill jpeg_header to calculate offset
    gboolean is_last_pkg =  FALSE;

    mt_jpg_comp_info info[3] = {
        { 0, },
    };
    mt_jpg_quant_table tables[15] = {
        { 0, NULL },
    };

    total_size = pBuffer->length;
    cpy_pos = (guchar *)(pMediaQItem->pPubData);

    mt_buffer_cpypos = (guchar *)(pBuffer->data) + pBuffer->offset;
    mt_buffer_cpypos_offset = pBuffer->offset;

    //step 1 parse mjpeg mark info  from pPvtData->pBuffer begin
    if (0 == pBuffer->offset) {
        if(!mt_jpg_pack_update(pkg)) {
            //LOG
            return FALSE;
        }
        while (!pkg->sos_found && (mt_buffer_cpypos_offset < (U32)pBuffer->length)) {
            switch ((marker = mt_jpg_scan_marker(mt_buffer_cpypos, total_size, &mt_buffer_cpypos_offset))) {
            case JPEG_MARKER_NOTHING:
                break;
            case JPEG_MARKER_JFIF:
            case JPEG_MARKER_CMT:
            case JPEG_MARKER_DHT:
            case JPEG_MARKER_H264:
                //if get the marker as shown above then skip
                mt_buffer_cpypos_offset += mt_jpg_get_marker_size(mt_buffer_cpypos, mt_buffer_cpypos_offset);
                break;
            case JPEG_MARKER_SOF:
                //get jpg width and height and conponent
                if (!mt_jpg_read_sof(pkg, mt_buffer_cpypos, total_size, &mt_buffer_cpypos_offset, info)) {
                    goto invalid_format;
                }
                break;
            case JPEG_MARKER_DQT:
                //色度 亮度的量化表
                if(!mt_jpg_read_dqt(pkg, mt_buffer_cpypos, total_size, &mt_buffer_cpypos_offset, tables)) {
                    goto invalid_format;
                }
                break;
            case JPEG_MARKER_SOS:
                //图像数据段 找到了 就相当于找到了一帧
                pkg->sos_found = TRUE;
                mt_buffer_cpypos_offset += mt_jpg_get_marker_size(mt_buffer_cpypos, mt_buffer_cpypos_offset);
                pkg->jpeg_marker_info_size = pBuffer->offset = mt_buffer_cpypos_offset;
                break;
            case JPEG_MARKER_EOI:
                //end of mjpeg
                MT_PRINT_ERR("before the valid [ayload find the end of the mjpeg");
                goto invalid_format;
                break;
            case JPEG_MARKER_SOI:
                //start of mejpeg
                break;
            case JPEG_MARKER_DRI:
                //找到复位间隔 在mjpeg头之后
                if (!mt_jpg_read_dri(pkg, mt_buffer_cpypos, total_size, &mt_buffer_cpypos_offset)) {
                    goto invalid_format;
                }
                break;
            default:
                if (marker == JPEG_MARKER_JPG ||
                    (marker >= JPEG_MARKER_JPG0 && marker <= JPEG_MARKER_JPG13) ||
                    (marker >= JPEG_MARKER_APP0 && marker <= JPEG_MARKER_APP15)) {
                    //skip this mark info
                    mt_buffer_cpypos_offset += mt_jpg_get_marker_size(mt_buffer_cpypos, mt_buffer_cpypos_offset);
                }
                else {
                    MT_PRINT_DEBUG("unhandled mjpeg marker 0x%02x", marker);
                }
                break;
            }
        }
        //a mjpeg frame must have an DQT and data containts (DA)
        if (!pkg->dqt_found || !pkg->sof_found) {
            goto unsupported_jpeg;
        }
        if (pkg->pay.width < 0 || pkg->pay.height < 0) {
            goto no_dimension;
        }

        //till now complete mjpeg frame scan over and save the header spilit this frame to several package

        /* prepare stuff for the jpeg header */

        pkg->jpeg_header.type_spec = 0;
        pkg->jpeg_header.type = pkg->pay.type;
        pkg->jpeg_header.q = pkg->pay.quant;
        pkg->jpeg_header.width = pkg->pay.width;
        pkg->jpeg_header.height = pkg->pay.height;

        if (pkg->pay.quant > 127)
        {
            /* for the Y and U component, look up the quant table and its size. quant
                * tables for U and V should be the same */
            for (i = 0; i < 2; i++) {
                guint qsize;
                guint qt;

                qt = info[i].qt;
                if (qt >= G_N_ELEMENTS(tables))
                    goto invalid_quant;

                qsize = tables[qt].size;
                if (qsize == 0)
                    goto invalid_quant;

                pkg->quant_header.precision |= (qsize == 64 ? 0 : (1 << i));
                pkg->quant_data_size += qsize;
            }
            pkg->quant_header.length = g_htons(pkg->quant_data_size);
            pkg->quant_data_size += sizeof(pkg->quant_header);
        }
    }


    //step 2 copy rtp head and mjpeg head

    //calculate the pack head size ,make sure the package could store the markinfo and frame pay load

    U32 mark_info_size = 0;
    mark_info_size += sizeof(pkg->rtp_head);
    mark_info_size += sizeof(pkg->jpeg_header);
    if(pkg->quant_data_size) {
    mark_info_size += pkg->quant_data_size;
    }

    if(mark_info_size >= pMediaQItem->itemSize) {
        MT_PRINT_ERR("this itemSize is not enough to store markinfo\n");
        return FALSE;
    }
    //copy rtphead
    is_last_pkg = pMediaQItem->itemSize - mark_info_size < (U32)(pBuffer->length - pBuffer->offset) ? 0 : 1;
    mt_jpg_ajust_rtp_header(&(pkg->rtp_head), is_last_pkg);
    memcpy(cpy_pos, &(pkg->rtp_head), sizeof(pkg->rtp_head));
    cpy_pos = cpy_pos + sizeof(pkg->rtp_head);



    //copy mjpeg head
    //default little end if big end  directly pkg->jpeg_header.offset = mjpeg_offset
    mjpeg_offset = pBuffer->offset - pkg->jpeg_marker_info_size;
    pkg->jpeg_header.offset = ((mjpeg_offset & 0x0000FF) << 16) |
                         ((mjpeg_offset & 0xFF0000) >> 16) | (mjpeg_offset & 0x00FF00);

    memcpy(cpy_pos, &(pkg->jpeg_header), sizeof(pkg->jpeg_header));
    cpy_pos += sizeof(pkg->jpeg_header);

    //if there is a dri head copy dri head
    if (pkg->dri_found) {
        memcpy(cpy_pos, &(pkg->restart_marker_header), sizeof(pkg->restart_marker_header));
        cpy_pos += sizeof(pkg->restart_marker_header);
    }

    /* only send quant table with first packet */
    if (pkg->quant_data_size) {
        memcpy(cpy_pos, &(pkg->quant_header), sizeof(pkg->quant_header));
        cpy_pos += sizeof(pkg->quant_header);
        /* copy the quant tables for luma and chrominance */
        for (i = 0; i < 2; i++) {
            guint qsize;
            guint qt;
            qt = info[i].qt;
            qsize = tables[qt].size;
            memcpy(cpy_pos, tables[qt].data, qsize);
            cpy_pos += qsize;
        }
        pkg->quant_data_size = 0;
    }

    int pkg_cpy_len = MIN(pMediaQItem->itemSize - mark_info_size, (U32)(pBuffer->length - pBuffer->offset));
    if (pkg_cpy_len == pBuffer->length - pBuffer->offset) {
        MT_PRINT_TRACE("this is the last packet left_size = %d", pkg_cpy_len);
    }
    memcpy(cpy_pos, (U8 *)(pBuffer->data) + pBuffer->offset, pkg_cpy_len);
    pBuffer->offset += pkg_cpy_len;
    pMediaQItem->dataLen = mark_info_size + pkg_cpy_len;
    return TRUE;
unsupported_jpeg: {
    MT_PRINT_ERR("unsupported_jpeg");
    return FALSE;
}
no_dimension: {
    MT_PRINT_ERR("no_dimension");
    return FALSE;
}
invalid_quant: {
    MT_PRINT_ERR("invalid_quant");
    return FALSE;
}
invalid_format: {
    MT_PRINT_ERR("invalid_format");
    return FALSE;
}
}

gboolean mt_jpg_depay(mt_jpg_pack* pkg, mt_buffer *pBuffer, media_q_item_t *pMediaQItem) {
    gint payload_len, header_len;
    guint8 *payload;
    guint frag_offset;
    gint Q;
    guint type, width, height;
    guint16 dri, precision, length;
    guint8 *qtable;
    guint *buff_offset = 0;

    payload_len = pMediaQItem->dataLen;

    //we can set the min pakage size
    if (payload_len <= 12)
        goto empty_packet;

    payload = pMediaQItem->pPubData;
    header_len = 0;

    //step 1 skip the rtp head
    header_len += sizeof(mt_jpg_rtp_hdr_t);
    payload += sizeof(mt_jpg_rtp_hdr_t);
    payload_len -= sizeof(mt_jpg_rtp_hdr_t);

    //step 2 read the 8Bytes mjpeg head
    /*  0                   1                   2                   3
   *  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
   * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   * | Type-specific |              Fragment Offset                  |
   * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   * |      Type     |       Q       |     Width     |     Height    |
   * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */
    frag_offset = (payload[1] << 16) | (payload[2] << 8) | payload[3];
    type = payload[4];
    Q = payload[5];
    width = payload[6] * 8;
    height = payload[7] * 8;
    if (width == 0 || height == 0) {
    goto invalid_dimension;
    }

    header_len += 8;
    payload += 8;
    payload_len -= 8;

    //step 3 read whether there is a dri
    dri = 0;
    if (type > 63) {
        if (payload_len < 4)
            goto empty_packet;

        /*  0                   1                   2                   3
     *  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
     * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     * |       Restart Interval        |F|L|       Restart Count       |
     * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     */
        dri = (payload[0] << 8) | payload[1];

        payload += 4;
        header_len += 4;
        payload_len -= 4;
    }

    //step 4 if this is the first package of a frame  read the dqt
    if (Q >= 128 && frag_offset == 0) {
        if (payload_len < 4)
            goto empty_packet;

        /*  0                   1                   2                   3
     *  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
     * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     * |      MBZ      |   Precision   |             Length            |
     * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     * |                    Quantization Table Data                    |
     * |                              ...                              |
     * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     */
        precision = payload[1];
        length = (payload[2] << 8) | payload[3];

        if (Q == 255 && length == 0)
            goto empty_packet;

        payload += 4;
        header_len += 4;
        payload_len -= 4;

        if (length > payload_len)
            goto empty_packet;

        if (length > 0)
            qtable = payload;
        // else
        //     qtable = MakeTables(Q, jpeg_luma_quantizer, jpeg_chroma_quantizer);

        payload += length;
        header_len += length;
        payload_len -= length;
    }
    else {
        length = 0;
        qtable = NULL;
        precision = 0;
    }

    //if this is the first package of the frame ,then struct a mjpeg head (with the marker)
    guint8 pkg_head[1024];
    guint8 pkg_qtable[128];
    memset(pkg_head, 0, sizeof(pkg_head));
    memset(pkg_qtable, 0, sizeof(pkg_qtable));
    guint pkg_head_size;
    if (frag_offset == 0) {
        if (length == 0) {
            if (Q < 128)
            {
                /* no quant table, creat a dqt   */
                //if(get one cache qtable)
                //else make a qtable refer to Q
                // qtable = MakeTables(Q, jpeg_luma_quantizer, jpeg_chroma_quantizer);
                //因为没有缓存的qtable  所以根据Q质量银子 make a qtable
                mt_jpg_make_qtables(Q, pkg_qtable);
                qtable = pkg_qtable;
                precision = 0;
            }
            else {
                if (!qtable)
                    goto no_qtable;
            }
        }

        /* I think we can get here with a NULL qtable, so make sure we don't
       go dereferencing it in mt_jpg_make_all_head if we do */
        if (!qtable)
            goto no_qtable;

        /* max header length, should be big enough */
        pkg_head_size = mt_jpg_make_all_head(pkg_head, type, width, height, qtable, precision, dri);
        if (pkg_head_size > (U32)(pBuffer->size - pBuffer->length)) {
            goto too_small_mtbuffer;
        }
        memcpy((guchar *)pBuffer->data + pBuffer->length, pkg_head, pkg_head_size);
        pBuffer->length += pkg_head_size;
    }
    pMediaQItem->readIdx += header_len;
    /* continue copy mjpeg frame data*/
    if (payload_len > (pBuffer->size - pBuffer->length)) {
        goto too_small_mtbuffer;
    }
    memcpy((guchar *)pBuffer->data + pBuffer->length, payload, payload_len);
    pBuffer->length += payload_len;
    pMediaQItem->readIdx += payload_len;
    // if ((ttp mark bit) {
    //     //add an FFD9 mjpeg end
    // }
    return TRUE;
    /* ERRORS */
too_small_mtbuffer: {
    MT_PRINT_ERR("too_small_mtbuffer");
    return FALSE;
}
empty_packet: {
    MT_PRINT_ERR("Empty Payload.");
    return FALSE;
}
invalid_dimension: {
    MT_PRINT_ERR("Invalid Dimension");
    return FALSE;
}
no_qtable: {
    MT_PRINT_ERR("no qtable");
    return FALSE;
}
invalid_packet: {
    MT_PRINT_ERR("invalid packet");
    return FALSE;
}
no_header_packet: {
    MT_PRINT_ERR("discarding data packets received when we have no header");
    return FALSE;
}
}
