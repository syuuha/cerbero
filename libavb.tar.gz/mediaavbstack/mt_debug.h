/**
 * Copyright @ 2013 - 2018 Suntec Software(Shanghai) Co., Ltd.
 * All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are NOT permitted except as agreed by
 * Suntec Software(Shanghai) Co., Ltd.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/**
 * @file mt_plugin_stream.h
 */

#ifndef MT_DEBUG_H
#define MT_DEBUG_H

#include <mt_inc.h>
#include <stdarg.h>

#define MT_PRINT_TRACE(format, ...) mt_print(MT_CATEGERY, MT_LOG_LEVEL_TRACE, format, ##__VA_ARGS__)
#define MT_PRINT_LOG(format, ...) mt_print(MT_CATEGERY, MT_LOG_LEVEL_LOG, format, ##__VA_ARGS__)
#define MT_PRINT_INFO(format, ...) mt_print(MT_CATEGERY, MT_LOG_LEVEL_INFO, format, ##__VA_ARGS__)
#define MT_PRINT_DEBUG(format, ...) mt_print(MT_CATEGERY, MT_LOG_LEVEL_DEBUG, format, ##__VA_ARGS__)
#define MT_PRINT_ERR(format, ...) mt_print(MT_CATEGERY, MT_LOG_LEVEL_ERROR, format, ##__VA_ARGS__)

void mt_print(const char* categery, int level, const char* format, ...);
void mt_printv(const char* categery, int level, const char* format, va_list args);

#endif // MT_DEBUG_H
