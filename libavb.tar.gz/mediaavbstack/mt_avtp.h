#ifndef MT_AVTP_H
#define MT_AVTP_H 1

#include "openavb_platform.h"
#include "openavb_intf_pub.h"
#include "openavb_map_pub.h"
#include "openavb_rawsock.h"
#include "openavb_timestamp.h"

#define MT_ETHERTYPE_AVTP 					0x22F0
#define MT_ETHERTYPE_8021Q 					0x8100
#define MT_ETHERNET_8021Q_OCTETS 			4
#define MT_TS_PACKET_LEN  					188
#define MT_SRC_PACKET_LEN 					192
#define MT_CIP_HEADER_LEN 					8

// Length of Ethernet frame header, with and without 802.1Q tag
#define MT_ETH_HDR_LEN						14
#define MT_ETH_HDR_LEN_VLAN					18

// AVTP Headers
#define MT_AVTP_COMMON_STREAM_DATA_HDR_LEN	24

//#define OPENAVB_AVTP_REPORT_RX_STATS 1
#define MT_OPENAVB_AVTP_REPORT_INTERVAL 	100

typedef struct {
	// These are significant only for RX data
	U32					timestamp;  // delivery timestamp
	bool				bComplete;	// not waiting for more data
#ifdef OPENAVB_AVTP_REPORT_RX_STATS
	U32					rxCnt, lateCnt, earlyCnt;
	U32					maxLate, maxEarly;
	struct timespec		lastTime;
#endif
} avtp_rx_info_t;

typedef struct {
	U8						*data;	// pointer to data
	avtp_rx_info_t			rx;		// re-assembly info
} avtp_info_t;

typedef struct {
	media_q_t 				mediaq;
} avtp_state_t;


/* Info associated with an AVTP stream (RX or TX).
 *
 * The void* handle that is returned to the client
 * really is a pointer to an avtp_stream_t.
 *
 * TODO: This passed around as void * handle can be typed since the avtp_stream_t is
 * now seen by the talker / listern module.
 *
 */
typedef struct
{
	// TX socket?
	bool tx;
	// Interface name
	char* ifname;
	// Number of rawsock buffers
	U16 nbuffers;
	// The rawsock library handle.  Used to send or receive frames.
	void *rawsock;
	// The streamID - in network form
	U8 streamIDnet[8];
	// The destination address for stream
	struct ether_addr dest_addr;
	// The AVTP subtype; it determines the encapsulation
	U8 subtype;
	// Max Transit - value added to current time to get play time
	U64 max_transit_usec;
	// Max frame size
	U16 frameLen;
	// AVTP sequence number
	U8 avtp_sequence_num;
	// Paused state of the stream
	bool bPause;
	// Encapsulation-specific state information
	avtp_state_t state;
	// RX info for data sample currently being received
	avtp_info_t info;
	// Mapping callbacks
	openavb_map_cb_t *pMapCB;
	// Interface callbacks
	openavb_intf_cb_t *pIntfCB;
	// MediaQ
	media_q_t *pMediaQ;
	bool bRxSignalMode;

	// TX frame buffer
	U8* pBuf;
	// Ethernet header length
	U32 ethHdrLen;

	// Timestamp evaluation related
	openavb_timestamp_eval_t tsEval;

	// Stat related
	// RX frames lost
	int nLost;
	// Bytes sent or recieved
	U64 bytes;

} avtp_stream_t;


typedef void (*avtp_listener_callback_fn)(void *pv, avtp_info_t *data);

// tx/rx
openavbRC mt_avtp_tx_init(media_q_t *pMediaQ,
					openavb_map_cb_t *pMapCB,
					openavb_intf_cb_t *pIntfCB,
					char* ifname,
					AVBStreamID_t *streamID,
					U8* destAddr,
					U32 max_transit_usec,
					U32 fwmark,
					U16 vlanID,
					U8  vlanPCP,
					U16 nbuffers,
					void **pStream_out);

openavbRC mt_avtp_tx(void *pv, bool bSend, bool txBlockingInIntf);

openavbRC mt_avtp_rx_init(media_q_t *pMediaQ,
					openavb_map_cb_t *pMapCB,
					openavb_intf_cb_t *pIntfCB,
					char* ifname,
					AVBStreamID_t *streamID,
					U8* destAddr,
					U16 nbuffers,
					bool rxSignalMode,
					void **pStream_out);

openavbRC mt_avtp_rx(void *handle);



void mt_avtp_config_timestamp_ecal(void *handle, U32 tsInterval, U32 reportInterval, bool smoothing, U32 tsMaxJitter, U32 tsMaxDrift);

void mt_avtp_pause(void *handle, bool bPause);

int mt_avtp_tx_buffer_level(void *handle);

int mt_avtp_rx_buffer_level(void *handle);



void mt_avtp_shutdown_talker(void *handle);

void mt_avtp_shutdown_listener(void *handle);

int mt_avtp_lost(void *handle);

U64 mt_avtp_bytes(void *handle);

#endif //AVB_AVTP_H
