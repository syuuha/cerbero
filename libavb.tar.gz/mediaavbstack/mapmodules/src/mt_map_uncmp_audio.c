#include <stdlib.h>
#include <string.h>
#include "openavb_types_pub.h"
#include "openavb_mediaq_pub.h"
#include "openavb_map_pub.h"
#include "mt_map_uncmp_audio_pub.h"
#include <mt_debug.h>
#include <mt_gptp.h>

#ifdef MT_CATEGERY
#undef MT_CATEGERY
#endif
#define MT_CATEGERY "mt_avtp_map_uncmp"
#define LOG_VARX(x, y) x ## y
#define LOG_VAR(x, y) LOG_VARX(x, y)
#define MT_IF_LOG_INTERVAL(x) static U32 LOG_VAR(logOnce,__LINE__) = 0; if (!(LOG_VAR(logOnce,__LINE__)++ % (x)))


// Header sizes
#define MT_AVTP_V0_HEADER_SIZE                  12
#define MT_MAP_HEADER_SIZE                      12
#define MT_CIP_HEADER_SIZE                      8
#define MT_TOTAL_HEADER_SIZE                    (MT_AVTP_V0_HEADER_SIZE + MT_MAP_HEADER_SIZE + MT_CIP_HEADER_SIZE)

#define MT_HIDX_AVTP_VERZERO96                  0       // This mapping does not directly set or read these.
#define MT_HIDX_AVTP_HIDE7_TV1                  1       // - 1 Byte - TV bit (timestamp valid)
#define MT_HIDX_AVTP_HIDE7_TU1                  3       // - 1 Byte - TU bit (timestamp uncertain)
#define MT_HIDX_AVTP_TIMESTAMP32                12      // - 4 bytes    avtp_timestamp
#define MT_HIDX_GATEWAY32                       16      // - 4 bytes    gateway_info
#define MT_HIDX_DATALEN16                       20      // - 2 bytes    stream_data_len (save a pointer for later use)
#define MT_HIDX_TAG2_CHANNEL6                   22      // 6 bit        channel                        = 31 / 0x1F (Native AVB)
#define MT_HIDX_TCODE4_SY4                      23      //  4 bits        tcode                        = 0xA 4 bits        sy (application-specific)    = 0
#define MT_HIDX_CIP2_SID6                       24
#define MT_HIDX_DBS8                            25      // 8 bits        dbs (data block size)        = Same as audio frame size. Sample Size * channels
#define MT_HIDX_FN2_QPC3_SPH1_RSV2              26
#define MT_HIDX_DBC8                            27      // 8 bits        DBC (data block counter)    = counter
#define MT_HIDX_CIP2_FMT6                       28
#define MT_HIDX_FDF5_SFC3                       29
#define MT_HIDX_SYT16                           30

typedef struct {
    /////////////
    // Config data
    /////////////
    // map_nv_item_count
    U32 itemCount;

    // Transmit interval in frames per second. 0 = default for talker class.
    U32 txInterval;

    // A multiple of how many frames of audio to accept in an media queue item and into the AVTP payload above
    //    the minimal needed.
    U32 packingFactor;

    /////////////
    // Variable data
    /////////////
    U32 maxTransitUsec;     // In microseconds

    U8 cip_sfc;

    U32 AM824_label;

    U32 maxPayloadSize;

    // Data block continuity counter
    U8 DBC;

    avb_audio_mcr_t audioMcr;

    mt_gptp * ptp;
} pvt_data_t;

static void x_calculateSizes(media_q_t *pMediaQ) {
    if (pMediaQ) {
        media_q_pub_map_uncmp_audio_info_t *pPubMapInfo = pMediaQ->pPubMapInfo;
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return;
        }

        switch (pPubMapInfo->audioRate) {
            case AVB_AUDIO_RATE_32KHZ:
                pPvtData->cip_sfc = 0;
                pPubMapInfo->sytInterval = 8;
                break;

            case AVB_AUDIO_RATE_44_1KHZ:
                pPvtData->cip_sfc = 1;
                pPubMapInfo->sytInterval = 8;
                break;

            case AVB_AUDIO_RATE_48KHZ:
                pPvtData->cip_sfc = 2;
                pPubMapInfo->sytInterval = 8;
                break;

            case AVB_AUDIO_RATE_88_2KHZ:
                pPvtData->cip_sfc = 3;
                pPubMapInfo->sytInterval = 16;
                break;

            case AVB_AUDIO_RATE_96KHZ:
                pPvtData->cip_sfc = 4;
                pPubMapInfo->sytInterval = 16;
                break;

            case AVB_AUDIO_RATE_176_4KHZ:
                pPvtData->cip_sfc = 5;
                pPubMapInfo->sytInterval = 32;
                break;

            case AVB_AUDIO_RATE_192KHZ:
                pPvtData->cip_sfc = 6;
                pPubMapInfo->sytInterval = 32;
                break;

            default:
                MT_PRINT_ERR("Invalid audio frequency configured: %u", pPubMapInfo->audioRate);
                pPvtData->cip_sfc = 2;
                pPubMapInfo->sytInterval = 8;
                break;
        }

        pPubMapInfo->framesPerPacket = (pPubMapInfo->audioRate / pPvtData->txInterval);
        if (pPubMapInfo->framesPerPacket < 1) {
            pPubMapInfo->framesPerPacket = 1;
        }
        if (pPubMapInfo->audioRate % pPvtData->txInterval != 0) {
            MT_PRINT_DEBUG("audio rate (%d) is not an integer multiple of TX rate (%d). Recommend TX rate of (%d)",
                pPubMapInfo->audioRate, pPvtData->txInterval, pPubMapInfo->audioRate / (pPubMapInfo->framesPerPacket + 1));
            pPubMapInfo->framesPerPacket += 1;
        }

        pPubMapInfo->packingFactor = pPvtData->packingFactor;
        if (pPubMapInfo->packingFactor > 1) {
            // Packing multiple packets of sampling into a media queue item
            pPubMapInfo->framesPerItem = pPubMapInfo->framesPerPacket * pPvtData->packingFactor;
        }
        else {
            // No packing. SYT_INTERVAL is used for media queue item size.
            pPubMapInfo->framesPerItem = pPubMapInfo->sytInterval;
        }
        if (pPubMapInfo->framesPerItem < 1) {
            pPubMapInfo->framesPerItem = 1;
        }

        pPubMapInfo->packetSampleSizeBytes = 4;

        MT_PRINT_DEBUG("Rate:%d", pPubMapInfo->audioRate);
        MT_PRINT_DEBUG("Bits:%d", pPubMapInfo->audioBitDepth);
        MT_PRINT_DEBUG("Channels:%d", pPubMapInfo->audioChannels);
        MT_PRINT_DEBUG("Packet Interval:%d", pPvtData->txInterval);
        MT_PRINT_DEBUG("Frames per packet:%d", pPubMapInfo->framesPerPacket);
        MT_PRINT_DEBUG("Packing Factor:%d", pPvtData->packingFactor);
        MT_PRINT_DEBUG("Frames per MediaQ Item:%d", pPubMapInfo->framesPerItem);
        MT_PRINT_DEBUG("Sample Size Bytes:%d", pPubMapInfo->packetSampleSizeBytes);

        if (pPubMapInfo->audioBitDepth == AVB_AUDIO_BIT_DEPTH_16BIT || pPubMapInfo->audioBitDepth == AVB_AUDIO_BIT_DEPTH_20BIT) {
            // TODO: The 20Bit format was downgraded to 16 bit and therefore 2 bytes
            pPubMapInfo->itemSampleSizeBytes = 2;
        }
        else if (pPubMapInfo->audioBitDepth == AVB_AUDIO_BIT_DEPTH_24BIT) {
            pPubMapInfo->itemSampleSizeBytes = 3;
        }
        else {
            MT_PRINT_ERR("Invalid audio format configured: %u", pPubMapInfo->audioBitDepth);
            pPubMapInfo->itemSampleSizeBytes = 1;
        }

        pPubMapInfo->packetFrameSizeBytes = pPubMapInfo->packetSampleSizeBytes * pPubMapInfo->audioChannels;
        pPubMapInfo->packetAudioDataSizeBytes = pPubMapInfo->framesPerPacket * pPubMapInfo->packetFrameSizeBytes;
        pPvtData->maxPayloadSize = pPubMapInfo->packetAudioDataSizeBytes + MT_TOTAL_HEADER_SIZE;

        pPubMapInfo->itemFrameSizeBytes = pPubMapInfo->itemSampleSizeBytes * pPubMapInfo->audioChannels;
        pPubMapInfo->itemSize = pPubMapInfo->itemFrameSizeBytes * pPubMapInfo->framesPerItem;

        switch (pPubMapInfo->audioBitDepth) {
            case AVB_AUDIO_BIT_DEPTH_16BIT:
                pPvtData->AM824_label = 0x42000000;
                break;

            case AVB_AUDIO_BIT_DEPTH_20BIT:
                MT_PRINT_ERR("20 bit not currently supported. Downgraded to 16 bit.");
                pPvtData->AM824_label = 0x42000000;
                break;

            case AVB_AUDIO_BIT_DEPTH_24BIT:
                pPvtData->AM824_label = 0x40000000;
                break;

            default:
                MT_PRINT_ERR("Invalid audio bit depth configured: %u", pPubMapInfo->audioBitDepth);
                pPvtData->AM824_label = 0x40000000;
                break;
        }

    }

}


// Each configuration name value pair for this mapping will result in this callback being called.
void mt_map_uncmp_cfg_cb(media_q_t *pMediaQ, const char *name, const char *value) {
    if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return;
        }

        if (strcmp(name, "map_nv_item_count") == 0) {
            char *pEnd;
            pPvtData->itemCount = strtol(value, &pEnd, 10);
        }
        else if (strcmp(name, "map_nv_tx_rate") == 0
            || strcmp(name, "map_nv_tx_interval") == 0) {
            char *pEnd;
            pPvtData->txInterval = strtol(value, &pEnd, 10);
        }
        else if (strcmp(name, "map_nv_packing_factor") == 0) {
            char *pEnd;
            pPvtData->packingFactor = strtol(value, &pEnd, 10);
        }
        else if (strcmp(name, "map_nv_audio_mcr") == 0) {
            char *pEnd;
            pPvtData->audioMcr = (avb_audio_mcr_t)strtol(value, &pEnd, 10);
        }
    }

}

U8 mt_map_uncmp_subtype_cb() {
    return 0x00;        // 61883 AVB subtype
}

// Returns the AVTP version used by this mapping
U8 mt_map_uncmp_avtp_version_cb() {
    return 0x00;        // Version 0
}

U16 mt_map_uncmp_max_datasize_cb(media_q_t *pMediaQ) {
    if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return 0;
        }
        return pPvtData->maxPayloadSize;
    }
    return 0;
}

// Returns the intended transmit interval (in frames per second). 0 = default for talker / class.
U32 mt_map_uncmp_transmit_interval_cb(media_q_t *pMediaQ) {
    if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return 0;
        }
        return pPvtData->txInterval;
    }
    return 0;
}

void mt_map_uncmp_geninit_cb(media_q_t *pMediaQ) {
    if (pMediaQ) {
        media_q_pub_map_uncmp_audio_info_t *pPubMapInfo = pMediaQ->pPubMapInfo;
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return;
        }

        pPvtData->ptp = mt_gptp_init();
        x_calculateSizes(pMediaQ);
        openavbMediaQSetSize(pMediaQ, pPvtData->itemCount, pPubMapInfo->itemSize);
    }
}

void openavbMapUncmpAudioAVDECCInitCB(media_q_t *pMediaQ, U16 configIdx, U16 descriptorType, U16 descriptorIdx) {
}

// A call to this callback indicates that this mapping module will be
// a talker. Any talker initialization can be done in this function.
void mt_map_uncmp_tx_init_cb(media_q_t *pMediaQ) {
    // Check the media queue for proper allocations to avoid doing it on each tx callback.
    if (!pMediaQ) {
        MT_PRINT_ERR("Media queue not allocated.");
        return;
    }

    media_q_pub_map_uncmp_audio_info_t *pPubMapInfo = pMediaQ->pPubMapInfo;
    if (!pPubMapInfo) {
        MT_PRINT_ERR("Public mapping module data not allocated.");
        return;
    }

    pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
    if (!pPvtData) {
        MT_PRINT_ERR("Private mapping module data not allocated.");
        return;
    }
}

// This talker callback will be called for each AVB observation interval.
tx_cb_ret_t mt_map_uncmp_tx_cb(media_q_t *pMediaQ, U8 *pData, U32 *dataLen)
{
    media_q_item_t *pMediaQItem = NULL;

    if (!pData || !dataLen) {
        MT_PRINT_ERR("Mapping module data or data length argument incorrect.");
        return TX_CB_RET_PACKET_NOT_READY;
    }

    media_q_pub_map_uncmp_audio_info_t *pPubMapInfo = pMediaQ->pPubMapInfo;
    pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;

    if (*dataLen - MT_TOTAL_HEADER_SIZE < pPubMapInfo->packetAudioDataSizeBytes) {
        MT_PRINT_ERR("Not enough room in packet for audio frames.");
        return TX_CB_RET_PACKET_NOT_READY;
    }

    if (openavbMediaQIsAvailableBytes(pMediaQ, pPubMapInfo->itemFrameSizeBytes * pPubMapInfo->framesPerPacket, TRUE)) {
        U8 *pHdr = pData;
        U8 *pPayload = pData + MT_TOTAL_HEADER_SIZE;

        *(U32 *)(&pHdr[MT_HIDX_AVTP_TIMESTAMP32]) = 0;            // Set later
        *(U32 *)(&pHdr[MT_HIDX_GATEWAY32]) = 0x00000000;
        //pHdr[MT_HIDX_DATALEN16] = 0x00;                    // Set Later
        pHdr[MT_HIDX_TAG2_CHANNEL6] = (1 << 6) | 0x1f;
        pHdr[MT_HIDX_TCODE4_SY4] = (0x0a << 4) | 0;

        // Set the majority of the CIP header now.
        pHdr[MT_HIDX_CIP2_SID6] = (0x00 << 6) | 0x3f;
        pHdr[MT_HIDX_DBS8] = pPubMapInfo->audioChannels;

        pHdr[MT_HIDX_FN2_QPC3_SPH1_RSV2] = (0x00 << 6) | (0x00 << 3) | (0x00 << 2) | 0x00;
        // pHdr[MT_HIDX_DBC8] = 0;                         // Set later
        pHdr[MT_HIDX_CIP2_FMT6] = (0x02 << 6) | 0x10;
        pHdr[MT_HIDX_FDF5_SFC3] = 0x00 << 3 | pPvtData->cip_sfc;
        *(U16 *)(&pHdr[MT_HIDX_SYT16]) = 0xffff;

        U32 framesProcessed = 0;
        U8 *pAVTPDataUnit = pPayload;
        bool timestampSet = FALSE;        // index of the timestamp
        U32 sytInt = pPubMapInfo->sytInterval;
        U8 dbc = pPvtData->DBC;
        while (framesProcessed < pPubMapInfo->framesPerPacket) {
            pMediaQItem = openavbMediaQTailLock(pMediaQ, TRUE);
            if (pMediaQItem && pMediaQItem->pPubData && pMediaQItem->dataLen > 0) {
                U8 *pItemData = (U8 *)pMediaQItem->pPubData + pMediaQItem->readIdx;

                if (pMediaQItem->readIdx == 0) {
                    // Timestamp from the media queue is always associated with the first data point.

                    // PTP walltime already set in the interface module. Just add the max transit time.
                // if (pMediaQItem->pAvtpTime) {
                //     pMediaQItem->pAvtpTime->timeNsec += pPvtData->maxTransitUsec * MT_GPTP_NANOSECONDS_PER_USEC;
                // }

                    // Set timestamp valid flag
                    if (pMediaQItem->pAvtpTime && pMediaQItem->pAvtpTime->bTimestampValid) {
                        pHdr[MT_HIDX_AVTP_HIDE7_TV1] |= 0x01;      // Set
                        pMediaQItem->pAvtpTime->timeNsec += pPvtData->maxTransitUsec * MT_GPTP_NANOSECONDS_PER_USEC;
                    }
                    else {
                        pHdr[MT_HIDX_AVTP_HIDE7_TV1] &= ~0x01;     // Clear
                    }

                    *(U32 *)(&pHdr[MT_HIDX_AVTP_TIMESTAMP32]) = htonl((U32)(pMediaQItem->pAvtpTime->timeNsec & 0x00000000FFFFFFFFL));
                    timestampSet = TRUE;
                    // Set timestamp uncertain flag
                    if (pMediaQItem->pAvtpTime && pMediaQItem->pAvtpTime->bTimestampUncertain) {
                        pHdr[MT_HIDX_AVTP_HIDE7_TU1] |= 0x01;      // Set
                    }
                    else {
                        pHdr[MT_HIDX_AVTP_HIDE7_TU1] &= ~0x01;     // Clear
                    }
                }
                else {
                    if (pMediaQItem->pAvtpTime && pMediaQItem->pAvtpTime->bTimestampUncertain) {
                        pHdr[MT_HIDX_AVTP_HIDE7_TU1] |= 0x01; // Set
                    }
                    else {
                        pHdr[MT_HIDX_AVTP_HIDE7_TU1] &= ~0x01; // Clear
                    }
                }

                while (framesProcessed < pPubMapInfo->framesPerPacket && pMediaQItem->readIdx < pMediaQItem->dataLen) {
                    U32 i1;
                    for (i1 = 0; i1 < pPubMapInfo->audioChannels; i1++) {
                        if (pPubMapInfo->itemSampleSizeBytes == 2) {
                            S32 sample = *(S16 *)pItemData;
                            sample &= 0x0000ffff;
                            sample = sample << 8;
                            sample |= pPvtData->AM824_label;
                            sample = htonl(sample);
                            *(U32 *)(pAVTPDataUnit) = sample;
                            pAVTPDataUnit += 4;
                            pItemData += 2;
                        }
                        else {
                            S32 sample = *(S32 *)pItemData;
                            sample &= 0x00ffffff;
                            sample |= pPvtData->AM824_label;
                            sample = htonl(sample);
                            *(U32 *)(pAVTPDataUnit) = sample;
                            pAVTPDataUnit += 4;
                            pItemData += 3;
                        }
                    }
                    framesProcessed++;
                    dbc++;
                    pMediaQItem->readIdx += pPubMapInfo->itemFrameSizeBytes;
                }

                if (pMediaQItem->readIdx >= pMediaQItem->dataLen) {
                    // Read the entire item
                    openavbMediaQTailPull(pMediaQ);
                }
                else {
                    // More to read next interval
                    openavbMediaQTailUnlock(pMediaQ);
                }
            }
            else {
                openavbMediaQTailPull(pMediaQ);
            }
        }

        // Check if timestamp was set
        if (!timestampSet) {
            // Timestamp wasn't set so mark it as invalid
            pHdr[MT_HIDX_AVTP_HIDE7_TV1] &= ~0x01;
        }

        // Set the block continutity and data length
        pHdr[MT_HIDX_DBC8] = pPvtData->DBC;
        pPvtData->DBC = dbc;

        *(U16 *)(&pHdr[MT_HIDX_DATALEN16]) = htons((pPubMapInfo->framesPerPacket * pPubMapInfo->packetFrameSizeBytes) + MT_CIP_HEADER_SIZE);

        // Set out bound data length (entire packet length)
        *dataLen = (pPubMapInfo->framesPerPacket * pPubMapInfo->packetFrameSizeBytes) + MT_TOTAL_HEADER_SIZE;
        return TX_CB_RET_PACKET_READY;

    }
    return TX_CB_RET_PACKET_NOT_READY;
}

// A call to this callback indicates that this mapping module will be
// a listener. Any listener initialization can be done in this function.
void mt_map_uncmp_rx_init_cb(media_q_t *pMediaQ) {
}

// This callback occurs when running as a listener and data is available.
bool mt_map_uncmp_rx_cb(media_q_t *pMediaQ, U8 *pData, U32 dataLen) {
    if (pMediaQ && pData) {
        U8 *pHdr = pData;
        U8 *pPayload = pData + MT_TOTAL_HEADER_SIZE;
        media_q_pub_map_uncmp_audio_info_t *pPubMapInfo = pMediaQ->pPubMapInfo;

        //pHdr[MT_HIDX_AVTP_TIMESTAMP32];
        //pHdr[MT_HIDX_GATEWAY32];
        U16 payloadLen = ntohs(*(U16 *)(&pHdr[MT_HIDX_DATALEN16]));

        //pHdr[MT_HIDX_TAG2_CHANNEL6];
        //pHdr[MT_HIDX_TCODE4_SY4];
        //pHdr[MT_HIDX_CIP2_SID6];
        //pHdr[MT_HIDX_DBS8];
        //pHdr[MT_HIDX_FN2_QPC3_SPH1_RSV2];
        U8 dbc = pHdr[MT_HIDX_DBC8];
        //pHdr[MT_HIDX_CIP2_FMT6];
        //pHdr[HIDX_TSF1_RESA7];
        //pHdr[HIDX_RESB8];
        //pHdr[HIDX_RESC8];
        bool tsValid = (pHdr[MT_HIDX_AVTP_HIDE7_TV1] & 0x01) ? TRUE : FALSE;
        bool tsUncertain = (pHdr[MT_HIDX_AVTP_HIDE7_TU1] & 0x01) ? TRUE : FALSE;

        // Per iec61883-6 Secion 7.2
        // index = mod((SYT_INTERVAL - mod(DBC, SYT_INTERVAL)), SYT_INTERVAL)
        // U8 dbcIdx = (pPubMapInfo->sytInterval - (dbc % pPubMapInfo->sytInterval)) % pPubMapInfo->sytInterval;
        // The dbcIdx calculation isn't used from spec because our implmentation only needs to know when the timestamp index is at 0.
        U8 dbcIdx = dbc % pPubMapInfo->sytInterval;
        U8 *pAVTPDataUnit = pPayload;
        U8 *pAVTPDataUnitEnd = pData + MT_AVTP_V0_HEADER_SIZE + MT_MAP_HEADER_SIZE + payloadLen;


        // timespec_t tmNow;
        // CLOCK_GETTIME(OPENAVB_CLOCK_WALLTIME, &tmNow);
        // U64 nsNow = ((U64)tmNow.tv_sec * (U64)NANOSECONDS_PER_SECOND) + (U64)tmNow.tv_nsec;
        // AVB_LOGF_DEBUG("mt_map_uncmp_rx_cb package ts = %u, nsNow = %lld", ntohl(*(U32 *)(&pHdr[MT_HIDX_AVTP_TIMESTAMP32])), nsNow);

        while (((pAVTPDataUnit + pPubMapInfo->packetFrameSizeBytes) <= pAVTPDataUnitEnd)) {
            // Get item pointer in media queue
            media_q_item_t *pMediaQItem = openavbMediaQHeadLock(pMediaQ);
            if (pMediaQItem) {

                U32 itemSizeWritten = 0;
                U8 *pItemData = (U8 *)pMediaQItem->pPubData + pMediaQItem->dataLen;
                U8 *pItemDataEnd = (U8 *)pMediaQItem->pPubData + pMediaQItem->itemSize;

                // Get the timestamp
                U32 timestamp = ntohl(*(U32 *)(&pHdr[MT_HIDX_AVTP_TIMESTAMP32]));
                pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
                if ((pPvtData->audioMcr != AVB_MCR_NONE) && tsValid && !tsUncertain) {
                    // MCR mode set and timestamp is valid, and timestamp uncertain is not set
                    openavbAvtpTimePushMCR(pMediaQItem->pAvtpTime, timestamp);
                }

                if (pMediaQItem->dataLen == 0) {
                    // This is the first set of frames for the media queue item, must align based on SYT_INTERVAL for proper synchronization of listeners
                    if (dbcIdx > 0 && pAVTPDataUnit == pPayload) {
                        // Failed to make alignment with this packet. This AVTP packet will be tossed. Once alignment is reached
                        // it is expected not to need to toss packets anymore.
                        MT_PRINT_ERR("Failed to make alignment with this packet. DBC=%02X, dbcIdx=%02x, itemSize=%d", dbc, dbcIdx, pMediaQItem->itemSize);
                        openavbMediaQHeadUnlock(pMediaQ);
                        return TRUE;
                    }

                    // Set time stamp info on first data write to the media queue
                    // place it in the media queue item.
                    //openavbAvtpTimeSetToTimestamp(pMediaQItem->pAvtpTime, timestamp);
                    if (pMediaQItem->pAvtpTime) {
                        mt_time_set_to_ts(pPvtData->ptp, &(pMediaQItem->pAvtpTime->timeNsec), timestamp);
                    }

                    // Set timestamp valid and timestamp uncertain flags
                    openavbAvtpTimeSetTimestampValid(pMediaQItem->pAvtpTime, tsValid);
                    openavbAvtpTimeSetTimestampUncertain(pMediaQItem->pAvtpTime, tsUncertain);
                    if (pMediaQItem->pAvtpTime) {
                        pMediaQItem->pAvtpTime->bTimestampValid = tsValid;
                        pMediaQItem->pAvtpTime->bTimestampUncertain = tsUncertain;
                    }
                }

                while (((pAVTPDataUnit + pPubMapInfo->packetFrameSizeBytes) <= pAVTPDataUnitEnd) && ((pItemData + pPubMapInfo->itemFrameSizeBytes) <= pItemDataEnd)) {
                    U32 i1;
                    for (i1 = 0; i1 < pPubMapInfo->audioChannels; i1++) {
                        if (pPubMapInfo->itemSampleSizeBytes == 2) {
                            S32 sample = ntohl(*(S32 *)pAVTPDataUnit);
                            sample = sample * 1;
                            *(S16 *)(pItemData) = (sample & 0x00ffffff) >> 8;
                            pAVTPDataUnit += 4;
                            pItemData += 2;
                            itemSizeWritten += 2;
                        }
                        else {
                            S32 sample = ntohl(*(S32 *)pAVTPDataUnit);
                            sample = sample * 1;
                            *(S32 *)(pItemData) = sample & 0x00ffffff;
                            pAVTPDataUnit += 4;
                            pItemData += 3;
                            itemSizeWritten += 3;
                        }
                    }
                }

                pMediaQItem->dataLen += itemSizeWritten;

                if (pMediaQItem->dataLen < pMediaQItem->itemSize) {
                    // More data can be written to the item
                    openavbMediaQHeadUnlock(pMediaQ);
                }
                else {
                    // The item is full push it.
                    openavbMediaQHeadPush(pMediaQ);
                }

                // AVB_TRACE_EXIT(AVB_TRACE_MAP_DETAIL);
                // return TRUE;    // Normal exit
            }
            else {
                MT_IF_LOG_INTERVAL(1000) MT_PRINT_ERR("Media queue full");
                return FALSE;   // Media queue full
            }
        }
        return TRUE;    // Normal exit
    }
    return FALSE;
}

// This callback will be called when the mapping module needs to be closed.
// All cleanup should occur in this function.
void mt_map_uncmp_end_cb(media_q_t *pMediaQ) {
}

void mt_map_uncmp_genend_cb(media_q_t *pMediaQ) {
        if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return;
        }
        mt_gptp_deinit(pPvtData->ptp);
    }
}

// Initialization entry point into the mapping module. Will need to be included in the .ini file.
extern DLL_EXPORT bool openavbMapUncmpAudioInitialize(media_q_t *pMediaQ, openavb_map_cb_t *pMapCB, U32 inMaxTransitUsec) {
    if (pMediaQ) {
        pMediaQ->pMediaQDataFormat = strdup(MapUncmpAudioMediaQDataFormat);
        pMediaQ->pPubMapInfo = calloc(1, sizeof(media_q_pub_map_uncmp_audio_info_t));       // Memory freed by the media queue when the media queue is destroyed.
        pMediaQ->pPvtMapInfo = calloc(1, sizeof(pvt_data_t));                               // Memory freed by the media queue when the media queue is destroyed.

        if (!pMediaQ->pMediaQDataFormat || !pMediaQ->pPubMapInfo || !pMediaQ->pPvtMapInfo) {
            MT_PRINT_ERR("Unable to allocate memory for mapping module.");
            return FALSE;
        }

        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;

        pMapCB->map_cfg_cb = mt_map_uncmp_cfg_cb;
        pMapCB->map_subtype_cb = mt_map_uncmp_subtype_cb;
        pMapCB->map_avtp_version_cb = mt_map_uncmp_avtp_version_cb;
        pMapCB->map_max_data_size_cb = mt_map_uncmp_max_datasize_cb; //return value maybe invalid
        pMapCB->map_transmit_interval_cb = mt_map_uncmp_transmit_interval_cb;
        pMapCB->map_gen_init_cb = mt_map_uncmp_geninit_cb;
        pMapCB->map_tx_init_cb = mt_map_uncmp_tx_init_cb;
        pMapCB->map_tx_cb = mt_map_uncmp_tx_cb;
        pMapCB->map_rx_init_cb = mt_map_uncmp_rx_init_cb;
        pMapCB->map_rx_cb = mt_map_uncmp_rx_cb;
        pMapCB->map_end_cb = mt_map_uncmp_end_cb;
        pMapCB->map_gen_end_cb = mt_map_uncmp_genend_cb;

        pPvtData->itemCount = 20;
        pPvtData->txInterval = 0;
        pPvtData->packingFactor = 1;
        pPvtData->maxTransitUsec = inMaxTransitUsec;
        pPvtData->DBC = 0;
        pPvtData->audioMcr = AVB_MCR_NONE;

        openavbMediaQSetMaxLatency(pMediaQ, inMaxTransitUsec);
    }

    return TRUE;
}
