#include <stdlib.h>
#include <string.h>
#include "openavb_types_pub.h"
#include "openavb_mediaq_pub.h"
#include "openavb_map_pub.h"
#include <mt_map_mjpeg_pub.h>
#include <mt_debug.h>
#include <mt_gptp.h>

#ifdef MT_CATEGERY
#undef MT_CATEGERY
#endif
#define MT_CATEGERY "mt_avtp_map_mjpeg"
#define LOG_VARX(x, y) x ## y
#define LOG_VAR(x, y) LOG_VARX(x, y)
#define MT_IF_LOG_INTERVAL(x) static U32 LOG_VAR(logOnce,__LINE__) = 0; if (!(LOG_VAR(logOnce,__LINE__)++ % (x)))

#define MT_MTU_SIZE                             1500
// Header sizes
#define MT_AVTP_V0_HEADER_SIZE                  12
#define MT_MAP_HEADER_SIZE                      12
#define MT_TOTAL_HEADER_SIZE                    (MT_AVTP_V0_HEADER_SIZE + MT_MAP_HEADER_SIZE)

// MJPEG Payload is a JPEG fragment per packet plus its headers
#define MT_MAX_JPEG_PAYLOAD_SIZE                (MT_MTU_SIZE -  MT_TOTAL_HEADER_SIZE )
#define MT_MAX_DATA_SIZE                        (MT_MAX_JPEG_PAYLOAD_SIZE + MT_TOTAL_HEADER_SIZE);
#define MT_ITEM_SIZE                            MT_MAX_JPEG_PAYLOAD_SIZE

//below macro represent the head bit
// This mapping does not directly set or read these.
#define MT_HIDX_AVTP_VERZERO96                  0
#define MT_HIDX_AVTP_HIDE7_TV1                  1        // - 1 Byte - TV bit (timestamp valid)
#define MT_HIDX_AVTP_HIDE7_TU1                  3       // - 1 Byte - TU bit (timestamp uncertain)
#define MT_HIDX_AVTP_TIMESTAMP32                12      // - 4 bytes    avtp_timestamp
#define MT_HIDX_FORMAT8                         16      // - 1 bytes    Format information             = 0x02 RTP Video
#define MT_HIDX_FORMAT_SUBTYPE8                 17      // - 1 byte     Format subtype                = 0x00
#define MT_HIDX_RESV16                          18      // - 2 bytes    Reserved                    = binary 0x0000
#define MT_HIDX_STREAM_DATA_LEN16               20     // - 2 bytes    Stream data length
#define MT_HIDX_M11_M01_EVT2_RESV2              22      //set last frame flag
#define MT_HIDX_RESV8                           23     // - 1 byte        Reserved                    = binary 0x00


typedef struct {
    /////////////
    // Config data
    /////////////
    // map_nv_item_count
    U32 itemCount;

    // Transmit interval in frames per second. 0 = default for talker class.
    U32 txInterval;

    /////////////
    // Variable data
    /////////////
    U32 maxTransitUsec;     // In microseconds

    U32 timestamp;

    bool tsvalid;

    mt_gptp * ptp;
} pvt_data_t;



// Each configuration name value pair for this mapping will result in this callback being called.
void mt_map_mjpeg_cfg_cb(media_q_t *pMediaQ, const char *name, const char *value) {
    if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return;
        }

        if (strcmp(name, "map_nv_item_count") == 0) {
            char *pEnd;
            pPvtData->itemCount = strtol(value, &pEnd, 10);
        }
        else if (strcmp(name, "map_nv_tx_rate") == 0
            || strcmp(name, "map_nv_tx_interval") == 0) {
            char *pEnd;
            pPvtData->txInterval = strtol(value, &pEnd, 10);
        }
    }
}

U8 mt_map_mjpeg_subtype_cb() {
    return 0x03;        // AVTP Video subtype
}

// Returns the AVTP version used by this mapping
U8 mt_map_mjpeg_avtp_version_cb() {
    return 0x00;        // Version 0
}

U16 mt_map_mjpeg_max_datasize_cb(media_q_t *pMediaQ) {
    return MT_MAX_DATA_SIZE;
}

// Returns the intended transmit interval (in frames per second). 0 = default for talker / class.
U32 mt_map_mjpeg_transmit_interval_cb(media_q_t *pMediaQ) {
    if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return 0;
        }
        return pPvtData->txInterval;
    }
    return 0;
}

void mt_map_mjpeg_geninit_cb(media_q_t *pMediaQ) {
    if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return;
        }

        pPvtData->timestamp = 0;
        pPvtData->tsvalid = FALSE;
        pPvtData->ptp = mt_gptp_init();
        openavbMediaQSetSize(pMediaQ, pPvtData->itemCount, MT_ITEM_SIZE);
        openavbMediaQAllocItemMapData(pMediaQ, sizeof(media_q_item_map_mjpeg_pub_data_t), 0);
    }
}

// A call to this callback indicates that this mapping module will be
// a talker. Any talker initialization can be done in this function.
void mt_map_mjpeg_tx_init_cb(media_q_t *pMediaQ){
}

// This talker callback will be called for each AVB observation interval.
tx_cb_ret_t mt_map_mjpeg_tx_cb(media_q_t *pMediaQ, U8 *pData, U32 *dataLen) {
    if (pMediaQ && pData && dataLen) {
        U8 *pHdr = pData;
        U8 *pPayload = pData + MT_TOTAL_HEADER_SIZE;
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return TX_CB_RET_PACKET_NOT_READY;
        }

		*(U32 *)(&pHdr[MT_HIDX_AVTP_TIMESTAMP32]) = 0;
        pHdr[MT_HIDX_FORMAT8] = 0x02;                          // RTP Payload type
        *(U16 *)(&pHdr[MT_HIDX_FORMAT_SUBTYPE8]) = 0x00;       // MJPEG format (RFC 2435)
                                                            //pHdr[MT_HIDX_STREAM_DATA_LEN16] = 0x00;                // Set later
        pHdr[MT_HIDX_RESV16] = 0x00;
        pHdr[MT_HIDX_RESV16+1] = 0x00;
        pHdr[MT_HIDX_M11_M01_EVT2_RESV2] = 0x00;
        pHdr[MT_HIDX_RESV8] = 0x00;

        media_q_item_t *pMediaQItem = openavbMediaQTailLock(pMediaQ, TRUE);
        if (pMediaQItem) {
            if (pMediaQItem->dataLen > 0) {
                if (pMediaQItem->dataLen > MT_ITEM_SIZE) {
                    MT_PRINT_ERR("Media queue data item size too large. Reported size: %d  Max Size: %d", pMediaQItem->dataLen, MT_ITEM_SIZE);
                    openavbMediaQTailPull(pMediaQ);
                    return TX_CB_RET_PACKET_NOT_READY;
                }
                // PTP walltime already set in the interface module. Just add the max transit time.
                // Set timestamp valid flag
                if (pMediaQItem->pAvtpTime && pMediaQItem->pAvtpTime->bTimestampValid) {
                    pHdr[MT_HIDX_AVTP_HIDE7_TV1] |= 0x01;      // Set
                    pMediaQItem->pAvtpTime->timeNsec += pPvtData->maxTransitUsec * MT_GPTP_NANOSECONDS_PER_USEC;
                }
                else {
                    pHdr[MT_HIDX_AVTP_HIDE7_TV1] &= ~0x01;     // Clear
                }

                // Set timestamp uncertain flag
                if (pMediaQItem->pAvtpTime && pMediaQItem->pAvtpTime->bTimestampUncertain) {
                    pHdr[MT_HIDX_AVTP_HIDE7_TU1] |= 0x01;      // Set
                }
                else {
                    pHdr[MT_HIDX_AVTP_HIDE7_TU1] &= ~0x01;     // Clear
                }

                // Set the timestamp.
                // 1722a-D6: The avtp_timestamp represents the presentation time associated with the given frame. The same avtp_timestamp
                // shall appear in each fragment of a given frame. The M0 marker bit shall be set in the last packet of a frame.
                if (!pPvtData->tsvalid  && pMediaQItem->pAvtpTime)
                {
                    pPvtData->timestamp = (U32)(pMediaQItem->pAvtpTime->timeNsec & 0x00000000FFFFFFFFL);
                    pPvtData->tsvalid = TRUE;
                }
                *(U32 *)(&pHdr[MT_HIDX_AVTP_TIMESTAMP32]) = htonl(pPvtData->timestamp);

                if (((media_q_item_map_mjpeg_pub_data_t *)pMediaQItem->pPubMapData)->lastFragment) {
                    pHdr[MT_HIDX_M11_M01_EVT2_RESV2] = 0x00 | (1 << 4);
                    pPvtData->tsvalid = FALSE;
                }
                else {
                    pHdr[MT_HIDX_M11_M01_EVT2_RESV2] = 0x00;
                }

                // Copy the JPEG fragment into the outgoing avtp packet.
                memcpy(pPayload, pMediaQItem->pPubData, pMediaQItem->dataLen);
                *(U16 *)(&pHdr[MT_HIDX_STREAM_DATA_LEN16]) = htons(pMediaQItem->dataLen);

                // Set out bound data length (entire packet length)
                *dataLen = pMediaQItem->dataLen + MT_TOTAL_HEADER_SIZE;
                openavbMediaQTailPull(pMediaQ);
                return TX_CB_RET_PACKET_READY;
            }
            openavbMediaQTailPull(pMediaQ);
        }
    }
    if (dataLen) {
        // Set out bound data length (entire packet length)
        *dataLen = 0;
    }
    return TX_CB_RET_PACKET_NOT_READY;
}

// A call to this callback indicates that this mapping module will be
// a listener. Any listener initialization can be done in this function.
void mt_map_mjpeg_rx_init_cb(media_q_t *pMediaQ) {
}

// This callback occurs when running as a listener and data is available.
bool mt_map_mjpeg_rx_cb(media_q_t *pMediaQ, U8 *pData, U32 dataLen) {
    if (pMediaQ && pData) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return false;
        }

        U8 *pHdr = pData;
        U8 *pPayload = pData + MT_TOTAL_HEADER_SIZE;

//        U16 payloadLen = ntohs(*(U16 *)(&pHdr[MT_HIDX_STREAM_DATA_LEN16]));
        U16 payloadLen = ntohs( *(U16 *)(&pHdr[MT_HIDX_STREAM_DATA_LEN16]));

        // Get item pointer in media queue
        media_q_item_t *pMediaQItem = openavbMediaQHeadLock(pMediaQ);
        if (pMediaQItem) {
            // Get the timestamp and place it in the media queue item.
            U32 timestamp = ntohl(*(U32 *)(&pHdr[MT_HIDX_AVTP_TIMESTAMP32]));
            //openavbAvtpTimeSetToTimestamp(pMediaQItem->pAvtpTime, timestamp);
            if(pMediaQItem->pAvtpTime) {
            mt_time_set_to_ts(pPvtData->ptp, &(pMediaQItem->pAvtpTime->timeNsec), timestamp);
            }
            // Set timestamp valid and timestamp uncertain flags
            if(pMediaQItem->pAvtpTime) {
                pMediaQItem->pAvtpTime->bTimestampValid = (pHdr[MT_HIDX_AVTP_HIDE7_TV1] & 0x01) ? TRUE : FALSE;
                pMediaQItem->pAvtpTime->bTimestampUncertain = (pHdr[MT_HIDX_AVTP_HIDE7_TU1] & 0x01) ? TRUE : FALSE;
            }
            if (pHdr[MT_HIDX_M11_M01_EVT2_RESV2] & 0x10) {
                ((media_q_item_map_mjpeg_pub_data_t *)pMediaQItem->pPubMapData)->lastFragment = TRUE;
            }
            else {
                ((media_q_item_map_mjpeg_pub_data_t *)pMediaQItem->pPubMapData)->lastFragment = FALSE;
            }

            if (pMediaQItem->itemSize >= dataLen - MT_TOTAL_HEADER_SIZE && pMediaQItem->itemSize >= payloadLen) {
                memcpy(pMediaQItem->pPubData, pPayload, payloadLen);
                pMediaQItem->dataLen = dataLen - MT_TOTAL_HEADER_SIZE;
            }
            else {
                MT_PRINT_ERR("Data to large for media queue.");
                pMediaQItem->dataLen = 0;
            }

            openavbMediaQHeadPush(pMediaQ);
            return TRUE;
        }
        else {
            MT_IF_LOG_INTERVAL(1000) MT_PRINT_ERR("Media queue full.");
            return FALSE;   // Media queue full
        }
    }
    return FALSE;
}

// This callback will be called when the mapping module needs to be closed.
// All cleanup should occur in this function.
void mt_map_mjpeg_end_cb(media_q_t *pMediaQ) {
}

void mt_map_mjpeg_genend_cb(media_q_t *pMediaQ) {
    if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return;
        }
        mt_gptp_deinit(pPvtData->ptp);
    }
}

// Initialization entry point into the mapping module. Will need to be included in the .ini file.
extern DLL_EXPORT bool openavbMapMjpegInitialize(media_q_t *pMediaQ, openavb_map_cb_t *pMapCB, U32 inMaxTransitUsec)
{
    if (pMediaQ) {
        pMediaQ->pMediaQDataFormat = strdup(MapMjpegMediaQDataFormat);
        pMediaQ->pPvtMapInfo = calloc(1, sizeof(pvt_data_t));       // Memory freed by the media queue when the media queue is destroyed.

        if (!pMediaQ->pMediaQDataFormat || !pMediaQ->pPvtMapInfo) {
            MT_PRINT_ERR("Unable to allocate memory for mapping module.");
            return FALSE;
        }

        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;

        pMapCB->map_cfg_cb = mt_map_mjpeg_cfg_cb;
        pMapCB->map_subtype_cb = mt_map_mjpeg_subtype_cb;
        pMapCB->map_avtp_version_cb = mt_map_mjpeg_avtp_version_cb;
        pMapCB->map_max_data_size_cb = mt_map_mjpeg_max_datasize_cb;
        pMapCB->map_transmit_interval_cb = mt_map_mjpeg_transmit_interval_cb;
        pMapCB->map_gen_init_cb = mt_map_mjpeg_geninit_cb;
        pMapCB->map_tx_init_cb = mt_map_mjpeg_tx_init_cb;
        pMapCB->map_tx_cb = mt_map_mjpeg_tx_cb;
        pMapCB->map_rx_init_cb = mt_map_mjpeg_rx_init_cb;
        pMapCB->map_rx_cb = mt_map_mjpeg_rx_cb;
        pMapCB->map_end_cb = mt_map_mjpeg_end_cb;
        pMapCB->map_gen_end_cb = mt_map_mjpeg_genend_cb;

        pPvtData->itemCount = 20;
        pPvtData->txInterval = 0;
        pPvtData->maxTransitUsec = inMaxTransitUsec;

        openavbMediaQSetMaxLatency(pMediaQ, inMaxTransitUsec);
    }
    return TRUE;
}
