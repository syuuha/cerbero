#include <stdlib.h>
#include <string.h>
#include "openavb_mcr_hal_pub.h"
#include "openavb_types_pub.h"
#include "openavb_mediaq_pub.h"
#include "openavb_map_pub.h"
#include "mt_map_aaf_audio_pub.h"
#include <mt_debug.h>
#include <mt_gptp.h>

#ifdef MT_CATEGERY
#undef MT_CATEGERY
#endif
#define MT_CATEGERY "mt_avtp_map_aaf_audio"
#define LOG_VARX(x, y) x ## y
#define LOG_VAR(x, y) LOG_VARX(x, y)
#define MT_IF_LOG_INTERVAL(x) static U32 LOG_VAR(logOnce,__LINE__) = 0; if (!(LOG_VAR(logOnce,__LINE__)++ % (x)))


#define MT_AVTP_SUBTYPE_AAF			2
#define MT_AVTP_V0_HEADER_SIZE			12
#define MT_AAF_HEADER_SIZE				12
#define MT_TOTAL_HEADER_SIZE			(MT_AVTP_V0_HEADER_SIZE + MT_AAF_HEADER_SIZE)

#define MT_HIDX_AVTP_HIDE7_TV1			1 	// - 1 Byte - TV bit (timestamp valid)
#define MT_HIDX_AVTP_SEQ_NUM			2 	// - 1 Byte - Sequence number
#define MT_HIDX_AVTP_HIDE7_TU1			3 	// - 1 Byte - TU bit (timestamp uncertain)
#define MT_HIDX_STREAM_DATA_LEN16		20 	// - 2 bytes	Stream data length
#define MT_HIDX_AVTP_HIDE7_SP			22 	// - 1 Byte - SP bit (sparse mode)
#define MT_SP_M0_BIT					(1 << 4)


typedef enum {
	AAF_RATE_UNSPEC = 0,
	AAF_RATE_8K,
	AAF_RATE_16K,
	AAF_RATE_32K,
	AAF_RATE_44K1,
	AAF_RATE_48K,
	AAF_RATE_88K2,
	AAF_RATE_96K,
	AAF_RATE_176K4,
	AAF_RATE_192K,
	AAF_RATE_24K,
} aaf_nominal_sample_rate_t;

typedef enum {
	AAF_FORMAT_UNSPEC = 0,
	AAF_FORMAT_FLOAT_32,
	AAF_FORMAT_INT_32,
	AAF_FORMAT_INT_24,
	AAF_FORMAT_INT_16,
	AAF_FORMAT_AES3_32, // AVDECC_TODO:  Implement this
} aaf_sample_format_t;

typedef enum {
	AAF_STATIC_CHANNELS_LAYOUT	= 0,
	AAF_MONO_CHANNELS_LAYOUT	= 1,
	AAF_STEREO_CHANNELS_LAYOUT	= 2,
	AAF_5_1_CHANNELS_LAYOUT		= 3,
	AAF_7_1_CHANNELS_LAYOUT		= 4,
	AAF_MAX_CHANNELS_LAYOUT		= 15,
} aaf_automotive_channels_layout_t;

typedef enum {
	// Disabled - timestamp is valid in every avtp packet
	TS_SPARSE_MODE_DISABLED		= 0,
	// Enabled - timestamp is valid in every 8th avtp packet
	TS_SPARSE_MODE_ENABLED		= 1
} avb_audio_sparse_mode_t;

typedef struct {
	/////////////
	// Config data
	/////////////
	// map_nv_item_count
	U32 itemCount;

	// Transmit interval in frames per second. 0 = default for talker class.
	U32 txInterval;

	// A multiple of how many frames of audio to accept in an media queue item and
	// into the AVTP payload above the minimal needed.
	U32 packingFactor;

	// MCR mode
	avb_audio_mcr_t audioMcr;

	// MCR timestamp interval
	U32 mcrTimestampInterval;

	// MCR clock recovery interval
	U32 mcrRecoveryInterval;

	/////////////
	// Variable data
	/////////////
	U32 maxTransitUsec;     // In microseconds

	aaf_nominal_sample_rate_t 	aaf_rate;
	aaf_sample_format_t			aaf_format;
	U8							aaf_bit_depth;
	U32 payloadSize;
	U32 payloadSizeMaxTalker, payloadSizeMaxListener;
	bool isTalker;

	U8 aaf_event_field;

	bool dataValid;

	U32 intervalCounter;

	avb_audio_sparse_mode_t sparseMode;

	bool mediaQItemSyncTS;


    mt_gptp * ptp;

} pvt_data_t;

static void x_calculateSizes(media_q_t *pMediaQ)
{
	if (pMediaQ) {
		media_q_pub_map_aaf_audio_info_t *pPubMapInfo = pMediaQ->pPubMapInfo;
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return;
		}

		switch (pPubMapInfo->audioRate) {
			case AVB_AUDIO_RATE_8KHZ:
				pPvtData->aaf_rate = AAF_RATE_8K;
				break;
			case AVB_AUDIO_RATE_16KHZ:
				pPvtData->aaf_rate = AAF_RATE_16K;
				break;
			case AVB_AUDIO_RATE_24KHZ:
				pPvtData->aaf_rate = AAF_RATE_24K;
				break;
			case AVB_AUDIO_RATE_32KHZ:
				pPvtData->aaf_rate = AAF_RATE_32K;
				break;
			case AVB_AUDIO_RATE_44_1KHZ:
				pPvtData->aaf_rate = AAF_RATE_44K1;
				break;
			case AVB_AUDIO_RATE_48KHZ:
				pPvtData->aaf_rate = AAF_RATE_48K;
				break;
			case AVB_AUDIO_RATE_88_2KHZ:
				pPvtData->aaf_rate = AAF_RATE_88K2;
				break;
			case AVB_AUDIO_RATE_96KHZ:
				pPvtData->aaf_rate = AAF_RATE_96K;
				break;
			case AVB_AUDIO_RATE_176_4KHZ:
				pPvtData->aaf_rate = AAF_RATE_176K4;
				break;
			case AVB_AUDIO_RATE_192KHZ:
				pPvtData->aaf_rate = AAF_RATE_192K;
				break;
			default:
				MT_PRINT_ERR("Invalid audio frequency configured");
				pPvtData->aaf_rate = AAF_RATE_UNSPEC;
				break;
		}
		MT_PRINT_DEBUG("aaf_rate=%d (%dKhz)", pPvtData->aaf_rate, pPubMapInfo->audioRate);

		char *typeStr = "int";
		if (pPubMapInfo->audioType == AVB_AUDIO_TYPE_FLOAT) {
			typeStr = "float";
			switch (pPubMapInfo->audioBitDepth) {
				case AVB_AUDIO_BIT_DEPTH_32BIT:
					pPvtData->aaf_format = AAF_FORMAT_FLOAT_32;
					pPubMapInfo->itemSampleSizeBytes = 4;
					pPubMapInfo->packetSampleSizeBytes = 4;
					pPvtData->aaf_bit_depth = 32;
					break;
				default:
					MT_PRINT_ERR("Invalid audio bit-depth configured for float");
					pPvtData->aaf_format = AAF_FORMAT_UNSPEC;
					break;
			}
		}
		else {
			switch (pPubMapInfo->audioBitDepth) {
				case AVB_AUDIO_BIT_DEPTH_32BIT:
					pPvtData->aaf_format = AAF_FORMAT_INT_32;
					pPubMapInfo->itemSampleSizeBytes = 4;
					pPubMapInfo->packetSampleSizeBytes = 4;
					pPvtData->aaf_bit_depth = 32;
					break;
				case AVB_AUDIO_BIT_DEPTH_24BIT:
					pPvtData->aaf_format = AAF_FORMAT_INT_24;
					pPubMapInfo->itemSampleSizeBytes = 3;
					pPubMapInfo->packetSampleSizeBytes = 3;
					pPvtData->aaf_bit_depth = 24;
					break;
				case AVB_AUDIO_BIT_DEPTH_16BIT:
					pPvtData->aaf_format = AAF_FORMAT_INT_16;
					pPubMapInfo->itemSampleSizeBytes = 2;
					pPubMapInfo->packetSampleSizeBytes = 2;
					pPvtData->aaf_bit_depth = 16;
					break;
#if 0
					// should work - test content?
				case AVB_AUDIO_BIT_DEPTH_20BIT:
					pPvtData->aaf_format = AAF_FORMAT_INT_24;
					pPubMapInfo->itemSampleSizeBytes = 3;
					pPubMapInfo->packetSampleSizeBytes = 3;
					pPvtData->aaf_bit_depth = 20;
					break;
					// would require byte-by-byte copy
				case AVB_AUDIO_BIT_DEPTH_8BIT:
					pPvtData->aaf_format = AAF_FORMAT_INT_24;
					pPubMapInfo->itemSampleSizeBytes = 1;
					pPubMapInfo->packetSampleSizeBytes = 2;
					pPvtData->aaf_bit_depth = 8;
					break;
#endif
				default:
					MT_PRINT_ERR("Invalid audio bit-depth configured");
					pPvtData->aaf_format = AAF_FORMAT_UNSPEC;
					break;
			}
		}
		MT_PRINT_DEBUG("aaf_format=%d (%s%d)",
			pPvtData->aaf_format, typeStr, pPubMapInfo->audioBitDepth);

		// Audio frames per packet
		pPubMapInfo->framesPerPacket = (pPubMapInfo->audioRate / pPvtData->txInterval);
		if (pPubMapInfo->audioRate % pPvtData->txInterval != 0) {
			MT_PRINT_DEBUG("Audio rate (%d) is not integer multiple of TX interval (%d)",
				pPubMapInfo->audioRate, pPvtData->txInterval);
			pPubMapInfo->framesPerPacket += 1;
		}
		MT_PRINT_DEBUG("Frames/packet = %d", pPubMapInfo->framesPerPacket);

		// AAF packet size calculations
		pPubMapInfo->packetFrameSizeBytes = pPubMapInfo->packetSampleSizeBytes * pPubMapInfo->audioChannels;
		pPvtData->payloadSize = pPvtData->payloadSizeMaxTalker = pPvtData->payloadSizeMaxListener =
			pPubMapInfo->framesPerPacket * pPubMapInfo->packetFrameSizeBytes;
		MT_PRINT_DEBUG("packet: sampleSz=%d * channels=%d => frameSz=%d * %d => payloadSz=%d",
			pPubMapInfo->packetSampleSizeBytes,
			pPubMapInfo->audioChannels,
			pPubMapInfo->packetFrameSizeBytes,
			pPubMapInfo->framesPerPacket,
			pPvtData->payloadSize);
		if (pPvtData->aaf_format >= AAF_FORMAT_INT_32 && pPvtData->aaf_format <= AAF_FORMAT_INT_16) {
			// Determine the largest size we could receive before adjustments.
			pPvtData->payloadSizeMaxListener = 4 * pPubMapInfo->audioChannels * pPubMapInfo->framesPerPacket;
			MT_PRINT_DEBUG("packet: payloadSizeMaxListener=%d", pPvtData->payloadSizeMaxListener);
		}

		// MediaQ item size calculations
		pPubMapInfo->packingFactor = pPvtData->packingFactor;
		pPubMapInfo->framesPerItem = pPubMapInfo->framesPerPacket * pPvtData->packingFactor;
		pPubMapInfo->itemFrameSizeBytes = pPubMapInfo->itemSampleSizeBytes * pPubMapInfo->audioChannels;
		pPubMapInfo->itemSize = pPubMapInfo->itemFrameSizeBytes * pPubMapInfo->framesPerItem;
		MT_PRINT_DEBUG("item: sampleSz=%d * channels=%d => frameSz=%d * %d * packing=%d => itemSz=%d",
			pPubMapInfo->itemSampleSizeBytes,
			pPubMapInfo->audioChannels,
			pPubMapInfo->itemFrameSizeBytes,
			pPubMapInfo->framesPerPacket,
			pPubMapInfo->packingFactor,
			pPubMapInfo->itemSize);
	}

}


// Each configuration name value pair for this mapping will result in this callback being called.
void mt_map_aaf_audio_cfg_cb(media_q_t *pMediaQ, const char *name, const char *value)
{
	if (pMediaQ) {
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return;
		}

		if (strcmp(name, "map_nv_item_count") == 0) {
			char *pEnd;
			pPvtData->itemCount = strtol(value, &pEnd, 10);
		}
		else if (strcmp(name, "map_nv_packing_factor") == 0) {
			char *pEnd;
			pPvtData->packingFactor = strtol(value, &pEnd, 10);
		}
		else if (strcmp(name, "map_nv_tx_rate") == 0
			|| strcmp(name, "map_nv_tx_interval") == 0) {
			char *pEnd;
			pPvtData->txInterval = strtol(value, &pEnd, 10);
		}
		else if (strcmp(name, "map_nv_sparse_mode") == 0) {
			char* pEnd;
			U32 tmp;
			tmp = strtol(value, &pEnd, 10);
			if (*pEnd == '\0' && tmp == 1) {
				pPvtData->sparseMode = TS_SPARSE_MODE_ENABLED;
			}
			else if (*pEnd == '\0' && tmp == 0) {
				pPvtData->sparseMode = TS_SPARSE_MODE_DISABLED;
			}
		}
		else if (strcmp(name, "map_nv_audio_mcr") == 0) {
			char *pEnd;
			pPvtData->audioMcr = (avb_audio_mcr_t)strtol(value, &pEnd, 10);
		}
		else if (strcmp(name, "map_nv_mcr_timestamp_interval") == 0) {
			char *pEnd;
			pPvtData->mcrTimestampInterval = strtol(value, &pEnd, 10);
		}
		else if (strcmp(name, "map_nv_mcr_recovery_interval") == 0) {
			char *pEnd;
			pPvtData->mcrRecoveryInterval = strtol(value, &pEnd, 10);
		}
	}

}

U8 mt_map_aaf_audio_subtype_cb() {
	return MT_AVTP_SUBTYPE_AAF;        // AAF AVB subtype
}

// Returns the AVTP version used by this mapping
U8 mt_map_aaf_audio_avtp_version_cb() {
	return 0x00;        // Version 0
}

U16 mt_map_aaf_audio_max_datasize_cb(media_q_t *pMediaQ) {
	if (pMediaQ) {
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return 0;
		}

		// Return the largest size a frame payload could be.
		// If we don't yet know if we are a Talker or Listener, the larger Listener max will be returned.
		U16 payloadSizeMax;
		if (pPvtData->isTalker) {
			payloadSizeMax = pPvtData->payloadSizeMaxTalker + MT_TOTAL_HEADER_SIZE;
		}
		else {
			payloadSizeMax = pPvtData->payloadSizeMaxListener + MT_TOTAL_HEADER_SIZE;
		}
		return payloadSizeMax;
	}
	return 0;
}

// Returns the intended transmit interval (in frames per second). 0 = default for talker / class.
U32 mt_map_aaf_audio_transmit_interval_cb(media_q_t *pMediaQ) {
	if (pMediaQ) {
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return 0;
		}
		return pPvtData->txInterval;
	}
	return 0;
}

void mt_map_aaf_audio_geninit_cb(media_q_t *pMediaQ) {
	if (pMediaQ) {
		media_q_pub_map_uncmp_audio_info_t *pPubMapInfo = pMediaQ->pPubMapInfo;
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return;
		}

        pPvtData->ptp = mt_gptp_init();
		x_calculateSizes(pMediaQ);
		openavbMediaQSetSize(pMediaQ, pPvtData->itemCount, pPubMapInfo->itemSize);

		pPvtData->dataValid = TRUE;
	}
}

// A call to this callback indicates that this mapping module will be
// a talker. Any talker initialization can be done in this function.
void mt_map_aaf_audio_tx_init_cb(media_q_t *pMediaQ) {
	if (pMediaQ) {
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (pPvtData) {
			pPvtData->isTalker = TRUE;
		}
	}
}

// CORE_TODO: This callback should be updated to work in a similar way the uncompressed audio mapping. With allowing AVTP packets to be built
//  from multiple media queue items. This allows interface to set into the media queue blocks of audio frames to properly correspond to
//  a SYT_INTERVAL. Additionally the public data member sytInterval needs to be set in the same way the uncompressed audio mapping does.
// This talker callback will be called for each AVB observation interval.
tx_cb_ret_t mt_map_aaf_audio_tx_cb(media_q_t *pMediaQ, U8 *pData, U32 *dataLen)
{
	media_q_item_t *pMediaQItem = NULL;
	if (!pMediaQ) {
		MT_PRINT_ERR("Mapping module invalid MediaQ");

		return TX_CB_RET_PACKET_NOT_READY;
	}

	if (!pData || !dataLen) {
		MT_PRINT_ERR("Mapping module data or data length argument incorrect.");

		return TX_CB_RET_PACKET_NOT_READY;
	}

	media_q_pub_map_aaf_audio_info_t *pPubMapInfo = pMediaQ->pPubMapInfo;

	U32 bytesNeeded = pPubMapInfo->itemFrameSizeBytes * pPubMapInfo->framesPerPacket;
	if (!openavbMediaQIsAvailableBytes(pMediaQ, pPubMapInfo->itemFrameSizeBytes * pPubMapInfo->framesPerPacket, TRUE)) {
		MT_PRINT_DEBUG("Not enough bytes are ready");

		return TX_CB_RET_PACKET_NOT_READY;
	}

	pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
	if (!pPvtData) {
		MT_PRINT_ERR("Private mapping module data not allocated.");
		openavbMediaQTailUnlock(pMediaQ);

		return TX_CB_RET_PACKET_NOT_READY;
	}

	if ((*dataLen - MT_TOTAL_HEADER_SIZE) < pPvtData->payloadSize) {
		MT_PRINT_ERR("Not enough room in packet for payload");
		openavbMediaQTailUnlock(pMediaQ);

		return TX_CB_RET_PACKET_NOT_READY;
	}

	U32 tmp32;
	U8 *pHdrV0 = pData;
	U32 *pHdr = (U32 *)(pData + MT_AVTP_V0_HEADER_SIZE);
	U8  *pPayload = pData + MT_TOTAL_HEADER_SIZE;

	U32 bytesProcessed = 0;
	while (bytesProcessed < bytesNeeded) {
		pMediaQItem = openavbMediaQTailLock(pMediaQ, TRUE);
		if (pMediaQItem && pMediaQItem->pPubData && pMediaQItem->dataLen > 0) {

			// timestamp set in the interface module, here just validate
			// In sparse mode, the timestamp valid flag should be set every eighth AAF AVPTDU.
			if (pPvtData->sparseMode == TS_SPARSE_MODE_ENABLED && (pHdrV0[MT_HIDX_AVTP_SEQ_NUM] & 0x07) != 0) {
				// Skip over this timestamp, as using sparse mode.
				pHdrV0[MT_HIDX_AVTP_HIDE7_TV1] &= ~0x01;
				pHdrV0[MT_HIDX_AVTP_HIDE7_TU1] &= ~0x01;
				*pHdr++ = 0; // Clear the timestamp field
			}
			else if (!(pMediaQItem->pAvtpTime && pMediaQItem->pAvtpTime->bTimestampValid)) {
				// Error getting the timestamp.  Clear timestamp valid flag.
				MT_PRINT_ERR("Unable to get the timestamp value");
				pHdrV0[MT_HIDX_AVTP_HIDE7_TV1] &= ~0x01;
				pHdrV0[MT_HIDX_AVTP_HIDE7_TU1] |= 0x01;
				*pHdr++ = 0; // Clear the timestamp field
			}
			else {
				// Add the max transit time.
                pMediaQItem->pAvtpTime->timeNsec += pPvtData->maxTransitUsec * MT_GPTP_NANOSECONDS_PER_USEC;


				// Set timestamp valid flag
				pHdrV0[MT_HIDX_AVTP_HIDE7_TV1] |= 0x01;

				// Set (clear) timestamp uncertain flag
				if (pMediaQItem->pAvtpTime && pMediaQItem->pAvtpTime->bTimestampUncertain)
					pHdrV0[MT_HIDX_AVTP_HIDE7_TU1] |= 0x01;
				else pHdrV0[MT_HIDX_AVTP_HIDE7_TU1] &= ~0x01;

				// - 4 bytes	avtp_timestamp
				*pHdr++ = htonl((U32)(pMediaQItem->pAvtpTime->timeNsec & 0x00000000FFFFFFFFL));

				//pMediaQItem->pAvtpTime->bTimestampValid = FALSE;
			}

			// - 4 bytes	format info (format, sample rate, channels per frame, bit depth)
			tmp32 = pPvtData->aaf_format << 24;
			tmp32 |= pPvtData->aaf_rate  << 20;
			tmp32 |= pPubMapInfo->audioChannels << 8;
			tmp32 |= pPvtData->aaf_bit_depth;
			*pHdr++ = htonl(tmp32);

			// - 4 bytes	packet info (data length, evt field)
			tmp32 = pPvtData->payloadSize << 16;
			tmp32 |= pPvtData->aaf_event_field << 8;
			*pHdr++ = htonl(tmp32);

			// Set (clear) sparse mode flag
			if (pPvtData->sparseMode == TS_SPARSE_MODE_ENABLED) {
				pHdrV0[MT_HIDX_AVTP_HIDE7_SP] |= MT_SP_M0_BIT;
			} else {
				pHdrV0[MT_HIDX_AVTP_HIDE7_SP] &= ~MT_SP_M0_BIT;
			}

			if ((pMediaQItem->dataLen - pMediaQItem->readIdx) < pPvtData->payloadSize) {
				// This should not happen so we will just toss it away.
				MT_PRINT_ERR("Not enough data in media queue item for packet");
				openavbMediaQTailPull(pMediaQ);

				return TX_CB_RET_PACKET_NOT_READY;
			}

			memcpy(pPayload, (uint8_t *)pMediaQItem->pPubData + pMediaQItem->readIdx, pPvtData->payloadSize);
			bytesProcessed += pPvtData->payloadSize;

			pMediaQItem->readIdx += pPvtData->payloadSize;
			if (pMediaQItem->readIdx >= pMediaQItem->dataLen) {
				// Finished reading the entire item
				openavbMediaQTailPull(pMediaQ);
			}
			else {
				// More to read next interval
				openavbMediaQTailUnlock(pMediaQ);
			}
		}
		else {
			openavbMediaQTailPull(pMediaQ);
		}
	}

	// Set out bound data length (entire packet length)
	*dataLen = bytesNeeded + MT_TOTAL_HEADER_SIZE;

	return TX_CB_RET_PACKET_READY;
}

// A call to this callback indicates that this mapping module will be
// a listener. Any listener initialization can be done in this function.
void mt_map_aaf_audio_rx_init_cb(media_q_t *pMediaQ) {
	if (pMediaQ) {
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return;
		}
		pPvtData->isTalker = FALSE;
		if (pPvtData->audioMcr != AVB_MCR_NONE) {
			HAL_INIT_MCR_V2(pPvtData->txInterval, pPvtData->packingFactor, pPvtData->mcrTimestampInterval, pPvtData->mcrRecoveryInterval);
		}
		bool badPckFctrValue = FALSE;
		if (pPvtData->sparseMode == TS_SPARSE_MODE_ENABLED) {
			// sparse mode enabled so check packing factor
			// listener should work correct for packing_factors:
			// 1, 2, 4, 8, 16, 24, 32, 40, 48, (+8) ...
			if (pPvtData->packingFactor == 0) {
				badPckFctrValue = TRUE;
			}
			else if (pPvtData->packingFactor < 8) {
				// check if power of 2
				if ((pPvtData->packingFactor & (pPvtData->packingFactor - 1)) != 0) {
					badPckFctrValue = TRUE;
				}
			}
			else {
				// check if multiple of 8
				if (pPvtData->packingFactor % 8 != 0) {
					badPckFctrValue = TRUE;
				}
			}
			if (badPckFctrValue) {
				MT_PRINT_DEBUG("Wrong packing factor value set (%d) for sparse timestamping mode", pPvtData->packingFactor);
			}
		}
	}
}

// This callback occurs when running as a listener and data is available.
bool mt_map_aaf_audio_rx_cb(media_q_t *pMediaQ, U8 *pData, U32 dataLen)
{
		if (pMediaQ && pData) {
		U8 *pHdrV0 = pData;
		U32 *pHdr = (U32 *)(pData + MT_AVTP_V0_HEADER_SIZE);
		U8  *pPayload = pData + MT_TOTAL_HEADER_SIZE;
		media_q_pub_map_aaf_audio_info_t *pPubMapInfo = pMediaQ->pPubMapInfo;
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return FALSE;
		}

		aaf_sample_format_t incoming_aaf_format;
		U8 incoming_bit_depth;
		U32 tmp;
		bool dataValid = TRUE;
		bool dataConversionEnabled = FALSE;

		U32 timestamp = ntohl(*pHdr++);
		U32 format_info = ntohl(*pHdr++);
		U32 packet_info = ntohl(*pHdr++);

		bool listenerSparseMode = (pPvtData->sparseMode == TS_SPARSE_MODE_ENABLED) ? TRUE : FALSE;
		bool streamSparseMode = (pHdrV0[MT_HIDX_AVTP_HIDE7_SP] & MT_SP_M0_BIT) ? TRUE : FALSE;
		U16 payloadLen = ntohs(*(U16 *)(&pHdrV0[MT_HIDX_STREAM_DATA_LEN16]));

		if (payloadLen > dataLen - MT_TOTAL_HEADER_SIZE) {
			if (pPvtData->dataValid)
				MT_PRINT_ERR("header data len %d > actual data len %d",
					       payloadLen, dataLen - MT_TOTAL_HEADER_SIZE);
			dataValid = FALSE;
		}

		if ((incoming_aaf_format = (aaf_sample_format_t) ((format_info >> 24) & 0xFF)) != pPvtData->aaf_format) {
			// Check if we can convert the incoming data.
			if (incoming_aaf_format >= AAF_FORMAT_INT_32 && incoming_aaf_format <= AAF_FORMAT_INT_16 &&
					pPvtData->aaf_format >= AAF_FORMAT_INT_32 && pPvtData->aaf_format <= AAF_FORMAT_INT_16) {
				// Integer conversion should be supported.
				dataConversionEnabled = TRUE;
			}
			else {
				if (pPvtData->dataValid)
					MT_PRINT_ERR("Listener format %d doesn't match received data (%d)",
						pPvtData->aaf_format, incoming_aaf_format);
				dataValid = FALSE;
			}
		}
		if ((tmp = ((format_info >> 20) & 0x0F)) != pPvtData->aaf_rate) {
			if (pPvtData->dataValid)
				MT_PRINT_ERR("Listener sample rate (%d) doesn't match received data (%d)",
					pPvtData->aaf_rate, tmp);
			dataValid = FALSE;
		}
		if ((tmp = ((format_info >> 8) & 0x3FF)) != pPubMapInfo->audioChannels) {
			if (pPvtData->dataValid)
				MT_PRINT_ERR("Listener channel count (%d) doesn't match received data (%d)",
					pPubMapInfo->audioChannels, tmp);
			dataValid = FALSE;
		}
		if ((incoming_bit_depth = (U8) (format_info & 0xFF)) == 0) {
			if (pPvtData->dataValid)
				MT_PRINT_ERR("Listener bit depth (%d) not valid",
					incoming_bit_depth);
			dataValid = FALSE;
		}
		if ((tmp = ((packet_info >> 16) & 0xFFFF)) != pPvtData->payloadSize) {
			if (!dataConversionEnabled) {
				if (pPvtData->dataValid)
					MT_PRINT_ERR("Listener payload size (%d) doesn't match received data (%d)",
						pPvtData->payloadSize, tmp);
				dataValid = FALSE;
			}
			else {
				U32 nInSampleLength = 6 - incoming_aaf_format; // Calculate the number of integer bytes per sample received
				U32 nOutSampleLength = 6 - pPvtData->aaf_format; // Calculate the number of integer bytes per sample we want
				if (tmp / nInSampleLength != pPvtData->payloadSize / nOutSampleLength) {
					if (pPvtData->dataValid)
						MT_PRINT_ERR("Listener payload samples (%d) doesn't match received data samples (%d)",
							pPvtData->payloadSize / nOutSampleLength, tmp / nInSampleLength);
					dataValid = FALSE;
				}
			}
		}
		if ((tmp = ((packet_info >> 8) & 0x0F)) != pPvtData->aaf_event_field) {
			if (pPvtData->dataValid)
				MT_PRINT_ERR("Listener event field (%d) doesn't match received data (%d)",
					pPvtData->aaf_event_field, tmp);
		}
		if (streamSparseMode && !listenerSparseMode) {
			MT_PRINT_DEBUG("Listener enabling sparse mode to match incoming stream");
			pPvtData->sparseMode = TS_SPARSE_MODE_ENABLED;
			listenerSparseMode = TRUE;
		}
		if (!streamSparseMode && listenerSparseMode) {
			MT_PRINT_DEBUG("Listener disabling sparse mode to match incoming stream");
			pPvtData->sparseMode = TS_SPARSE_MODE_DISABLED;
			listenerSparseMode = FALSE;
		}

		if (dataValid) {
			if (!pPvtData->dataValid) {
				MT_PRINT_DEBUG("RX data valid, stream un-muted");
				pPvtData->dataValid = TRUE;
			}

			// Get item pointer in media queue
			media_q_item_t *pMediaQItem = openavbMediaQHeadLock(pMediaQ);
			if (pMediaQItem) {
				// set timestamp if first data written to item
				if (pMediaQItem->dataLen == 0) {

					// Set timestamp valid flag and Set timestamp uncertain flag
					if (pMediaQItem->pAvtpTime) {
						pMediaQItem->pAvtpTime->bTimestampValid = (pHdr[MT_HIDX_AVTP_HIDE7_TV1] & 0x01) ? TRUE : FALSE;
						pMediaQItem->pAvtpTime->bTimestampUncertain = (pHdr[MT_HIDX_AVTP_HIDE7_TU1] & 0x01) ? TRUE : FALSE;
					}

					if (pMediaQItem->pAvtpTime->bTimestampValid) {
						// Get the timestamp and place it in the media queue item.
						//openavbAvtpTimeSetToTimestamp(pMediaQItem->pAvtpTime, timestamp);
						if (pMediaQItem->pAvtpTime) {
							mt_time_set_to_ts(pPvtData->ptp, &(pMediaQItem->pAvtpTime->timeNsec), timestamp);
						}

						pMediaQItem->pAvtpTime -= pPubMapInfo->presentationLatencyUSec * MT_GPTP_NANOSECONDS_PER_USEC;
						// Set flag to inform that MediaQ is synchronized with timestamped packets
						 pPvtData->mediaQItemSyncTS = TRUE;
					}
					else if (!pPvtData->mediaQItemSyncTS) {
						//we need packet with valid TS for first data written to item
						MT_PRINT_DEBUG("Timestamp not valid for MediaQItem - initial packets dropped");
						MT_IF_LOG_INTERVAL(1000) MT_PRINT_ERR("Timestamp not valid for MediaQItem - initial packets dropped");
						dataValid = FALSE;
					}
				}
				if (dataValid) {
					if (!dataConversionEnabled) {
						// Just use the raw incoming data, and ignore the incoming bit_depth.
						if (pPubMapInfo->intf_rx_translate_cb) {
							pPubMapInfo->intf_rx_translate_cb(pMediaQ, pPayload, pPvtData->payloadSize);
						}

						memcpy((uint8_t *)pMediaQItem->pPubData + pMediaQItem->dataLen, pPayload, pPvtData->payloadSize);
					}
					else {
						static U8 s_audioBuffer[1500];
						U8 *pInData = pPayload;
						U8 *pInDataEnd = pPayload + payloadLen;
						U8 *pOutData = s_audioBuffer;
						int nInSampleLength = 6 - incoming_aaf_format; // Calculate the number of integer bytes per sample received
						int nOutSampleLength = 6 - pPvtData->aaf_format; // Calculate the number of integer bytes per sample we want
						int i;
						if (nInSampleLength < nOutSampleLength) {
							// We need to pad the data supplied.
							while (pInData < pInDataEnd) {
								for (i = 0; i < nInSampleLength; ++i) {
									*pOutData++ = *pInData++;
								}
								for ( ; i < nOutSampleLength; ++i) {
									*pOutData++ = 0; // Value specified in Clause 7.3.4.
								}
							}
						}
						else {
							// We need to truncate the data supplied.
							while (pInData < pInDataEnd) {
								for (i = 0; i < nOutSampleLength; ++i) {
									*pOutData++ = *pInData++;
								}
								pInData += (nInSampleLength - nOutSampleLength);
							}
						}
						if (pOutData - s_audioBuffer != pPvtData->payloadSize) {
							MT_PRINT_ERR("Output not expected size (%d instead of %d)", pOutData - s_audioBuffer, pPvtData->payloadSize);
						}

						if (pPubMapInfo->intf_rx_translate_cb) {
							pPubMapInfo->intf_rx_translate_cb(pMediaQ, s_audioBuffer, pPvtData->payloadSize);
						}

						memcpy((uint8_t *)pMediaQItem->pPubData + pMediaQItem->dataLen, s_audioBuffer, pPvtData->payloadSize);
					}

					pMediaQItem->dataLen += pPvtData->payloadSize;
				}

				if (pMediaQItem->dataLen < pMediaQItem->itemSize) {
					// More data can be written to the item
					openavbMediaQHeadUnlock(pMediaQ);
				}
				else {
					// The item is full push it.
					openavbMediaQHeadPush(pMediaQ);
				}


				return TRUE;    // Normal exit
			}
			else {
				MT_IF_LOG_INTERVAL(1000) MT_PRINT_ERR("Media queue full");

				return FALSE;   // Media queue full
			}
		}
		else {
			if (pPvtData->dataValid) {
				MT_PRINT_DEBUG("RX data invalid, stream muted");
				pPvtData->dataValid = FALSE;
			}
		}
	}
	return FALSE;
}

// This callback will be called when the mapping module needs to be closed.
// All cleanup should occur in this function.
void mt_map_aaf_audio_end_cb(media_q_t *pMediaQ) {
	if (pMediaQ) {
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return;
		}

		if (pPvtData->audioMcr != AVB_MCR_NONE) {
			HAL_CLOSE_MCR_V2();
		}
		pPvtData->mediaQItemSyncTS = FALSE;
	}
}

void mt_map_aaf_audio_genend_cb(media_q_t *pMediaQ) {
if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return;
        }
        mt_gptp_deinit(pPvtData->ptp);
    }
}

// Initialization entry point into the mapping module. Will need to be included in the .ini file.
extern DLL_EXPORT bool openavbMapAVTPAudioInitialize(media_q_t *pMediaQ, openavb_map_cb_t *pMapCB, U32 inMaxTransitUsec)
{
	if (pMediaQ) {
		pMediaQ->pMediaQDataFormat = strdup(MapAVTPAudioMediaQDataFormat);
		pMediaQ->pPubMapInfo = calloc(1, sizeof(media_q_pub_map_aaf_audio_info_t));      // Memory freed by the media queue when the media queue is destroyed.
		pMediaQ->pPvtMapInfo = calloc(1, sizeof(pvt_data_t));                            // Memory freed by the media queue when the media queue is destroyed.

		if (!pMediaQ->pMediaQDataFormat || !pMediaQ->pPubMapInfo || !pMediaQ->pPvtMapInfo) {
			MT_PRINT_ERR("Unable to allocate memory for mapping module");
			return FALSE;
		}

		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;

		pMapCB->map_cfg_cb = mt_map_aaf_audio_cfg_cb;
		pMapCB->map_subtype_cb = mt_map_aaf_audio_subtype_cb;
		pMapCB->map_avtp_version_cb = mt_map_aaf_audio_avtp_version_cb;
		pMapCB->map_max_data_size_cb = mt_map_aaf_audio_max_datasize_cb; //may return invalid val
		pMapCB->map_transmit_interval_cb = mt_map_aaf_audio_transmit_interval_cb;
		pMapCB->map_gen_init_cb = mt_map_aaf_audio_geninit_cb;
		pMapCB->map_tx_init_cb = mt_map_aaf_audio_tx_init_cb;
		pMapCB->map_tx_cb = mt_map_aaf_audio_tx_cb;
		pMapCB->map_rx_init_cb = mt_map_aaf_audio_rx_init_cb;
		pMapCB->map_rx_cb = mt_map_aaf_audio_rx_cb;
		pMapCB->map_end_cb = mt_map_aaf_audio_end_cb;
		pMapCB->map_gen_end_cb = mt_map_aaf_audio_genend_cb;

		pPvtData->itemCount = 20;
		pPvtData->txInterval = 4000;  // default to something that wont cause divide by zero
		pPvtData->packingFactor = 1;
		pPvtData->maxTransitUsec = inMaxTransitUsec;
		pPvtData->sparseMode = TS_SPARSE_MODE_DISABLED;
		pPvtData->mcrTimestampInterval = 144;
		pPvtData->mcrRecoveryInterval = 512;
		pPvtData->aaf_event_field = AAF_STATIC_CHANNELS_LAYOUT;
		pPvtData->intervalCounter = 0;
		pPvtData->mediaQItemSyncTS = FALSE;
		openavbMediaQSetMaxLatency(pMediaQ, inMaxTransitUsec);
	}

	return TRUE;
}
