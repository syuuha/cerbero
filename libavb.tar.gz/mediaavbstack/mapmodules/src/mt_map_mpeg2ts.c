#include <stdlib.h>
#include <string.h>
#include "openavb_types_pub.h"
#include "openavb_avtp_time_pub.h"
#include "openavb_mediaq_pub.h"
#include "openavb_map_pub.h"
#include "mt_map_mpeg2ts_pub.h"
#include "openavb_types.h"
#include <assert.h>
#include <mt_debug.h>
#include <mt_gptp.h>

#ifdef MT_CATEGERY
#undef MT_CATEGERY
#endif
#define MT_CATEGERY "mt_avtp_ts"
#define LOG_VARX(x, y) x ## y
#define LOG_VAR(x, y) LOG_VARX(x, y)
#define MT_IF_LOG_INTERVAL(x) static U32 LOG_VAR(logOnce,__LINE__) = 0; if (!(LOG_VAR(logOnce,__LINE__)++ % (x)))


// Base MPEG2 Transport Stream packet size
#define MT_MPEG2_TS_PKT_SIZE				188
#define MT_MPEG2_TS_SYNC_BYTE				0x47
#define MT_MPEG2TS_MQITEM_SIZE				9024
#define MT_MPEG2TS_MQITEM_COUNT		20
#define MT_MPEGTS_SRC_PKT_HDR_SIZE			4
#define MT_MPEGTS_SRC_PKT_SIZE 				(MT_MPEG2_TS_PKT_SIZE + MT_MPEGTS_SRC_PKT_HDR_SIZE)
#define MT_AVTP_DFLT_SRC_PKTS				7
#define MT_AVTP_V0_HEADER_SIZE				12
#define MT_MAP_HEADER_SIZE					12
#define MT_CIP_HEADER_SIZE					8
#define MT_CTOTAL_HEADER_SIZE				(MT_AVTP_V0_HEADER_SIZE + MT_MAP_HEADER_SIZE + MT_CIP_HEADER_SIZE)
#define MT_BLOCKS_PER_SRC_PKT				8
#define MT_BLOCKS_PER_AVTP_PKT				(MT_BLOCKS_PER_SRC_PKT * AVTP_NUM_SRC_PKTS)
#define MT_HIDX_AVTP_VERZERO96				0
#define MT_HIDX_AVTP_HIDE7_TV1				1
#define MT_HIDX_AVTP_HIDE7_TU1				3
#define MT_HIDX_AVTP_TIMESTAMP32			12
#define MT_HIDX_GATEWAY32					16
#define MT_HIDX_DATALEN16					20
#define MT_HIDX_TAG2_CHANNEL6				22
#define MT_HIDX_TCODE4_SY4					23
#define MT_HIDX_CIP2_SID6					24
#define MT_HIDX_DBS8						25
#define MT_HIDX_FN2_QPC3_SPH1_RSV2			26
#define MT_HIDX_DBC8						27
#define MT_HIDX_CIP2_FMT6					28
#define MT_HIDX_TSF1_RESA7					29
#define MT_HIDX_RESB8						30
#define MT_HIDX_RESC8						31
#define MT_DEFAULT_SRC_PKTS_PER_AVTP_FRAME 	5

typedef struct {
	/////////////
	// Config data
	/////////////

	// map_nv_item_count, map_nv_item_size
	// number of items to allocate in MediaQ, size of data in each item
	unsigned itemCount, itemSize;

	// map_nv_ts_packet_size
	// size of transport stream packets passed to/from interface module (188 or 192)
	unsigned tsPacketSize;

	// Talker-only config

	// map_nv_num_source_packets
	// Number of source packets to send in AVTP frame
	unsigned numSourcePackets;

	// map_nv_tx_rate
	// Transmit rate in frames per second. 0 = default for talker class.
	unsigned txRate;

	/////////////
	// Variable data
	/////////////
	unsigned maxTransitUsec;        // In microseconds

	// Data block continuity counter
	U32 DBC;

	// Saved partial source packet
	char savedBytes[200];
	int  nSavedBytes;

	// Is the input stream out of synch?
	bool unsynched;

	unsigned int srcBitrate;

	mt_gptp * ptp;

} pvt_data_t;


// Each configuration name value pair for this mapping will result in this callback being called.
void mt_map_ts_cfg_cb(media_q_t *pMediaQ, const char *name, const char *value)
{

	if (pMediaQ) {
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return;
		}

		char *pEnd;
		unsigned long tmp;
		bool nameOK = TRUE, valueOK = FALSE;

		if (strcmp(name, "map_nv_item_count") == 0) {
			tmp = strtoul(value, &pEnd, 10);
			if (pEnd != value && *pEnd == '\0') {
				pPvtData->itemCount = tmp;
				valueOK = TRUE;
			}
		}
		else if (strcmp(name, "map_nv_item_size") == 0) {
			tmp = strtoul(value, &pEnd, 10);
			if (pEnd != value && *pEnd == '\0') {
				pPvtData->itemSize = tmp;
				valueOK = TRUE;
			}
		}
		else if (strcmp(name, "map_nv_ts_packet_size") == 0) {
			tmp = strtoul(value, &pEnd, 10);
			if (pEnd != value && *pEnd == '\0' && (tmp == 188 || tmp == 192)) {
				pPvtData->tsPacketSize = tmp;
				valueOK = TRUE;
			}
		}
		else if (strcmp(name, "map_nv_num_source_packets") == 0) {
			tmp = strtoul(value, &pEnd, 10);
			if (pEnd != value && *pEnd == '\0') {
				pPvtData->numSourcePackets = tmp;
				valueOK = TRUE;
			}
		}
		else if (strcmp(name, "map_nv_tx_rate") == 0
			|| strcmp(name, "map_nv_tx_interval") == 0) {
			tmp = strtoul(value, &pEnd, 10);
			if (pEnd != value && *pEnd == '\0') {
				pPvtData->txRate = tmp;
				valueOK = TRUE;
			}
		}
		else {
			MT_PRINT_DEBUG("Unknown configuration item: %s", name);
			nameOK = FALSE;
		}

		if (nameOK && !valueOK) {
			MT_PRINT_DEBUG("Bad value for configuration item: %s = %s", name, value);
		}
	}

}

U8 mt_map_ts_subtype_cb()
{
	return 0x00;        // 61883 AVB subtype
}

// Returns the AVTP version used by this mapping
U8 mt_map_ts_avtp_version_cb() {
	return 0x00;        // Version 0
}

U16 mt_map_ts_max_data_size_cb(media_q_t *pMediaQ)
{
	U16 retval = 0;
	if (pMediaQ) {
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return 0;
		}

		retval = MT_MPEGTS_SRC_PKT_SIZE * pPvtData->numSourcePackets + MT_CTOTAL_HEADER_SIZE;
	}
	return retval;
}

// Returns the intended transmit interval (in frames per second). 0 = default for talker / class.
U32 mt_map_ts_transmit_interval_cb(media_q_t *pMediaQ)
{
	if (pMediaQ) {
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return 0;
		}

		return pPvtData->txRate;
	}
	return 0;
}

void mt_map_ts_geninit_cb(media_q_t *pMediaQ)
{
	if (pMediaQ) {
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return;
		}
        pPvtData->ptp = mt_gptp_init();
		openavbMediaQSetSize(pMediaQ, pPvtData->itemCount, pPvtData->itemSize);
	}
}

// A call to this callback indicates that this mapping module will be
// a talker. Any talker initialization can be done in this function.
void mt_map_ts_init_cb(media_q_t *pMediaQ)
{
}

static int syncScan(media_q_item_t *pMediaQItem, U32 startIdx)
{
	char *data = pMediaQItem->pPubData;
	U32 offset;
	for (offset = startIdx; offset < pMediaQItem->dataLen; offset++) {
		if (data[offset] == MT_MPEG2_TS_SYNC_BYTE)
			break;
	}

	MT_PRINT_DEBUG("Dropped %d bytes", offset - startIdx);
	if (offset >= pMediaQItem->dataLen)
		offset = -1;

	return offset;
}

// This talker callback will be called for each AVB observation interval.
tx_cb_ret_t mt_map_ts_tx_cb(media_q_t *pMediaQ, U8 *pData, U32 *dataLen)
{
	if (pMediaQ && pData && dataLen) {
		U8 *pHdr = pData;
		U8 *pPayload = pData + MT_CTOTAL_HEADER_SIZE;
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return TX_CB_RET_PACKET_NOT_READY;
		}

		*(U32 *)(&pHdr[MT_HIDX_AVTP_TIMESTAMP32]) = 0;
		*(U32 *)(&pHdr[MT_HIDX_GATEWAY32]) = 0x00000000;
		//pHdr[MT_HIDX_DATALEN16] = 0x00;					// Set Later
		pHdr[MT_HIDX_TAG2_CHANNEL6] = (1 << 6) | 0x1f;
		pHdr[MT_HIDX_TCODE4_SY4] = (0x0a << 4) | 0;

		// Set the majority of the CIP header now.
		pHdr[MT_HIDX_CIP2_SID6] = (0x00 << 6) | 0x3f;
		pHdr[MT_HIDX_DBS8] = 0x06;
		pHdr[MT_HIDX_FN2_QPC3_SPH1_RSV2] = (0x03 << 6) | (0x00 << 3) | (0x01 << 2) | 0x00;
		// pHdr[MT_HIDX_DBC8] = 0; // This will be set later.
		pHdr[MT_HIDX_CIP2_FMT6] = (0x02 << 6) | 0xa0;
		pHdr[MT_HIDX_TSF1_RESA7] = (0x01 << 7) | 0x00;
		pHdr[MT_HIDX_RESB8] = 0x00;
		pHdr[MT_HIDX_RESC8] = 0x00;

		media_q_item_t *pMediaQItem = openavbMediaQTailLock(pMediaQ, TRUE);
		U32 sourcePacketsAdded = 0;
		int nItemBytes;
		U32 nAvailBytes;
		int offset, bytesNeeded;
		U32 timestamp;
		bool moreSourcePackets = TRUE;

		while (pMediaQItem && moreSourcePackets) {

			if (pPvtData->unsynched) {
				// Scan forward, looking for next sync byte.
				offset = syncScan(pMediaQItem, 0);
				if (offset >= 0)
					pMediaQItem->readIdx = offset;
				else {
					pPvtData->unsynched = TRUE;
					pMediaQItem->dataLen = 0;
					pMediaQItem->readIdx = 0;
				}
			}

			nItemBytes = pMediaQItem->dataLen - pMediaQItem->readIdx;
			nAvailBytes = nItemBytes + pPvtData->nSavedBytes;

			if (nItemBytes == 0) {
				// Empty MQ item, ignore
			}
			else if (nAvailBytes >= pPvtData->tsPacketSize) {
				// PTP walltime already set in the interface module. Just add the max transit time.
				// If this is a new mq item, add the AVTP transit time to the timestamp
				if (pMediaQItem->readIdx == 0 && pMediaQItem->pAvtpTime && pMediaQItem->pAvtpTime->bTimestampValid) {
                    pMediaQItem->pAvtpTime->timeNsec += pPvtData->maxTransitUsec * MT_GPTP_NANOSECONDS_PER_USEC;
				}

				timestamp = (U32)(pMediaQItem->pAvtpTime->timeNsec & 0x00000000FFFFFFFFL);

				// Set timestamp valid flag
				pHdr[MT_HIDX_AVTP_HIDE7_TV1] &= ~0x01;      
				//modify:because If the SPH bit is set, then the tv bit must be zero. If the SPH bit is not set, then the SYT field must be 0xFFFF.
				//Note, for MPEG2-TS encapsulation via IEC 61883-4:2004, the SPH bit should be set for all AVTPDUs.


				// Set timestamp uncertain flag
				if (pMediaQItem->pAvtpTime && pMediaQItem->pAvtpTime->bTimestampUncertain)
					pHdr[MT_HIDX_AVTP_HIDE7_TU1] |= 0x01;      // Set
				else pHdr[MT_HIDX_AVTP_HIDE7_TU1] &= ~0x01;     // Clear

				// Set the timestamp.
				if (sourcePacketsAdded == 0) {
					// TODO: I think this is wrong with source packets
					*(U32 *)(&pHdr[MT_HIDX_AVTP_TIMESTAMP32]) = 0;
				}

				/* Copy the TS packets into the outgoing AVTP frame
				 */
				offset = 0, bytesNeeded = pPvtData->tsPacketSize;

				// If getting 188-byte packets from interface, need to add source packet header
				if (pPvtData->tsPacketSize == MT_MPEG2_TS_PKT_SIZE) {
					// Set the timestamp on this source packet
					*((U32 *)pPayload) = htonl(timestamp);
					offset = MT_MPEGTS_SRC_PKT_HDR_SIZE;
				}

				// Use any leftover data from last MQ item
				if (pPvtData->nSavedBytes) {
					memcpy(pPayload + offset, pPvtData->savedBytes, pPvtData->nSavedBytes);
					offset += pPvtData->nSavedBytes;
					bytesNeeded -= pPvtData->nSavedBytes;
					pPvtData->nSavedBytes = 0;
				}

				// Now, copy data from current MQ item
				memcpy(pPayload + offset, (U8*)pMediaQItem->pPubData + pMediaQItem->readIdx, bytesNeeded);

				// Check that the data we've copied is synchronized
				/// i.e. that the transport stream packet starts
				//  where we think it should
				if (pPayload[4] == MT_MPEG2_TS_SYNC_BYTE) {
					// OK, now we can update the read index
					pMediaQItem->readIdx += bytesNeeded;
					// and move the payload ptr for the next source packet
					pPayload += MT_MPEGTS_SRC_PKT_SIZE;

					// Keep track of how many source packets have been added to the outgoing packet
					sourcePacketsAdded++;
				}
				else {
					MT_PRINT_DEBUG("Alignment problem");

					// Scan forward, looking for next sync byte.
					// Start scan after 4-byte header if getting 192 byte packets.
					// Ignore saved data if there was any, start from what's in current item.
					offset = syncScan(pMediaQItem, pMediaQItem->readIdx + (pPvtData->tsPacketSize - MT_MPEG2_TS_PKT_SIZE));
					if (offset >= 0)
						pMediaQItem->readIdx = offset;
					else {
						pPvtData->unsynched = TRUE;
						pMediaQItem->dataLen = 0;
						pMediaQItem->readIdx = 0;
					}
				}
			}
			else {
				// Arghhh - a partial packet.
				assert(pPvtData->nSavedBytes + nItemBytes <= MT_MPEG2_TS_PKT_SIZE);

				memcpy((U8 *)pPvtData->savedBytes + pPvtData->nSavedBytes,
					(U8 *)pMediaQItem->pPubData + pMediaQItem->readIdx,
					nItemBytes);
				pPvtData->nSavedBytes += nItemBytes;

				pMediaQItem->dataLen = 0;
				pMediaQItem->readIdx = 0;
			}

			// Have we reached our target?
			if (sourcePacketsAdded >= pPvtData->numSourcePackets) {
				moreSourcePackets = FALSE;
			}

			// Have we used up the data in the MQ item?
			if (pMediaQItem->dataLen - pMediaQItem->readIdx == 0) {
				// release used-up item
				openavbMediaQTailPull(pMediaQ);

				// and get a new one, if needed
				if (moreSourcePackets)
					pMediaQItem = openavbMediaQTailLock(pMediaQ, TRUE);
				else pMediaQItem = NULL;
			}

		} // while (pMediaQItem && moreSourcePackets)

		if (pMediaQItem) {
			// holds more data, leave it in the queue
			openavbMediaQTailUnlock(pMediaQ);
		}

		if (sourcePacketsAdded > 0) {

			// Set the block continuity and data length
			pHdr[MT_HIDX_DBC8] = pPvtData->DBC;
			pPvtData->DBC = (pPvtData->DBC + (sourcePacketsAdded * MT_BLOCKS_PER_SRC_PKT)) & 0x000000ff;

			U16 datalen = (sourcePacketsAdded * MT_MPEGTS_SRC_PKT_SIZE) + MT_CIP_HEADER_SIZE;
			*(U16 *)(pHdr + MT_HIDX_DATALEN16) = htons(datalen);

			// Set out bound data length (entire packet length)
			*dataLen = (sourcePacketsAdded * MT_MPEGTS_SRC_PKT_SIZE) + MT_CTOTAL_HEADER_SIZE;
			return TX_CB_RET_PACKET_READY;
		}
	}
	return TX_CB_RET_PACKET_NOT_READY;
}

// A call to this callback indicates that this mapping module will be
// a listener. Any listener initialization can be done in this function.
void mt_map_ts_rx_init_cb(media_q_t *pMediaQ) {
}

// This callback occurs when running as a listener and data is available.
bool mt_map_ts_rx_cb(media_q_t *pMediaQ, U8 *pData, U32 dataLen)
{
	if (pMediaQ && pData) {
		U8 *pHdr = pData;
		U8 *pPayload = pData + MT_CTOTAL_HEADER_SIZE;
		U8 sourcePacketCount = 0;
		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
		if (!pPvtData) {
			MT_PRINT_ERR("Private mapping module data not allocated.");
			return FALSE;
		}

		//pHdr[MT_HIDX_AVTP_TIMESTAMP32];
		//pHdr[MT_HIDX_GATEWAY32];
		//pHdr[MT_HIDX_DATALEN16];

		//pHdr[MT_HIDX_TAG2_CHANNEL6];
		//pHdr[MT_HIDX_TCODE4_SY4];
		//pHdr[MT_HIDX_CIP2_SID6];
		//pHdr[MT_HIDX_DBS8];
		//pHdr[MT_HIDX_FN2_QPC3_SPH1_RSV2];

		// Only support full source packets.
		// TODO: This mapper could be enhanced to support partial source packets and assemble the datablocks
		//	recieved across multiple avtp packets.
		if ((pHdr[MT_HIDX_DBC8] % 8) > 0) {
			MT_PRINT_ERR("Unsupported MPEG2TS block count received, payload discarded.");
			return FALSE;
		}

		// TODO: validate DBC

		// Determine the number of source packets bundled into the AVTP payload.
		U16 datalen = ntohs(*(U16 *)(pHdr + MT_HIDX_DATALEN16));
		sourcePacketCount = (datalen - MT_CIP_HEADER_SIZE) / MT_MPEGTS_SRC_PKT_SIZE;

		//pHdr[MT_HIDX_CIP2_FMT6];
		//pHdr[MT_HIDX_TSF1_RESA7];
		//pHdr[MT_HIDX_RESB8];
		//pHdr[MT_HIDX_RESC8];

		if (sourcePacketCount > 0) {
			// Get item in media queue
			media_q_item_t *pMediaQItem = openavbMediaQHeadLock(pMediaQ);
			if (pMediaQItem) {
				if (pMediaQItem->dataLen == 0) {
					// Get the timestamp and place it in the media queue item.
					U32 timestamp = ntohl(*(U32 *)(&pHdr[MT_HIDX_AVTP_TIMESTAMP32]));
					//openavbAvtpTimeSetToTimestamp(pMediaQItem->pAvtpTime, timestamp);
					if (pMediaQItem->pAvtpTime) {
						mt_time_set_to_ts(pPvtData->ptp, &(pMediaQItem->pAvtpTime->timeNsec), timestamp);
					}

					// Set timestamp valid and timestamp uncertain flags
					if (pMediaQItem->pAvtpTime) {
						pMediaQItem->pAvtpTime->bTimestampValid = (pHdr[MT_HIDX_AVTP_HIDE7_TV1] & 0x01) ? TRUE : FALSE;
						pMediaQItem->pAvtpTime->bTimestampUncertain = (pHdr[MT_HIDX_AVTP_HIDE7_TU1] & 0x01) ? TRUE : FALSE;
					}
			}

				int i;
				for (i = 0; i < sourcePacketCount; i++) {
					if (pMediaQItem->itemSize - pMediaQItem->dataLen >= pPvtData->tsPacketSize) {
						memcpy((U8 *)pMediaQItem->pPubData + pMediaQItem->dataLen,
							pPayload + MT_MPEGTS_SRC_PKT_SIZE - pPvtData->tsPacketSize,
							pPvtData->tsPacketSize);
						pMediaQItem->dataLen += pPvtData->tsPacketSize;
						pPayload += MT_MPEGTS_SRC_PKT_SIZE;
					}
					else {
						MT_PRINT_ERR("Data too large for media queue");
						pMediaQItem->dataLen = 0;
						break;
					}
				}

				// TODO: try to pack more data into MQ item?
				openavbMediaQHeadPush(pMediaQ);
			}
			else {
				// Media queue full, data dropped
				MT_IF_LOG_INTERVAL(1000) MT_PRINT_ERR("Media queue full");
				return FALSE;
			}
		}
	}
	return FALSE;
}

// This callback will be called when the mapping module needs to be closed.
// All cleanup should occur in this function.
void mt_map_ts_end_cb(media_q_t *pMediaQ)
{
}

void mt_map_ts_genend_cb(media_q_t *pMediaQ) {
	if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return;
        }
        mt_gptp_deinit(pPvtData->ptp);
    }
}

void mt_map_ts_set_srcbitrate_cb(media_q_t *pMediaQ, unsigned int bitrate)
{
	((pvt_data_t*)pMediaQ->pPvtMapInfo)->srcBitrate = (unsigned int)((double)bitrate * ((double)MT_MPEGTS_SRC_PKT_SIZE)/((double)MT_MPEG2_TS_PKT_SIZE));
}

unsigned int calculateBitrate(const int intervalsPerSecond, const int num_source_packets, const int number_of_frames)
{
	unsigned int bitrate = intervalsPerSecond * num_source_packets * number_of_frames * (MT_MPEGTS_SRC_PKT_SIZE) * 8;
	return bitrate;
}

unsigned int mt_map_ts_get_max_interval_frames_cb(media_q_t *pMediaQ, SRClassIdx_t sr_class)
{

	unsigned int interval_frames = 1;
	unsigned int classRate = 0;
	switch (sr_class) {
	case SR_CLASS_A:
		classRate = 8000;
		break;
	case SR_CLASS_B:
		classRate = 4000;
		break;
	case MAX_AVB_SR_CLASSES:	// Case included to avoid warning on some toolchains
		break;
	}

	((pvt_data_t*)pMediaQ->pPvtMapInfo)->numSourcePackets = 1;
	while (calculateBitrate(classRate,((pvt_data_t*)pMediaQ->pPvtMapInfo)->numSourcePackets,interval_frames) < ((pvt_data_t*)pMediaQ->pPvtMapInfo)->srcBitrate)
	{
		++((pvt_data_t*)pMediaQ->pPvtMapInfo)->numSourcePackets;
		if (((pvt_data_t*)pMediaQ->pPvtMapInfo)->numSourcePackets > 7)
		{
			((pvt_data_t*)pMediaQ->pPvtMapInfo)->numSourcePackets = 1;
			++interval_frames;
		}
	}

	return interval_frames;
}

// Initialization entry point into the mapping module. Will need to be included in the .ini file.
extern DLL_EXPORT bool openavbMapMpeg2tsInitialize(media_q_t *pMediaQ, openavb_map_cb_t *pMapCB, U32 inMaxTransitUsec)
{

	if (pMediaQ) {
		pMediaQ->pMediaQDataFormat = strdup(MapMpeg2tsMediaQDataFormat);
		pMediaQ->pPvtMapInfo = calloc(1, sizeof(pvt_data_t));       // Memory freed by the media queue when the media queue is destroyed.

		if (!pMediaQ->pMediaQDataFormat || !pMediaQ->pPvtMapInfo) {
			MT_PRINT_ERR("Unable to allocate memory for mapping module.");
			return FALSE;
		}

		pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;

		pMapCB->map_cfg_cb = mt_map_ts_cfg_cb;
		pMapCB->map_subtype_cb = mt_map_ts_subtype_cb;
		pMapCB->map_avtp_version_cb = mt_map_ts_avtp_version_cb;
		pMapCB->map_max_data_size_cb = mt_map_ts_max_data_size_cb;
		pMapCB->map_transmit_interval_cb = mt_map_ts_transmit_interval_cb;
		pMapCB->map_gen_init_cb = mt_map_ts_geninit_cb;
		pMapCB->map_tx_init_cb = mt_map_ts_init_cb;
		pMapCB->map_tx_cb = mt_map_ts_tx_cb;
		pMapCB->map_rx_init_cb = mt_map_ts_rx_init_cb;
		pMapCB->map_rx_cb = mt_map_ts_rx_cb;
		pMapCB->map_end_cb = mt_map_ts_end_cb;
		pMapCB->map_gen_end_cb = mt_map_ts_genend_cb;
		pMapCB->map_set_src_bitrate_cb = mt_map_ts_set_srcbitrate_cb;
		pMapCB->map_get_max_interval_frames_cb = mt_map_ts_get_max_interval_frames_cb;

		pPvtData->tsPacketSize = MT_MPEG2_TS_PKT_SIZE;
		pPvtData->numSourcePackets = MT_AVTP_DFLT_SRC_PKTS;
		pPvtData->itemCount = MT_MPEG2TS_MQITEM_COUNT;
		pPvtData->itemSize = MT_MPEG2TS_MQITEM_SIZE;
		pPvtData->txRate = 0;
		pPvtData->maxTransitUsec = inMaxTransitUsec;
		pPvtData->DBC = 0;

		openavbMediaQSetMaxLatency(pMediaQ, inMaxTransitUsec);
	}

	return TRUE;
}
