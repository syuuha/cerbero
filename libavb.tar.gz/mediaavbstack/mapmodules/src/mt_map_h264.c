#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include "openavb_types_pub.h"
#include "openavb_mediaq_pub.h"
#include "openavb_map_pub.h"
#include "mt_map_h264_pub.h"
#include <mt_debug.h>
#include <mt_gptp.h>

#ifdef MT_CATEGERY
#undef MT_CATEGERY
#endif
#define MT_CATEGERY "mt_avtp_map_h264"
#define LOG_VARX(x, y) x ## y
#define LOG_VAR(x, y) LOG_VARX(x, y)
#define MT_IF_LOG_INTERVAL(x) static U32 LOG_VAR(logOnce,__LINE__) = 0; if (!(LOG_VAR(logOnce,__LINE__)++ % (x)))

#define MT_MTU_SIZE                            1500
#define MT_AVTP_V0_HEADER_SIZE                 12
#define MT_MAP_HEADER_SIZE                     16
#define MT_H264_TIMESTAMP32_SIZE               4
#define MT_TOTAL_HEADER_SIZE                   (MT_AVTP_V0_HEADER_SIZE + MT_MAP_HEADER_SIZE)
#define MT_MAX_PAYLOAD_SIZE                    (MT_MTU_SIZE - MT_TOTAL_HEADER_SIZE)

//below macro represent the head bit
#define MT_HIDX_AVTP_VERZERO96                  0    // This mapping does not directly set or read these.
#define MT_HIDX_AVTP_HIDE7_TV1                  1    // - 1 Byte - TV bit (timestamp valid)
#define MT_HIDX_AVTP_HIDE7_TU1                  3    // - 1 Byte - TU bit (timestamp uncertain)
#define MT_HIDX_AVTP_TIMESTAMP32                12    // - 4 bytes    avtp_timestamp (nanosec)
#define MT_HIDX_FORMAT8                         16    // - 1 bytes    Format information             = 0x02 RTP Video
#define MT_HIDX_FORMAT_SUBTYPE8                 17    // - 1 bytes     Format subtype                = 0x01 H.264
#define MT_HIDX_RESV16                          18    // - 2 bytes     Reserved                    = 0x0000
#define MT_HIDX_STREAM_DATA_LEN16               20    // - 2 bytes    Stream data length
#define MT_HIDX_M31_M21_M11_M01_EVT2_RESV26     22    //set last frame flag
#define MT_HIDX_RESV8                           23    // - 1 byte        Reserved                    = binary 0x00
#define MT_HIDX_H264_TIMESTAMP32                24    //timestamp used by subtype h264

//this pvt_data_t would be seted by openavbMapH264Initialize, and reseted by config file
typedef struct {

    // map_nv_item_count
    U32 item_count;

    // Transmit interval in frames per second. 0 = default for talker class.
    U32 tx_interval;

    // Max payload size default is 1416, peritem payloadsize
    U32 max_payload_size;

    // Maximum transit time in microseconds, represent the net delay time, reseted by user
    U32 max_transit_usec;

    // Maximum data size. This is the RTP payload size. See RFC 6184 for details. rekated to avtphead , maphead and payloadsize
    U32 max_data_size;

    // Maximum media queue item size
    U32 item_size;

    mt_gptp * ptp;

} pvt_data_t;

// Each configuration name value pair for this mapping will result in this callback being called.
void mt_map_h264_cfg_cb(media_q_t *pMediaQ, const char *name, const char *value) {
    if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return;
        }

        char *pEnd;

        if (strcmp(name, "map_nv_item_count") == 0) {
            pPvtData->item_count = strtol(value, &pEnd, 10);
        }
        else if (strcmp(name, "map_nv_tx_rate") == 0
            || strcmp(name, "map_nv_tx_interval") == 0) {
            pPvtData->tx_interval = strtol(value, &pEnd, 10);
        }
        else if (strcmp(name, "map_nv_max_payload_size") == 0) {
            U32 size = strtol(value, &pEnd, 10);
            if (size > MT_MAX_PAYLOAD_SIZE) {
                MT_PRINT_DEBUG("map_nv_max_payload_size too large. Parameter set to default: %d", MT_MAX_PAYLOAD_SIZE);
                size = MT_MAX_PAYLOAD_SIZE;
            }
            pPvtData->max_payload_size = size;
            pPvtData->max_data_size = (pPvtData->max_payload_size + MT_TOTAL_HEADER_SIZE);
            pPvtData->item_size =    pPvtData->max_payload_size;
        }
    }


}

U8 mt_map_h264_subtype_cb() {
    return 0x03;        // AVTP Video subtype
}

// Returns the AVTP version used by this mapping
U8 mt_map_h264_avtp_version_cb() {
    return 0x00;        // Version 0
}

U16 mt_map_h264_max_datasize_cb(media_q_t *pMediaQ) {
if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return 0;
        }
        return pPvtData->max_data_size;
    }

    return 0;
}

// Returns the intended transmit interval (in frames per second). 0 = default for talker / class.
U32 mt_map_h264_transmit_interval_cb(media_q_t *pMediaQ) {
if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return 0;
        }
        return pPvtData->tx_interval;
    }

    return 0;
}

void mt_map_h264_geninit_cb(media_q_t *pMediaQ) {
if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return;
        }
        pPvtData->ptp = mt_gptp_init();
        openavbMediaQSetSize(pMediaQ, pPvtData->item_count, pPvtData->item_size);
        openavbMediaQAllocItemMapData(pMediaQ, sizeof(media_q_item_map_h264_pub_data_t), 0);
    }

}

// A call to this callback indicates that this mapping module will be
// a talker. Any talker initialization can be done in this function.
void mt_map_h264_tx_init_cb(media_q_t *pMediaQ) {
}

// This talker callback will be called for each AVB observation interval.
tx_cb_ret_t mt_map_h264_tx_cb(media_q_t *pMediaQ, U8 *pData, U32 *dataLen) {

    if (pMediaQ && pData && dataLen) {
        U8 *pHdr = pData;
        U8 *pPayload = pData + MT_TOTAL_HEADER_SIZE;
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return TX_CB_RET_PACKET_NOT_READY;
        }

		*(U32 *)(&pHdr[MT_HIDX_AVTP_TIMESTAMP32]) = 0;
        pHdr[MT_HIDX_FORMAT8] = 0x02;                          // RTP Payload type
        pHdr[MT_HIDX_FORMAT_SUBTYPE8] = 0x01;                  // H.264 subtype
        pHdr[MT_HIDX_RESV16] = 0x0000;                           // Reserved
        //pHdr[MT_HIDX_STREAM_DATA_LEN16] = 0x0000;            // Set later
        //pHdr[MT_HIDX_M31_M21_M11_M01_EVT2_RESV26] = 0x00;        // M0 set later
        pHdr[MT_HIDX_RESV8] = 0x00;

        media_q_item_t *pMediaQItem = openavbMediaQTailLock(pMediaQ, TRUE);
        if (pMediaQItem) {
            if (pMediaQItem->dataLen > 0) {
                if (pMediaQItem->dataLen > pPvtData->item_size) {
                    MT_PRINT_ERR("Media queue data item size too large. Reported size: %d  Max Size: %d", pMediaQItem->dataLen, pPvtData->item_size);
                    openavbMediaQTailPull(pMediaQ);
                    return TX_CB_RET_PACKET_NOT_READY;
                }

                // PTP walltime already set in the interface module. Just add the max transit time.
                // Set timestamp valid flag
                if (pMediaQItem->pAvtpTime && pMediaQItem->pAvtpTime->bTimestampValid) {
                    pHdr[MT_HIDX_AVTP_HIDE7_TV1] |= 0x01;      // Set
                    pMediaQItem->pAvtpTime->timeNsec += pPvtData->max_transit_usec * MT_GPTP_NANOSECONDS_PER_USEC;
                }
                else {
                    pHdr[MT_HIDX_AVTP_HIDE7_TV1] &= ~0x01;     // Clear
                }

                // Set timestamp uncertain flag
                if (pMediaQItem->pAvtpTime && pMediaQItem->pAvtpTime->bTimestampUncertain)
                    pHdr[MT_HIDX_AVTP_HIDE7_TU1] |= 0x01;      // Set
                else pHdr[MT_HIDX_AVTP_HIDE7_TU1] &= ~0x01;    // Clear

                // Set the timestamp.
                *(U32 *)(&pHdr[MT_HIDX_AVTP_TIMESTAMP32]) = htonl((U32)(pMediaQItem->pAvtpTime->timeNsec & 0x00000000FFFFFFFFL));

                if (((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->lastPacket) {
                    pHdr[MT_HIDX_M31_M21_M11_M01_EVT2_RESV26] = 0x10;;
                }
                else {
                    pHdr[MT_HIDX_M31_M21_M11_M01_EVT2_RESV26] = 0x00;
                }

                // Set h264_timestamp
                *(U32 *)(&pHdr[MT_HIDX_H264_TIMESTAMP32]) =
                        htonl(((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->timestamp);

                // Copy the h264 rtp payload into the outgoing avtp packet.
                memcpy(pPayload, pMediaQItem->pPubData, pMediaQItem->dataLen);

                *(U16 *)(&pHdr[MT_HIDX_STREAM_DATA_LEN16]) = htons(pMediaQItem->dataLen + MT_H264_TIMESTAMP32_SIZE);

                // Set out bound data length (entire packet length)
                *dataLen = pMediaQItem->dataLen + MT_TOTAL_HEADER_SIZE;
                openavbMediaQTailPull(pMediaQ);
                return TX_CB_RET_PACKET_READY;
            }
            openavbMediaQTailPull(pMediaQ);
        }
    }

    if (dataLen) {
        // Set out bound data length (entire packet length)
        *dataLen = 0;
    }

    return TX_CB_RET_PACKET_NOT_READY;
}

// A call to this callback indicates that this mapping module will be
// a listener. Any listener initialization can be done in this function.
void mt_map_h264_rx_init_cb(media_q_t *pMediaQ) {
}

// This callback occurs when running as a listener and data is available.
bool mt_map_h264_rx_cb(media_q_t *pMediaQ, U8 *pData, U32 dataLen) {

    if (pMediaQ && pData) {

        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return false;
        }

        U8 *pHdr = pData;
        U8 *pPayload = pData + MT_TOTAL_HEADER_SIZE;


        //pHdr[MT_HIDX_AVTP_TIMESTAMP32]
        //pHdr[MT_HIDX_FORMAT8]
        //pHdr[MT_HIDX_FORMAT_SUBTYPE8]
        //pHdr[MT_HIDX_RESV16]
        //pHdr[MT_HIDX_STREAM_DATA_LEN16]
        U16 payloadLen = ntohs(*(U16 *)(&pHdr[MT_HIDX_STREAM_DATA_LEN16]));
        //pHdr[MT_HIDX_M31_M21_M11_M01_EVT2_RESV26]
        //pHdr[MT_HIDX_RESV8]
        // validate headerW
        if (payloadLen  > dataLen - MT_TOTAL_HEADER_SIZE + MT_H264_TIMESTAMP32_SIZE) {
            MT_PRINT_ERR("header data len[%d] > actual data len[%d]", payloadLen, dataLen - MT_TOTAL_HEADER_SIZE);

            return FALSE;
        }
        // minus h264_timestamp_len
        payloadLen -= MT_H264_TIMESTAMP32_SIZE;

        // Get item pointer in media queue
        media_q_item_t *pMediaQItem = openavbMediaQHeadLock(pMediaQ);
        if (pMediaQItem) {
            // Get the timestamp and place it in the media queue item.
            U32 timestamp = ntohl(*(U32 *)(&pHdr[MT_HIDX_AVTP_TIMESTAMP32]));
            //openavbAvtpTimeSetToTimestamp(pMediaQItem->pAvtpTime, timestamp);
            if(pMediaQItem->pAvtpTime) {
            mt_time_set_to_ts(pPvtData->ptp, &(pMediaQItem->pAvtpTime->timeNsec), timestamp);
            }
            // Set timestamp valid and timestamp uncertain flags
            if(pMediaQItem->pAvtpTime) {
                pMediaQItem->pAvtpTime->bTimestampValid = (pHdr[MT_HIDX_AVTP_HIDE7_TV1] & 0x01) ? TRUE : FALSE;
                pMediaQItem->pAvtpTime->bTimestampUncertain = (pHdr[MT_HIDX_AVTP_HIDE7_TU1] & 0x01) ? TRUE : FALSE;
            }
            if (pHdr[MT_HIDX_M31_M21_M11_M01_EVT2_RESV26] & 0x10)
                ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->lastPacket = TRUE;
            else
                ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->lastPacket = FALSE;

            ((media_q_item_map_h264_pub_data_t *)pMediaQItem->pPubMapData)->timestamp =
                    ntohl(*(U32 *)(&pHdr[MT_HIDX_H264_TIMESTAMP32]));

            if (pMediaQItem->itemSize >= payloadLen) {
                memcpy(pMediaQItem->pPubData, pPayload, payloadLen);
                pMediaQItem->dataLen = payloadLen;
            }
            else {
                MT_PRINT_DEBUG("Data to large for media queue (itemSize %d, data size %d).", pMediaQItem->itemSize, payloadLen);
                pMediaQItem->dataLen = 0;
            }

            openavbMediaQHeadPush(pMediaQ);


            return TRUE;
        }
        else {
            // MT_IF_LOG_INTERVAL(1000) AVB_LOG_ERROR("Media queue full");//this contain a static AVB_LOG, Increment is 1,if over 1000 print queue full log
            MT_IF_LOG_INTERVAL(1000) MT_PRINT_ERR("Media queue full"); //Reduce frequency of print log

            return FALSE;   // Media queue full
        }
    }
    return FALSE;
}

// This callback will be called when the mapping module needs to be closed.
// All cleanup should occur in this function.
void mt_map_h264_end_cb(media_q_t *pMediaQ) {
}

void mt_map_h264_genend_cb(media_q_t *pMediaQ) {
if (pMediaQ) {
        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;
        if (!pPvtData) {
            MT_PRINT_ERR("Private mapping module data not allocated.");
            return;
        }
        mt_gptp_deinit(pPvtData->ptp);
    }
}

// Initialization entry point into the mapping module. Will need to be included in the .ini file.
extern DLL_EXPORT bool openavbMapH264Initialize(media_q_t *pMediaQ, openavb_map_cb_t *pMapCB, U32 inMaxTransitUsec) {
    if (pMediaQ) {
        pMediaQ->pMediaQDataFormat = strdup(MapH264MediaQDataFormat);
        pMediaQ->pPvtMapInfo = calloc(1, sizeof(pvt_data_t));       // Memory freed by the media queue when the media queue is destroyed.

        if (!pMediaQ->pMediaQDataFormat || !pMediaQ->pPvtMapInfo) {
            MT_PRINT_ERR("Unable to allocate memory for mapping module.");
            return FALSE;
        }

        pvt_data_t *pPvtData = pMediaQ->pPvtMapInfo;

        pMapCB->map_cfg_cb = mt_map_h264_cfg_cb;//read config file set property if no cinfig use the default val
        pMapCB->map_subtype_cb = mt_map_h264_subtype_cb;//avtp protocol surport this vedio size is 3
        pMapCB->map_avtp_version_cb = mt_map_h264_avtp_version_cb;//default avtpversion is 0
        pMapCB->map_max_data_size_cb = mt_map_h264_max_datasize_cb;//return max pay load size
        pMapCB->map_transmit_interval_cb = mt_map_h264_transmit_interval_cb;// return the value of  tx_interval witch set by map_nv_tx_rate or map_nv_tx_interval, if not set use default val = 0;
        pMapCB->map_gen_init_cb = mt_map_h264_geninit_cb;//set mediaqitem  item_size amd iemcount and set pPbumapData last frame and timestamp are included
        pMapCB->map_tx_init_cb = mt_map_h264_tx_init_cb;
        pMapCB->map_tx_cb = mt_map_h264_tx_cb;
        pMapCB->map_rx_init_cb = mt_map_h264_rx_init_cb;
        pMapCB->map_rx_cb = mt_map_h264_rx_cb;
        pMapCB->map_end_cb = mt_map_h264_end_cb;
        pMapCB->map_gen_end_cb = mt_map_h264_genend_cb;

        pPvtData->item_count = 20;
        pPvtData->tx_interval = 0;
        pPvtData->max_transit_usec = inMaxTransitUsec;

        pPvtData->max_payload_size = MT_MAX_PAYLOAD_SIZE;
        pPvtData->max_data_size = (pPvtData->max_payload_size + MT_TOTAL_HEADER_SIZE);
        pPvtData->item_size = pPvtData->max_payload_size;

        openavbMediaQSetMaxLatency(pMediaQ, inMaxTransitUsec);
    }


    return TRUE;
}
