/**
 * Copyright @ 2013 - 2018 Suntec Software(Shanghai) Co., Ltd.
 * All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are NOT permitted except as agreed by
 * Suntec Software(Shanghai) Co., Ltd.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/**
 * @file mt_debug.h
 */

#include <mt_debug.h>
#include <glib.h>
#include <glib/gprintf.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
//#include <sys/syscall.h>
#include <sys/uio.h>

#define TIME_US (1000000ll)
#define TIME_FORMAT "%u:%02u:%02u.%06u"
#define TIME_ARGS(t) \
        (guint)((t) / (TIME_US * 60 * 60)), \
        (guint)((t) / (TIME_US * 60) % 60), \
        (guint)((t) / (TIME_US) % 60), \
        (guint)((t) % TIME_US) \

static const char* level_tbl[] = {
    " ",
    "E",
    "W",
    "I",
    "L",
    "D",
    "T"
};

static GHashTable* g_debug_map = NULL;
static guint g_debug_level_threshold_default = MT_LOG_LEVEL_INVALID;

static void __attribute__((constructor))
mt_debug_init(void)
{
    const char* debug_env = g_getenv ("MT_DEBUG");
    if (NULL == debug_env || debug_env[0] == '\0') {
        return;
    }
    gint idx = 0;
    gchar** debug_str_list = g_strsplit(debug_env, ",", -1);
    if (NULL == debug_str_list) {
        return;
    }
    g_debug_map = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, NULL);
    while(NULL != debug_str_list[idx]) {
        gchar** level_str_list = g_strsplit(debug_str_list[idx], ":", -1);
        if (NULL != level_str_list) {
            if (NULL != level_str_list[0] && NULL != level_str_list[1]) {
                char* categery = g_strstrip(level_str_list[0]);
                guint level = g_ascii_strtoull(level_str_list[1], NULL, 10);
                if ('\0' == categery[0]) {
                    /* skip */
                } else if (0 == g_ascii_strcasecmp(categery, "*")){
                    g_debug_level_threshold_default = level;
                } else {
                    g_hash_table_replace(g_debug_map, g_strdup(categery), GUINT_TO_POINTER(level));
                }
            }
            g_strfreev(level_str_list);
        }
        ++idx;
    }
    g_strfreev(debug_str_list);
    return;
}

static void __attribute__((destructor))
mt_debug_atexit(void)
{
    if (g_debug_map) {
        g_hash_table_destroy(g_debug_map);
        g_debug_map = NULL;
    }
    g_debug_level_threshold_default = MT_LOG_LEVEL_INVALID;

    return;
}

void
mt_print(const char* categery, int level, const char* format, ...)
{
  va_list args;

  va_start (args, format);
  mt_printv(categery, level, format, args);
  va_end (args);
}

void
mt_printv(const char* categery, int level, const char* format, va_list args)
{
    if (NULL == g_debug_map ||
        (guint)level <= MT_LOG_LEVEL_INVALID ||
        (guint)level >= MT_LOG_LEVEL_MAX) {
        return;
    }
    guint level_threshold;
    gpointer level_value = NULL;
    if(g_hash_table_lookup_extended(g_debug_map, categery, NULL, &level_value)) {
        level_threshold = GPOINTER_TO_UINT(level_value);
    } else {
        level_threshold = g_debug_level_threshold_default;
    }
    if ((guint)level > level_threshold) {
        return;
    }
    char str[1024];
    int pos;
    gint64 ts = g_get_monotonic_time();
    gint pid = getpid();
    gint tid = 0;//syscall(SYS_gettid);

    str[0] = '\0';
    g_vsnprintf(str, sizeof(str), format, args);
    str[sizeof(str)-1] = '\0';

    g_fprintf(stderr, TIME_FORMAT " %5d %5d %-8s %s %s\n", TIME_ARGS(ts), pid, tid, categery, level_tbl[level], str);

    // g_vfprintf(stderr, format, args);
}
