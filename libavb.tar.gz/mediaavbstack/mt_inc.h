/**
 * Copyright @ 2013 - 2018 Suntec Software(Shanghai) Co., Ltd.
 * All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are NOT permitted except as agreed by
 * Suntec Software(Shanghai) Co., Ltd.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
/**
 * @file mt_buffer.h
 */

#ifndef MT_INC_H
#define MT_INC_H

#include <stddef.h>
#include <stdbool.h>

#define MT_RET_OK                   (0)
#define MT_RET_UNKOWN_ERROR         (-1)
#define MT_RET_INVALID_PARAM_ERROR  (-2)
#define MT_RET_TERMINATE_ERROR      (-3)
#define MT_RET_BUSY_ERROR           (-4)
#define MT_RET_TIMEOUT_ERROR        (-5)
#define MT_RET_OVERRUN_ERROR        (-6)
#define MT_RET_UNDERRUN_ERROR       (-7)

#define MT_AVTP_TALKER_MASK (0x1000)
#define MT_AVTP_LISTENER_MASK (0x0100)

#ifdef __cplusplus
/** If using C++ this macro enables C mode, otherwise does nothing */
#define MT_C_DECL_BEGIN extern "C" {
/* If using C++ this macros switches back to C++ mode, otherwise does nothing */
#define MT_C_DECL_END }
#else
/* If using C++ this macro enables C mode, otherwise does nothing */
#define MT_C_DECL_BEGIN
/* If using C++ this macros switches back to C++ mode, otherwise does nothing */
#define MT_C_DECL_END
#endif

typedef enum {
    MT_LOG_LEVEL_INVALID,
    MT_LOG_LEVEL_ERROR,
    MT_LOG_LEVEL_WARNING,
    MT_LOG_LEVEL_INFO,
    MT_LOG_LEVEL_LOG,
    MT_LOG_LEVEL_DEBUG,
    MT_LOG_LEVEL_TRACE,
    MT_LOG_LEVEL_MAX
} mt_log_level;

typedef enum {
    MT_STREAM_ROLE_UNDEFINED,
    MT_STREAM_ROLE_TALKER,
    MT_STREAM_ROLE_LISTENER
} mt_stream_role;

typedef enum {
    MT_STREAM_STATE_INIT,
    MT_STREAM_STATE_READY,
    MT_STREAM_STATE_RUNNING
} mt_stream_state;

typedef enum {
    MT_STREAM_NOT_CONTINUOUS = 0x0001,
} mt_stream_flag;

typedef struct _mt_buffer {
    /* read/write */
    long long timestamp;
    int offset;
    int length;
    int flag;
    /* readonly */
    int size;
    void* data;
    void* user_data;
} mt_buffer;

typedef enum {
    MT_AVTP_ROLE_PCM_TALKER = 0 | MT_AVTP_TALKER_MASK,
    MT_AVTP_ROLE_PCM_LISTENER = 1 | MT_AVTP_LISTENER_MASK,
    MT_AVTP_ROLE_TS_TALKER = 2 | MT_AVTP_TALKER_MASK,
    MT_AVTP_ROLE_TS_LISTENER = 3 | MT_AVTP_LISTENER_MASK,
    MT_AVTP_ROLE_H264_TALKER = 4 | MT_AVTP_TALKER_MASK,
    MT_AVTP_ROLE_H264_LISTENER = 5 | MT_AVTP_LISTENER_MASK,
    MT_AVTP_ROLE_MJPEG_TALKER = 6 | MT_AVTP_TALKER_MASK,
    MT_AVTP_ROLE_MJPEG_LISTENER = 7 | MT_AVTP_LISTENER_MASK,
    MT_AVTP_ROLE_AAF_TALKER = 8 | MT_AVTP_TALKER_MASK,
    MT_AVTP_ROLE_AAF_LISTENER = 9 | MT_AVTP_LISTENER_MASK
} mt_avtp_role_type;

#endif // MT_INC_H
