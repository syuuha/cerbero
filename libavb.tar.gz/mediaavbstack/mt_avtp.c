#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdint.h>
#include <errno.h>
#include "openavb_platform.h"
#include "openavb_types.h"
#include "mt_avtp.h"
#include "openavb_rawsock.h"
#include "openavb_mediaq.h"
#include <mt_debug.h>
#include <mt_gptp.h>

#ifdef MT_CATEGERY
#undef MT_CATEGERY
#endif
#define MT_CATEGERY "mt_avtp"
#define LOG_VARX(x, y) x ## y
#define LOG_VAR(x, y) LOG_VARX(x, y)
#define MT_IF_LOG_INTERVAL(x) static U32 LOG_VAR(logOnce,__LINE__) = 0; if (!(LOG_VAR(logOnce,__LINE__)++ % (x)))

// Maximum time that AVTP RX/TX calls should block before returning
#define AVTP_MAX_BLOCK_USEC (1 * MICROSECONDS_PER_SECOND)

/*
 * This is broken out into a function, so that we can close and reopen
 * the socket if we detect a problem receiving frames.
 */
static openavbRC openAvtpSock(avtp_stream_t *pStream)
{
    if (pStream->tx) {
        pStream->rawsock = openavbRawsockOpen(pStream->ifname, FALSE, TRUE, MT_ETHERTYPE_AVTP, pStream->frameLen, pStream->nbuffers);
    }
    else {
#ifndef UBUNTU
        // This is the normal case for most of our supported platforms
        pStream->rawsock = openavbRawsockOpen(pStream->ifname, TRUE, FALSE, MT_ETHERTYPE_8021Q, pStream->frameLen, pStream->nbuffers);
#else
        pStream->rawsock = openavbRawsockOpen(pStream->ifname, TRUE, FALSE, MT_ETHERTYPE_AVTP, pStream->frameLen, pStream->nbuffers);
#endif
    }

    if (pStream->rawsock != NULL) {
        openavbSetRxSignalMode(pStream->rawsock, pStream->bRxSignalMode);

        if (!pStream->tx) {
            // Set the multicast address that we want to receive
            openavbRawsockRxMulticast(pStream->rawsock, TRUE, pStream->dest_addr.ether_addr_octet);
        }
        return OPENAVB_AVTP_SUCCESS;
    }
    MT_PRINT_ERR("%s", openavbUtilRCCodeToString(OPENAVB_AVTP_FAILURE | OPENAVB_RC_RAWSOCK_OPEN));
    return OPENAVB_AVTP_FAILURE | OPENAVB_RC_RAWSOCK_OPEN;
}


// Evaluate the AVTP timestamp. Only valid for common AVTP stream subtypes
#define HIDX_AVTP_HIDE7_TV1            1
#define HIDX_AVTP_HIDE7_TU1            3
#define HIDX_AVTP_TIMESPAMP32        12
static void processTimestampEval(avtp_stream_t *pStream, U8 *pHdr)
{
    if (pStream->tsEval) {
        bool tsValid =  (pHdr[HIDX_AVTP_HIDE7_TV1] & 0x01) ? TRUE : FALSE;
        bool tsUncertain = (pHdr[HIDX_AVTP_HIDE7_TU1] & 0x01) ? TRUE : FALSE;

        if (tsValid && !tsUncertain) {
            U32 ts = ntohl(*(U32 *)(&pHdr[HIDX_AVTP_TIMESPAMP32]));
            U32 tsSmoothed = openavbTimestampEvalTimestamp(pStream->tsEval, ts);
            if (tsSmoothed != ts) {
                *(U32 *)(&pHdr[HIDX_AVTP_TIMESPAMP32]) = htonl(tsSmoothed);
            }
        }
    }

}


/* Initialize AVTP for talking
 */
openavbRC mt_avtp_tx_init(
    media_q_t *pMediaQ,
    openavb_map_cb_t *pMapCB,
    openavb_intf_cb_t *pIntfCB,
    char *ifname,
    AVBStreamID_t *streamID,
    U8 *destAddr,
    U32 max_transit_usec,
    U32 fwmark,
    U16 vlanID,
    U8  vlanPCP,
    U16 nbuffers,
    void **pStream_out)
{
    MT_PRINT_DEBUG("Initialize");

    *pStream_out = NULL;

    // Malloc the structure to hold state information
    avtp_stream_t *pStream = calloc(1, sizeof(avtp_stream_t));
    if (!pStream) {
        MT_PRINT_ERR("when mt_avtp_tx_init pStream is NULL");
    }
    pStream->tx = TRUE;

    pStream->pMediaQ = pMediaQ;
    pStream->pMapCB = pMapCB;
    pStream->pIntfCB = pIntfCB;

    pStream->pMapCB->map_tx_init_cb(pStream->pMediaQ);
    pStream->pIntfCB->intf_tx_init_cb(pStream->pMediaQ);
    if (pStream->pIntfCB->intf_set_stream_uid_cb) {
        pStream->pIntfCB->intf_set_stream_uid_cb(pStream->pMediaQ, streamID->uniqueID);
    }

    // Set the frame length
    pStream->frameLen = pStream->pMapCB->map_max_data_size_cb(pStream->pMediaQ) + MT_ETH_HDR_LEN_VLAN;

    // and the latency
    pStream->max_transit_usec = max_transit_usec;

    // and save other stuff needed to (re)open the socket
    pStream->ifname = strdup(ifname);
    pStream->nbuffers = nbuffers;

    // Open a raw socket
    openavbRC rc = openAvtpSock(pStream);
    if (IS_OPENAVB_FAILURE(rc)) {
        free(pStream);
        MT_PRINT_ERR("when mt_avtp_tx_init openAvtpSock failed");
    }

    // Create the AVTP frame header for the frames we'll send
    hdr_info_t hdrInfo;

    U8 srcAddr[ETH_ALEN];
    if (openavbRawsockGetAddr(pStream->rawsock, srcAddr)) {
        hdrInfo.shost = srcAddr;
    }
    else {
        openavbRawsockClose(pStream->rawsock);
        free(pStream);
        MT_PRINT_ERR("when mt_avtp_tx_init openavbRawsockGetAddr failed");
    }

    hdrInfo.dhost = destAddr;
    if (vlanPCP != 0 || vlanID != 0) {
        hdrInfo.vlan = TRUE;
        hdrInfo.vlan_pcp = vlanPCP;
        hdrInfo.vlan_vid = vlanID;
        MT_PRINT_DEBUG("VLAN pcp=%d vid=%d", hdrInfo.vlan_pcp, hdrInfo.vlan_vid);
    }
    else {
        hdrInfo.vlan = FALSE;
    }
    openavbRawsockTxSetHdr(pStream->rawsock, &hdrInfo);

    // Remember the AVTP subtype and streamID
    pStream->subtype = pStream->pMapCB->map_subtype_cb();

    memcpy(pStream->streamIDnet, streamID->addr, ETH_ALEN);
        U16 *pStreamUID = (U16 *)((U8 *)(pStream->streamIDnet) + ETH_ALEN);
       *pStreamUID = htons(streamID->uniqueID);

    // Set the fwmark - used to steer packets into the right traffic control queue
    openavbRawsockTxSetMark(pStream->rawsock, fwmark);

    *pStream_out = (void *)pStream;
    return OPENAVB_AVTP_SUCCESS;
}

#ifdef OPENAVB_AVTP_REPORT_RX_STATS
static void inline rxDeliveryStats(avtp_rx_info_t *rxInfo,
    struct timespec *tmNow,
    U32 early, U32 late)
{

    rxInfo->rxCnt++;

    if (late > 0) {
        rxInfo->lateCnt++;
        if (late > rxInfo->maxLate)
            rxInfo->maxLate = late;
    }
    if (early > 0) {
        rxInfo->earlyCnt++;
        if (early > rxInfo->maxEarly)
            rxInfo->maxEarly = early;
    }

    if (rxInfo->lastTime.tv_sec == 0) {
        rxInfo->lastTime.tv_sec = tmNow->tv_sec;
        rxInfo->lastTime.tv_nsec = tmNow->tv_nsec;
    }
    else if ((tmNow->tv_sec > (rxInfo->lastTime.tv_sec + MT_OPENAVB_AVTP_REPORT_INTERVAL))
        || ((tmNow->tv_sec == (rxInfo->lastTime.tv_sec + MT_OPENAVB_AVTP_REPORT_INTERVAL))
            && (tmNow->tv_nsec > rxInfo->lastTime.tv_nsec))) {
        MT_PRINT_DEBUG("Stream %d seconds, %lu samples: %lu late, max=%lums, %lu early, max=%lums",
            MT_OPENAVB_AVTP_REPORT_INTERVAL, (unsigned long)rxInfo->rxCnt,
            (unsigned long)rxInfo->lateCnt, (unsigned long)rxInfo->maxLate / NANOSECONDS_PER_MSEC,
            (unsigned long)rxInfo->earlyCnt, (unsigned long)rxInfo->maxEarly / NANOSECONDS_PER_MSEC);
        rxInfo->maxLate = 0;
        rxInfo->lateCnt = 0;
        rxInfo->maxEarly = 0;
        rxInfo->earlyCnt = 0;
        rxInfo->rxCnt = 0;
        rxInfo->lastTime.tv_sec = tmNow->tv_sec;
        rxInfo->lastTime.tv_nsec = tmNow->tv_nsec;
    }

#if 0
    if (++txCnt >= 1000) {}
#endif
}
#endif

static openavbRC fillAvtpHdr(avtp_stream_t *pStream, U8 *pFill)
{
    switch (pStream->pMapCB->map_avtp_version_cb()) {
        default:
            MT_PRINT_ERR("%s", openavbUtilRCCodeToString(OPENAVB_AVTP_FAILURE | OPENAVBAVTP_RC_INVALID_AVTP_VERSION));
            return OPENAVB_AVTP_FAILURE | OPENAVBAVTP_RC_INVALID_AVTP_VERSION;
        case 0:
            //
            // - 1 bit         cd (control/data indicator)    = 0 (stream data)
            // - 7 bits     subtype                      = as configured
            *pFill++ = pStream->subtype & 0x7F;
            // - 1 bit         sv (stream valid)            = 1
            // - 3 bits     AVTP version                = binary 000
            // - 1 bit        mr (media restart)            = toggled when clock changes
            // - 1 bit        r (reserved)                = 0
            // - 1 bit        gv (gateway valid)            = 0
            // - 1 bit        tv (timestamp valid)        = 1
            // TODO: set mr correctly
            *pFill++ = 0x81;
            // - 8 bits        sequence num                = increments with each frame
            *pFill++ = pStream->avtp_sequence_num;
            // - 7 bits        reserved                    = 0;
            // - 1 bit        tu (timestamp uncertain)    = 1 when no PTP sync
            // TODO: set tu correctly
            *pFill++ = 0;
            // - 8 bytes    stream_id
            memcpy(pFill, (U8 *)&pStream->streamIDnet, 8);
            break;
    }
    return OPENAVB_AVTP_SUCCESS;
}

/* Send a frame
 */
openavbRC mt_avtp_tx(void *pv, bool bSend, bool txBlockingInIntf)
{
    avtp_stream_t *pStream = (avtp_stream_t *)pv;
    if (!pStream) {
        MT_PRINT_ERR("%s", openavbUtilRCCodeToString(OPENAVB_AVTP_FAILURE | OPENAVB_RC_INVALID_ARGUMENT));
        return OPENAVB_AVTP_FAILURE | OPENAVB_RC_INVALID_ARGUMENT;
    }

    U8 * pAvtpFrame,*pFill;
    U32 avtpFrameLen, frameLen;
    tx_cb_ret_t txCBResult = TX_CB_RET_PACKET_NOT_READY;

    // Get a TX buf if we don't already have one.
    //   (We keep the TX buf in our stream data, so that if we don't
    //    get data from the mapping module, we can use the buf next time.)
    if (!pStream->pBuf) {

        pStream->pBuf = (U8 *)openavbRawsockGetTxFrame(pStream->rawsock, TRUE, &frameLen);
        if (pStream->pBuf) {
            assert(frameLen >= pStream->frameLen);
            // Fill in the Ethernet header
            openavbRawsockTxFillHdr(pStream->rawsock, pStream->pBuf, &pStream->ethHdrLen);
        }
    }

    if (pStream->pBuf) {
        // AVTP frame starts right after the Ethernet header
        pAvtpFrame = pFill = pStream->pBuf + pStream->ethHdrLen;
        avtpFrameLen = pStream->frameLen - pStream->ethHdrLen;

        // Fill the AVTP Header. This must be done before calling the interface and mapping modules.
        openavbRC rc = fillAvtpHdr(pStream, pFill);
        if (IS_OPENAVB_FAILURE(rc)) {
            MT_PRINT_ERR("%s", openavbUtilRCCodeToString(rc));
            return rc;
        }

        U64 timeNsec = 0;

        if (!txBlockingInIntf) {
            // Call interface module to read data
            pStream->pIntfCB->intf_tx_cb(pStream->pMediaQ);

#if IGB_LAUNCHTIME_ENABLED
            // lets get unmodified timestamp from mediaq item about to be sent by mapping
            media_q_item_t* item = openavbMediaQTailLock(pStream->pMediaQ, true);
            if (item) {
                timeNsec = item->pAvtpTime->timeNsec;
                openavbMediaQTailUnlock(pStream->pMediaQ);
            }
#endif

            // Call mapping module to move data into AVTP frame
            txCBResult = pStream->pMapCB->map_tx_cb(pStream->pMediaQ, pAvtpFrame, &avtpFrameLen);

            pStream->bytes += avtpFrameLen;
        }
        else {

#if IGB_LAUNCHTIME_ENABLED
            // lets get unmodified timestamp from mediaq item about to be sent by mapping
            media_q_item_t* item = openavbMediaQTailLock(pStream->pMediaQ, true);
            if (item) {
                timeNsec = item->pAvtpTime->timeNsec;
                openavbMediaQTailUnlock(pStream->pMediaQ);
            }
#endif

            // Blocking in interface mode. Pull from media queue for tx first
            if ((txCBResult = pStream->pMapCB->map_tx_cb(pStream->pMediaQ, pAvtpFrame, &avtpFrameLen)) == TX_CB_RET_PACKET_NOT_READY) {
                // Call interface module to read data
                pStream->pIntfCB->intf_tx_cb(pStream->pMediaQ);
            }
            else {
                pStream->bytes += avtpFrameLen;
            }
        }

        // If we got data from the mapping module and stream is not paused,
        // notify the raw sockets.
        if (txCBResult != TX_CB_RET_PACKET_NOT_READY && !pStream->bPause) {

            if (pStream->tsEval) {
                processTimestampEval(pStream, pAvtpFrame);
            }

            // Increment the sequence number now that we are sure this is a good packet.
            pStream->avtp_sequence_num++;
            // Mark the frame "ready to send".
            // AVB_LOGF_VERBOSE("ready to send, avtpFrameLen[%d]", avtpFrameLen);
            openavbRawsockTxFrameReady(pStream->rawsock, pStream->pBuf, avtpFrameLen + pStream->ethHdrLen, timeNsec);
            // Send if requested
            if (bSend)
                openavbRawsockSend(pStream->rawsock);

            // Drop our reference to it
            pStream->pBuf = NULL;
        }
        else {
            return OPENAVB_AVTP_FAILURE;
        }
    }
    else {
            return OPENAVB_AVTP_FAILURE;
    }
    return OPENAVB_AVTP_SUCCESS;
}

openavbRC mt_avtp_rx_init(
    media_q_t *pMediaQ,
    openavb_map_cb_t *pMapCB,
    openavb_intf_cb_t *pIntfCB,
    char *ifname,
    AVBStreamID_t *streamID,
    U8 *daddr,
    U16 nbuffers,
    bool rxSignalMode,
    void **pStream_out)
{
    MT_PRINT_DEBUG("Initialize");

    *pStream_out = NULL;

    if (!pMapCB) {
        MT_PRINT_ERR("Mapping callback structure not set");
        return OPENAVB_AVTP_FAILURE | OPENAVBAVTP_RC_MAPPING_CB_NOT_SET;
    }
    if (!pIntfCB) {
        MT_PRINT_ERR("Interface callback structure not set");
        return OPENAVB_AVTP_FAILURE | OPENAVBAVTP_RC_INTERFACE_CB_NOT_SET;
    }
    if (!daddr) {
        MT_PRINT_ERR("Invalid function argument");
        return OPENAVB_AVTP_FAILURE | OPENAVB_RC_INVALID_ARGUMENT;

    }

    avtp_stream_t *pStream = calloc(1, sizeof(avtp_stream_t));
    if (!pStream) {
        MT_PRINT_ERR("Out of memory");
        return OPENAVB_AVTP_FAILURE | OPENAVB_RC_OUT_OF_MEMORY;

    }
    pStream->tx = FALSE;
    pStream->nLost = -1;

    pStream->pMediaQ = pMediaQ;
    pStream->pMapCB = pMapCB;
    pStream->pIntfCB = pIntfCB;

    pStream->pMapCB->map_rx_init_cb(pStream->pMediaQ);
    pStream->pIntfCB->intf_rx_init_cb(pStream->pMediaQ);
    if (pStream->pIntfCB->intf_set_stream_uid_cb) {
        pStream->pIntfCB->intf_set_stream_uid_cb(pStream->pMediaQ, streamID->uniqueID);
    }

    // Set the frame length
    pStream->frameLen = pStream->pMapCB->map_max_data_size_cb(pStream->pMediaQ) + MT_ETH_HDR_LEN_VLAN;

    // Save the streamID
    memcpy(pStream->streamIDnet, streamID->addr, ETH_ALEN);
        U16 *pStreamUID = (U16 *)((U8 *)(pStream->streamIDnet) + ETH_ALEN);
       *pStreamUID = htons(streamID->uniqueID);

    // and the destination MAC address
    memcpy(pStream->dest_addr.ether_addr_octet, daddr, ETH_ALEN);

    // and other stuff needed to (re)open the socket
    pStream->ifname = strdup(ifname);
    pStream->nbuffers = nbuffers;
    pStream->bRxSignalMode = rxSignalMode;

    openavbRC rc = openAvtpSock(pStream);
    if (IS_OPENAVB_FAILURE(rc)) {
        free(pStream);
        //AVB_RC_LOG_TRACE_RET(rc, AVB_TRACE_AVTP);
        MT_PRINT_ERR("%s", openavbUtilRCCodeToString(rc));
        return rc;
    }

    // Save the AVTP subtype
    pStream->subtype = pStream->pMapCB->map_subtype_cb();

    *pStream_out = (void *)pStream;
    return OPENAVB_AVTP_SUCCESS;
}

static int x_avtpRxFrame(avtp_stream_t *pStream, U8 *pFrame, U32 frameLen)
{
    MT_IF_LOG_INTERVAL(4096) MT_PRINT_DEBUG("pFrame=%p, len=%u", pFrame, frameLen);
    U8 subtype, flags, flags2, rxSeq, nLost, avtpVersion;
    U8 *pRead = pFrame;

    // AVTP Header
    //
    // Check control/data bit.  We only expect data packets.
    if (0 == (*pRead & 0x80)) {
        // - 7 bits     subtype
        subtype = *pRead++ & 0x7F;
        flags   = *pRead++;
        avtpVersion = (flags >> 4) & 0x07;

        // Check AVTPDU version, BZ 106
        if (0 == avtpVersion) {

            rxSeq = *pRead++;

            if (pStream->nLost == -1) {
                // first frame received, don't check for mismatch
                pStream->nLost = 0;
            }
            else if (pStream->avtp_sequence_num != rxSeq) {
                nLost = (rxSeq - pStream->avtp_sequence_num)
                    + (rxSeq < pStream->avtp_sequence_num ? 256 : 0);
                MT_PRINT_DEBUG("AVTP sequence mismatch: expected: %3u,\tgot: %3u,\tlost %3d",
                    pStream->avtp_sequence_num, rxSeq, nLost);
                pStream->nLost += nLost;
            }
            pStream->avtp_sequence_num = rxSeq + 1;

            pStream->bytes += frameLen;

            flags2 = *pRead++;
            MT_IF_LOG_INTERVAL(4096) MT_PRINT_DEBUG("subtype=%u, sv=%u, ver=%u, mr=%u, tv=%u tu=%u",
                subtype, flags & 0x80, avtpVersion,
                flags & 0x08, flags & 0x01, flags2 & 0x01);

            pRead += 8;

            if (pStream->tsEval) {
                processTimestampEval(pStream, pFrame);
            }

            pStream->pMapCB->map_rx_cb(pStream->pMediaQ, pFrame, frameLen);

            // NOTE : This is a redundant call. It is handled in avtpTryRx()
            // pStream->pIntfCB->intf_rx_cb(pStream->pMediaQ);

            pStream->info.rx.bComplete = TRUE;

            // to prevent unused variable warnings
            (void)subtype;
            (void)flags2;
            return 0;
        }
        else {
            MT_PRINT_ERR("%s", openavbUtilRCCodeToString(OPENAVB_AVTP_FAILURE | OPENAVBAVTP_RC_INVALID_AVTP_VERSION));
            return OPENAVB_AVTP_FAILURE | OPENAVBAVTP_RC_INVALID_AVTP_VERSION;
        }
    }
    else {
        MT_PRINT_ERR("%s", openavbUtilRCCodeToString(OPENAVB_AVTP_FAILURE | OPENAVBAVTP_RC_IGNORING_CONTROL_PACKET));
        return OPENAVB_AVTP_FAILURE | OPENAVBAVTP_RC_IGNORING_CONTROL_PACKET;

    }

}

/*
 * Try to receive some data.
 *
 * Keeps state information in pStream.
 * Look at pStream->info for the received data.
 */
static int avtpTryRx(avtp_stream_t *pStream)
{
    U8         *pBuf = NULL;   // pointer to buffer containing rcvd frame, if any
    U8         *pAvtpPdu;      // pointer to AVTP PDU within Ethernet frame
    U32         offsetToFrame; // offset into pBuf where Ethernet frame begins (bytes)
    U32         frameLen;      // length of the Ethernet frame (bytes)
    int         hdrLen;        // length of the Ethernet frame header (bytes)
    U32         avtpPduLen;    // length of the AVTP PDU (bytes)
    hdr_info_t  hdrInfo;       // Ethernet header contents
    U32         timeout;

    while (!pBuf) {
        if (!openavbMediaQUsecTillTail(pStream->pMediaQ, &timeout)) {
            // No mediaQ item available therefore wait for a new packet
            timeout = AVTP_MAX_BLOCK_USEC;
            pBuf = (U8 *)openavbRawsockGetRxFrame(pStream->rawsock, timeout, &offsetToFrame, &frameLen);
            if (!pBuf) {
                return -1;
            }
        }
        else/* if (timeout == 0) */ {
            // Process the pending media queue item and after check for available incoming packets
            pStream->pIntfCB->intf_rx_cb(pStream->pMediaQ);

            // Previously would check for new packets but disabled to favor presentation times.
            // pBuf = (U8 *)openavbRawsockGetRxFrame(pStream->rawsock, OPENAVB_RAWSOCK_NONBLOCK, &offsetToFrame, &frameLen);
        }
        // else {
        //     if (timeout > AVTP_MAX_BLOCK_USEC)
        //         timeout = AVTP_MAX_BLOCK_USEC;
        //     if (timeout < RAWSOCK_MIN_TIMEOUT_USEC)
        //         timeout = RAWSOCK_MIN_TIMEOUT_USEC;

        //     pBuf = (U8 *)openavbRawsockGetRxFrame(pStream->rawsock, timeout, &offsetToFrame, &frameLen);
        //     if (!pBuf)
        //         pStream->pIntfCB->intf_rx_cb(pStream->pMediaQ);
        // }
    }

    hdrLen = openavbRawsockRxParseHdr(pStream->rawsock, pBuf, &hdrInfo);
    if (hdrLen < 0) {
        MT_PRINT_ERR("%s", openavbUtilRCCodeToString(OPENAVB_AVTP_FAILURE | OPENAVBAVTP_RC_PARSING_FRAME_HEADER));
        return OPENAVB_AVTP_FAILURE | OPENAVBAVTP_RC_PARSING_FRAME_HEADER;

    }
    else {
        pAvtpPdu = pBuf + offsetToFrame + hdrLen;
        avtpPduLen = frameLen - hdrLen;
        x_avtpRxFrame(pStream, pAvtpPdu, avtpPduLen);
    }
    openavbRawsockRelRxFrame(pStream->rawsock, pBuf);
    return 0;

}

int mt_avtp_tx_buffer_level(void *pv)
{
    avtp_stream_t *pStream = (avtp_stream_t *)pv;
    if (!pStream) {
        MT_PRINT_ERR("%s", openavbUtilRCCodeToString(OPENAVB_AVTP_FAILURE | OPENAVB_RC_INVALID_ARGUMENT));
        return 0;
    }
    return openavbRawsockTxBufLevel(pStream->rawsock);
}

int mt_avtp_rx_buffer_level(void *pv)
{
    avtp_stream_t *pStream = (avtp_stream_t *)pv;
    if (!pStream) {
        MT_PRINT_ERR("%s", openavbUtilRCCodeToString(OPENAVB_AVTP_FAILURE | OPENAVB_RC_INVALID_ARGUMENT));
        return 0;
    }
    return openavbRawsockRxBufLevel(pStream->rawsock);
}

int mt_avtp_lost(void *pv)
{
    avtp_stream_t *pStream = (avtp_stream_t *)pv;
    if (!pStream) {
        // Quietly return. Since this can be called before a stream is available.
        return 0;
    }
    int count = pStream->nLost;
    pStream->nLost = 0;
    return count;
}

U64 mt_avtp_bytes(void *pv)
{
    avtp_stream_t *pStream = (avtp_stream_t *)pv;
    if (!pStream) {
        // Quietly return. Since this can be called before a stream is available.
        return 0;
    }

    U64 bytes = pStream->bytes;
    pStream->bytes = 0;
    return bytes;
}

openavbRC mt_avtp_rx(void *pv)
{
    avtp_stream_t *pStream = (avtp_stream_t *)pv;
    if (!pStream) {
        MT_PRINT_ERR("%s", openavbUtilRCCodeToString(OPENAVB_AVTP_FAILURE | OPENAVB_RC_INVALID_ARGUMENT));
        return OPENAVB_AVTP_FAILURE | OPENAVB_RC_INVALID_ARGUMENT;
    }

    // Check our socket, and potentially receive some data.
    avtpTryRx(pStream);

    // See if there's a complete (re-assembled) data sample.
    if (pStream->info.rx.bComplete) {
        pStream->info.rx.bComplete = FALSE;
        //AVB_RC_TRACE_RET(OPENAVB_AVTP_SUCCESS, AVB_TRACE_AVTP_DETAIL);
        return OPENAVB_AVTP_SUCCESS;
    }
    MT_PRINT_INFO("%s", openavbUtilRCCodeToString(OPENAVB_AVTP_FAILURE | OPENAVBAVTP_RC_NO_FRAMES_PROCESSED));
    return OPENAVB_AVTP_FAILURE | OPENAVBAVTP_RC_NO_FRAMES_PROCESSED;
}

void mt_avtp_config_timestamp_ecal(void *handle, U32 tsInterval, U32 reportInterval, bool smoothing, U32 tsMaxJitter, U32 tsMaxDrift)
{

    avtp_stream_t *pStream = (avtp_stream_t *)handle;
    if (!pStream) {
        MT_PRINT_ERR("%s", openavbUtilRCCodeToString(OPENAVB_AVTP_FAILURE | OPENAVB_RC_INVALID_ARGUMENT));
        return;
    }

    pStream->tsEval = openavbTimestampEvalNew();
    openavbTimestampEvalInitialize(pStream->tsEval, tsInterval);
    openavbTimestampEvalSetReport(pStream->tsEval, reportInterval);
    if (smoothing) {
        openavbTimestampEvalSetSmoothing(pStream->tsEval, tsMaxJitter, tsMaxDrift);
    }

}

void mt_avtp_pause(void *handle, bool bPause)
{

    avtp_stream_t *pStream = (avtp_stream_t *)handle;
    if (!pStream) {
        MT_PRINT_ERR("%s", openavbUtilRCCodeToString(OPENAVB_AVTP_FAILURE | OPENAVB_RC_INVALID_ARGUMENT));
        return;
    }

    pStream->bPause = bPause;

    // AVDECC_TODO:  Do something with the bPause value!

}

void mt_avtp_shutdown_talker(void *pv)
{
    MT_PRINT_DEBUG("Shutdown");

    avtp_stream_t *pStream = (avtp_stream_t *)pv;
    if (pStream) {
        pStream->pIntfCB->intf_end_cb(pStream->pMediaQ);
        pStream->pMapCB->map_end_cb(pStream->pMediaQ);

        // close the rawsock
        if (pStream->rawsock) {
            openavbRawsockClose(pStream->rawsock);
            pStream->rawsock = NULL;
        }

        if (pStream->ifname)
            free(pStream->ifname);

        // free the malloc'd stream info
        free(pStream);
    }
    return;
}

void mt_avtp_shutdown_listener(void *pv)
{
    MT_PRINT_DEBUG("Shutdown");

    avtp_stream_t *pStream = (avtp_stream_t *)pv;
    if (pStream) {
        // close the rawsock
        if (pStream->rawsock) {
            openavbRawsockClose(pStream->rawsock);
            pStream->rawsock = NULL;
        }

        pStream->pIntfCB->intf_end_cb(pStream->pMediaQ);
        pStream->pMapCB->map_end_cb(pStream->pMediaQ);

        if (pStream->ifname)
            free(pStream->ifname);

        // free the malloc'd stream info
        free(pStream);
    }
    return;
}
