
#ifndef MT_AVTP_COMMON_H
#define MT_AVTP_COMMON_H
#include <mt_plugin_stream.h>
#include <mt_gptp.h>
extern mt_plugins_utils_funcs g_utils_funcs;

#define MT_PRINT_TRACE(format, ...) g_utils_funcs.print(MT_CATEGERY, MT_LOG_LEVEL_TRACE, format, ##__VA_ARGS__)
#define MT_PRINT_LOG(format, ...) g_utils_funcs.print(MT_CATEGERY, MT_LOG_LEVEL_LOG, format, ##__VA_ARGS__)
#define MT_PRINT_INFO(format, ...) g_utils_funcs.print(MT_CATEGERY, MT_LOG_LEVEL_INFO, format, ##__VA_ARGS__)
#define MT_PRINT_DEBUG(format, ...) g_utils_funcs.print(MT_CATEGERY, MT_LOG_LEVEL_DEBUG, format, ##__VA_ARGS__)
#define MT_PRINT_ERR(format, ...) g_utils_funcs.print(MT_CATEGERY, MT_LOG_LEVEL_ERROR, format, ##__VA_ARGS__)


#define MT_AVTP_STREAM_INTF_KV_HEAD     ("intf_nv_")
#define MT_AVTP_STREAM_MAP_KV_HEAD      ("map_nv_")

#define ETH_FORMAT    "%02x:%02x:%02x:%02x:%02x:%02x"
#define ETH_OCTETS(a) (a)[0],(a)[1],(a)[2],(a)[3],(a)[4],(a)[5]

#define STREAMID_FORMAT    "%02x:%02x:%02x:%02x:%02x:%02x/%u"
#define STREAMID_ARGS(s)   (s)->addr[0],(s)->addr[1],(s)->addr[2],(s)->addr[3],(s)->addr[4],(s)->addr[5],(s)->uniqueID

#define GROUP_PCM_TALKER ("PCM-TALKER")
#define GROUP_PCM_TALKER_NV ("PCM-TALKER-NV")
#define GROUP_PCM_LISTENER ("PCM-LISTENER")
#define GROUP_PCM_LISTENER_NV ("PCM-LISTENER-NV")
#define GROUP_H264_TALKER ("H264-TALKER")
#define GROUP_H264_TALKER_NV ("H264-TALKER-NV")
#define GROUP_H264_LISTENER ("H264-LISTENER")
#define GROUP_H264_LISTENER_NV ("H264-LISTENER-NV")
#define GROUP_AAF_TALKER ("AAF-TALKER")
#define GROUP_AAF_TALKER_NV ("AAF-TALKER-NV")
#define GROUP_AAF_LISTENER ("AAF-LISTENER")
#define GROUP_AAF_LISTENER_NV ("AAF-LISTENER-NV")
#define GROUP_MJPEG_TALKER ("MJPEG-TALKER")
#define GROUP_MJPEG_TALKER_NV ("MJPEG-TALKER-NV")
#define GROUP_MJPEG_LISTENER ("MJPEG-LISTENER")
#define GROUP_MJPEG_LISTENER_NV ("MJPEG-LISTENER-NV")
#define GROUP_TS_TALKER ("TS-TALKER")
#define GROUP_TS_TALKER_NV ("TS-TALKER-NV")
#define GROUP_TS_LISTENER ("TS-LISTENER")
#define GROUP_TS_LISTENER_NV ("TS-LISTENER-NV")

#define INVALID_INT_VAL (-1)      //通过判断结构体中的ｉｎｔ值是否有效　　决定是否要读取配置文件

//used to be parse config

typedef struct {
    int role;
    const char *group_name;
    const char *sub_group_name;
} role_format_group;

typedef enum _timestamp_type {
    TS_DEFAULT,
    TS_SYSTEM,
    TS_MASTER
} timestamp_type;

static const role_format_group role_format_group_table[] = {
    {MT_AVTP_ROLE_PCM_TALKER, GROUP_PCM_TALKER, GROUP_PCM_TALKER_NV},
    {MT_AVTP_ROLE_PCM_LISTENER, GROUP_PCM_LISTENER, GROUP_PCM_LISTENER_NV},
    {MT_AVTP_ROLE_TS_TALKER, GROUP_TS_TALKER, GROUP_TS_TALKER_NV},
    {MT_AVTP_ROLE_TS_LISTENER, GROUP_TS_LISTENER, GROUP_TS_LISTENER_NV},
    {MT_AVTP_ROLE_H264_TALKER, GROUP_H264_TALKER, GROUP_H264_TALKER_NV},
    {MT_AVTP_ROLE_H264_LISTENER, GROUP_H264_LISTENER, GROUP_H264_LISTENER_NV},
    {MT_AVTP_ROLE_MJPEG_TALKER, GROUP_MJPEG_TALKER, GROUP_MJPEG_TALKER_NV},
    {MT_AVTP_ROLE_MJPEG_LISTENER, GROUP_MJPEG_LISTENER, GROUP_MJPEG_LISTENER_NV},
    {MT_AVTP_ROLE_AAF_TALKER, GROUP_AAF_TALKER, GROUP_AAF_TALKER_NV},
    {MT_AVTP_ROLE_AAF_LISTENER, GROUP_AAF_LISTENER, GROUP_AAF_LISTENER_NV},
    {0, NULL, NULL}

};

#endif

